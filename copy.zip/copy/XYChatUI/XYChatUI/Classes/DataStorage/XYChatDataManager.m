//
//  XYChatDataManager.m
//  MJExtension
//
//  Created by henry on 2018/9/29.
//

#import "XYChatDataManager.h"
#import <FMDB/FMDB.h>
#import "XYChatSourceProtocol.h"
#import "XYChatContactModel.h"
#import "XYChatMsgTextModel.h"

@interface XYChatDataManager()
@property (nonatomic,strong) FMDatabase *database;

@end

@implementation XYChatDataManager

+ (XYChatDataManager *)shareInstance{
    static XYChatDataManager *shareInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareInstance = [XYChatDataManager new];
    });
    return shareInstance;
}

- (void)connectWithMid:(NSString *)mid{
    if ([self.database goodConnection]) {
        if ([self.mid isEqualToString:mid]) {
            return;
        }
        [self disconnect];
    }
    
    NSString *path = [self getDBPathWithMid:mid];
    self.database = [FMDatabase databaseWithPath:path];
    if (![self.database open]) {
        NSLog(@"连接数据库失败");
    }
}

- (void)disconnect{
    [self.database close];
    self.database = nil;
}

- (NSString *)getDBPathWithMid:(NSString *)mid{
    NSString *documentPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    documentPath = [documentPath stringByAppendingPathComponent:@"basedata"];
    NSFileManager *manager = [NSFileManager defaultManager];
    BOOL isDirectory = NO;
    BOOL exists = [manager fileExistsAtPath:documentPath isDirectory:&isDirectory];
    BOOL isCreate = NO;
    if (exists && !isDirectory) {//存在文件不存在目录
        isCreate = YES;
    }
    
    if (!exists ) {//不存在文件和目录
        isCreate = YES;
    }
    
    //创建目录
    if(isCreate){
        [manager createDirectoryAtPath:documentPath withIntermediateDirectories:nil attributes:nil error:nil];
    }
    
    NSString *dbPath = [documentPath stringByAppendingPathComponent:[NSString stringWithFormat:@"user%@.db",mid]];
    
    isDirectory = NO;
    exists = [manager fileExistsAtPath:dbPath isDirectory:&isDirectory];
    isCreate = NO;
    if (exists && isDirectory) {//存在目录不存在文件
        isCreate = YES;
    }
    
    if (!exists ) {//不存在文件和目录
        isCreate = YES;
    }
    
    //创建目录
    if(isCreate){
        NSString *orgPath = [XYChatSourceProtocol pathWithName:@"chat_database" withType:@"sqlite"];
        [manager copyItemAtPath:orgPath toPath:dbPath error:nil];
    }
    return dbPath;
}

- (NSArray *)queryContactList{
    FMResultSet *s = [self.database executeQuery:@"SELECT * FROM contact"];
    NSMutableArray *contacts = [NSMutableArray new];
    if ([s next]) {
        NSData *data = [s dataForColumn:@"data"];
        id obj = [NSKeyedUnarchiver unarchiveObjectWithData:data];
        if (obj) {
            [contacts addObject:obj];
        }
    }
    return contacts;
}

- (void)updateContactList:(NSArray *)contactList{
//    for (XYChatContactModel *contact in contactList) {
//        
//        
//    }
}


- (void)updateContact:(XYChatContactModel *)contact{
    if (![self.database goodConnection]) {
        NSLog(@"数据库连接出错");
        return ;
    }
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:contact];
    NSString *mid = contact.toUserId;
    BOOL isSucc =  [self.database executeUpdate:@"update contact set data = ? where mid = ?",data,mid];
    if (isSucc) {
        [self.database commit];
    }
}

- (XYChatMsgTextModel *)msgModelWithMessageId:(NSString *)messageId{
    FMResultSet *s = [self.database executeQuery:@"SELECT * FROM msg where mid = ?",messageId];
    NSMutableArray *msgs = [NSMutableArray new];
    if ([s next]) {
        NSData *data = [s dataForColumn:@"data"];
        id obj = [NSKeyedUnarchiver unarchiveObjectWithData:data];
        if (obj) {
            [msgs addObject:obj];
        }
    }
    return [msgs firstObject];
}

- (void)insertMsg:(XYChatMsgTextModel *)msgModel{
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:msgModel];
    BOOL isSucc =  [self.database executeUpdate:@"insert into msg (message_id,data) values (?,?) ",msgModel.messageId,data];
    if (isSucc) {
        [self.database commit];
    }
}

@end
