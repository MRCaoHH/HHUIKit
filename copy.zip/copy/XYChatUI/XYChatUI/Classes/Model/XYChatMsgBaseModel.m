//
//  XYChatMsgBaseModel.m
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import "XYChatMsgBaseModel.h"

@implementation XYChatMsgBaseModel

- (void)setState:(XYChatMsgSendState)state{
    _state = state;
    if (_stateObserver) {
        _stateObserver(state);
    }
}

@end
