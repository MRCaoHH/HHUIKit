//
//  XYStudentModel.m
//  XYExtension
//
//  Created by henry on 2017/10/26.
//  Copyright © 2017年 henry. All rights reserved.
//

#import "XYStudentModel.h"
@implementation XYSexModel

@end

@implementation XYStudentModel



@end
