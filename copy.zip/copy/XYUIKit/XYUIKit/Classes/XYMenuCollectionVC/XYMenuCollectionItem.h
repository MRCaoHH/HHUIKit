//
//  XYMenuCollectionItem.h
//  XYUIKit
//
//  Created by henry on 2018/1/2.
//

#import <Foundation/Foundation.h>

@interface XYMenuCollectionItem : NSObject
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *iconUrl;
@property (nonatomic,copy) NSString *action;
@end
