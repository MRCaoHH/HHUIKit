//
//  XYBTSwitchCell.m
//  XYUIKit
//
//  Created by henry on 2017/12/16.
//

#import "XYBTSwitchCell.h"
#import <Masonry/Masonry.h>
#import <XYCategory/XYCategory.h>

@implementation XYBTSwitchCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSubview];
        [self initConstrant];
        self.titleFontSize = 16;
        self.titleColor = @"#454545";
    }
    return self;
}

- (void)initSubview{
    _switchView = [UISwitch new];
    [_switchView addTarget:self action:@selector(switchChangeValue:) forControlEvents:UIControlEventValueChanged];
    [self.contentView addSubview:_switchView];
    
    _titleLabel = [UILabel new];
    [self.contentView addSubview:_titleLabel];
}

- (void)initConstrant{
    [_switchView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.mas_right).offset(self.switchToEdge);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(self.titleToEdge);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
}

- (void)_updateConstraints{
    [_switchView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.mas_right).offset(self.switchToEdge);
        make.centerY.equalTo(self.mas_centerY);
    }];
    
    [_titleLabel mas_updateConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.mas_left).offset(self.titleToEdge);
        make.centerY.equalTo(self.mas_centerY);
    }];
}

#pragma mark - 交互 -
- (void)switchChangeValue:(UISwitch *)aSwitch{
    if (self.notificationName) {
        [[NSNotificationCenter defaultCenter]postNotificationName:self.notificationName object:@(aSwitch.on)];
    }
}

#pragma mark - 属性方法 -
- (void)setSwitchToEdge:(CGFloat)switchToEdge{
    _switchToEdge = switchToEdge;
    [self _updateConstraints];
}

- (void)setTitleToEdge:(CGFloat)titleToEdge{
    _titleToEdge = titleToEdge;
    [self _updateConstraints];
}

- (void)setTitleColor:(NSString *)titleColor{
    _titleColor = titleColor;
    _titleLabel.textColor = [UIColor xy_colorWithHexString:titleColor];
}

- (void)setTitleFontSize:(CGFloat)titleFontSize{
    _titleFontSize = titleFontSize;
    _titleLabel.font = [UIFont systemFontOfSize:titleFontSize];
}

- (void)setSwitchTintColor:(NSString *)switchTintColor{
    _switchTintColor = switchTintColor;
    _switchView.tintColor = [UIColor xy_colorWithHexString:switchTintColor];
}

- (void)setSwitchOnTintColor:(NSString *)switchOnTintColor{
    _switchOnTintColor = switchOnTintColor;
    _switchView.onTintColor = [UIColor xy_colorWithHexString:switchOnTintColor];
}

- (void)setSwitchThumbTintColor:(NSString *)switchThumbTintColor{
    _switchThumbTintColor = switchThumbTintColor;
    _switchView.thumbTintColor = [UIColor xy_colorWithHexString:switchThumbTintColor];
}
@end
