//
//  XYBlurViewController.m
//  XYNavigationController_Example
//
//  Created by henry on 2017/12/7.
//  Copyright © 2017年 henry. All rights reserved.
//

#import "XYBlurViewController.h"
#import <XYNavigationController/XYBlurDismiss.h>
#import <XYNavigationController/XYBlurPresent.h>
#import <pop/pop.h>
#import <XYCategory/XYCategory.h>

@interface XYBlurViewController ()<UIViewControllerTransitioningDelegate>
@property (nonatomic,strong) UIButton *dismissBtn;
@property (nonatomic,strong) UIButton *dismissBtn2;
@end

@implementation XYBlurViewController

- (instancetype)init{
    self = [super init];
    if (self) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _dismissBtn = [UIButton new];
    _dismissBtn.frame = CGRectMake(33, 300, 100, 100);
    _dismissBtn.layer.cornerRadius = 50;
    _dismissBtn.layer.masksToBounds = YES;
    [_dismissBtn setTitle:@"开启直播" forState:UIControlStateNormal];
    _dismissBtn.titleLabel.font = [UIFont systemFontOfSize:14];
    [_dismissBtn setImage:[UIImage imageNamed:@"live_account_qq"] forState:UIControlStateNormal];
    [_dismissBtn addTarget:self action:@selector(clickDismissBtn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_dismissBtn];
    [_dismissBtn xy_adjustLayout:20];
    
    _dismissBtn2 = [UIButton new];
    _dismissBtn2.frame = CGRectMake(166, 300, 100, 100);
    _dismissBtn2.layer.cornerRadius = 50;
    _dismissBtn2.layer.masksToBounds = YES;
    [_dismissBtn2 setImage:[UIImage imageNamed:@"live_account_wechat"] forState:UIControlStateNormal];
    [_dismissBtn2 setTitle:@"发布动态" forState:UIControlStateNormal];
    _dismissBtn2.titleLabel.font = [UIFont systemFontOfSize:14];
    [_dismissBtn2 addTarget:self action:@selector(clickDismissBtn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_dismissBtn2];
    [_dismissBtn2 xy_adjustLayout:20];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(xy_dismissVC)];
    [self.view addGestureRecognizer:tap];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)clickDismissBtn{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)xy_dismissVC{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UIViewControllerTransitioningDelegate -
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return ({
        XYBlurPresent *present =  [XYBlurPresent new];
        present.viewSize = CGSizeMake(300, 300);
        present.type = XYBlurPresentAnimateType_BottomPsuh;
        __weak typeof(self) weakSelf = self;
        [present setPresentAnimate:^{
            [weakSelf presentAnimate];
        }];
        present;
    });
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return ({
        XYBlurDismiss *dismiss = [XYBlurDismiss new];
        dismiss.type = XYBlurDismissAnimateType_BottomPop;
        dismiss;
    });
}


#pragma mark - 动画执行
- (void)presentAnimate{

    POPSpringAnimation *positionAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerPositionY];
    positionAnimation.toValue = @(200);
    positionAnimation.springBounciness = random()%10;
    positionAnimation.dynamicsMass = random()%50 + 20;
    positionAnimation.springSpeed =  positionAnimation.dynamicsMass;
    [self.dismissBtn.layer pop_addAnimation:positionAnimation forKey:@"positionAnimation"];
    
    POPSpringAnimation *positionAnimation2 = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerPositionY];
    positionAnimation2.toValue = @(200);
    positionAnimation2.springBounciness =  random()%10;
    positionAnimation2.dynamicsMass = random()%50 + 20;;
    positionAnimation2.springSpeed =  positionAnimation2.dynamicsMass/10;
    [self.dismissBtn2.layer pop_addAnimation:positionAnimation2 forKey:@"positionAnimation"];
}
@end
