# XYRefresh

## 版本变更信息

|版本|文档修改时间|修改人|
|---|---|---|
|1.0.0|2018-1-31|henry|

## Example 使用方法

终端进入`XYAlert/Example`目录运行命令：

```ruby
pod install
```

用xcode 打开 XYRefresh.xcworkspace 就可以直接运行Example


## 用法

导入头文件

```Objc
    #import <XYAlert/XYAlert.h>
```

添加header头部

```Objc
[XYRefresh  addHeaderRefresh:self.tableView target:self action:@selector(downPullRefresh)];
```

开始头部刷新

```Objc
[XYRefresh beginHeaderRefresh:self.tableView];
```

结束头部刷新动画

```Objc
[XYRefresh endHeaderRefresh:self.tableView];
```

添加尾部

```Objc
[XYRefresh addFooterRefresh:self.tableView target:self action:@selector(loadMore)];
```

开始尾部刷新

```Objc
[XYRefresh beginFooterRefresh:self.tableView];
```

结束尾部刷新
```Objc
[XYRefresh endFooterRefresh:self.tableView];
```





