//
//  XYTitleMenuView.m
//  XY
//
//  Created by henry on 2018/1/2.
//

#import "XYTitleMenuView.h"
#import <XYMacro/XYMacro_Key.h>
#import <XYCategory/XYCategory.h>

@interface XYTitleMenuView ()
@property (nonatomic,strong) NSDictionary *fixWidths;
@property (nonatomic,strong) UIColor *bgColor;
@property (nonatomic,strong) UIColor *textColor;
@end

@implementation XYTitleMenuView

- (instancetype)initWithTitles:(NSArray *)titles{
    self = [self initWithTitles:titles bgColor:[UIColor blackColor] textColor:[UIColor whiteColor]];
    return self;
}

- (instancetype)initWithTitles:(NSArray *)titles bgColor:(UIColor *)bgColor textColor:(UIColor *)textColor{
    return [self initWithTitles:titles fixWidths:nil bgColor:bgColor textColor:textColor];
}

- (instancetype)initWithTitles:(NSArray *)titles fixWidths:(NSDictionary *)fixWidths bgColor:(UIColor *)bgColor textColor:(UIColor *)textColor{
    self = [super init];
    if (self) {
        _fixWidths = fixWidths;
        _bgColor = bgColor;
        _textColor = textColor;
        _titles = titles;
        _titleHeight = 44;
        _titleFontSize = 15;
        [self initSubview];
    }
    return self;
}

- (void)initSubview{
    self.backgroundColor = _bgColor;
    CGFloat fixWidth = 0;
    for (NSNumber *width in self.fixWidths.allValues) {
        fixWidth += width.floatValue;
    }
    NSInteger count = (_titles.count - [self.fixWidths.allValues count]);
    CGFloat width = count ? (XYScreen_Width - fixWidth)/(_titles.count - [self.fixWidths.allValues count]):0;
    CGFloat x = 0;
    CGFloat y = 0;
    CGFloat height = self.titleHeight;
    for (NSString *title in _titles) {
        CGFloat labelWidth = width;
        if (self.fixWidths[title]) {
            labelWidth = [self.fixWidths[title] floatValue];
        }
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(x, y, labelWidth, height)];
        label.backgroundColor = self.bgColor;
        label.font = [UIFont systemFontOfSize:_titleFontSize];
        label.textColor = self.textColor;
        label.text = title;
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = [title hash];
        [self addSubview:label];
        x=label.xy_right;
    }
    self.xy_height = height;
}

- (void)adjustsStyle{
    self.backgroundColor = self.bgColor;
    self.xy_height = self.titleHeight;
    for (NSString *title in _titles) {
        UILabel *label = [self viewWithTag:[title hash]];
        label.xy_height = self.titleHeight;
        label.backgroundColor = self.bgColor;
        label.font = [UIFont systemFontOfSize: self.titleFontSize];
        label.textColor = self.textColor;
    }
}


- (void)setTitleHeight:(CGFloat)titleHeight{
    _titleHeight = titleHeight;
    [self adjustsStyle];
}

- (void)setTitleFontSize:(CGFloat)titleFontSize{
    _titleFontSize = titleFontSize;
    [self adjustsStyle];
}

- (void)setBgColor:(UIColor *)bgColor{
    _bgColor = bgColor;
    [self adjustsStyle];
}

@end
