//
//  XYChatDelayedTaskTool.m
//  MJExtension
//
//  Created by henry on 2018/9/29.
//

#import "XYChatDelayedTaskTool.h"

@implementation XYChatDelayedTaskTool

+ (dispatch_block_t)createDelayedTask:(int64_t)delayedTime task:(void(^)(void))task{
    dispatch_block_t block = dispatch_block_create(DISPATCH_BLOCK_BARRIER, task);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, delayedTime * NSEC_PER_SEC),dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), block);
    return block;
}


+ (void)cancelBlock:(dispatch_block_t)block{
    dispatch_block_cancel(block);
}
@end
