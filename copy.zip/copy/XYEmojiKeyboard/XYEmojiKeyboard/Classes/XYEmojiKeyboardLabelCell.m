//
//  XYEmojiKeyboardLabelCell.m
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/16.
//

#import "XYEmojiKeyboardLabelCell.h"

@implementation XYEmojiKeyboardLabelCell

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubview];
    }
    return self;
}

- (void)updateConstraints{
    [super updateConstraints];
    _emojiLabel.font = [UIFont systemFontOfSize:self.frame.size.width / 2];
}

- (void)initSubview{
    self.emojiLabel = [UILabel new];
    self.emojiLabel.textAlignment = NSTextAlignmentCenter;
    self.emojiLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:self.emojiLabel];
    
    NSString *vflH = @"H:|-0-[_emojiLabel]-0-|";
    NSString  *vflV = @"V:|-0-[_emojiLabel]-0-|";
    
    NSDictionary *views =  NSDictionaryOfVariableBindings(_emojiLabel);
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:vflH options:0 metrics:nil views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:vflV options:0 metrics:nil views:views]];
}
@end

@implementation XYEmojiCategoryCell

- (void)initSubview{
    [super initSubview];
    _sepLine = [[UIView alloc]init];
    _sepLine.translatesAutoresizingMaskIntoConstraints = NO;
    _sepLine.backgroundColor = [UIColor colorWithRed:0.93 green:0.93 blue:0.93 alpha:1.00];
    [self addSubview:_sepLine];
    CGFloat lineWidth = 1.0/[UIScreen mainScreen].scale;
    CGFloat toTop = 5;
    CGFloat toBottom = 5;
    NSString  *vflV = @"V:|-5-[_sepLine]-5-|";
    NSDictionary *metrics = @{@"lineWidth":@(lineWidth),@"toTop":@(toTop),@"toBottom":@(toBottom)};
    NSDictionary *views =  NSDictionaryOfVariableBindings(_sepLine);
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:vflV options:0 metrics:metrics views:views]];
    [self addConstraints: [NSLayoutConstraint constraintsWithVisualFormat:@"H:[_sepLine(lineWidth)]-0-|" options:0 metrics:metrics views:views]];
    
}

@end
