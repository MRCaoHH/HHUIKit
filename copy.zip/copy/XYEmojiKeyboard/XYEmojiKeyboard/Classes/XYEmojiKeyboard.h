//
//  XYEmojiKeyboard.h
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/15.
//

#import <UIKit/UIKit.h>

@protocol XYEmojiKeyboardDelegate;

@interface XYEmojiKeyboard : UIView
@property (nonatomic,weak) id<XYEmojiKeyboardDelegate> delegate;
@end

@protocol XYEmojiKeyboardDelegate<NSObject>
@optional
- (void)emojiKeyboard:(XYEmojiKeyboard *)emojiKeyboard sendEmoji:(NSString *)emoji;
- (void)emojiKeyboardClickDeleteEvent:(XYEmojiKeyboard *)emojiKeyboard;
- (void)emojiKeyboardClickSendEvent:(XYEmojiKeyboard *)emojiKeyboard;
@end
