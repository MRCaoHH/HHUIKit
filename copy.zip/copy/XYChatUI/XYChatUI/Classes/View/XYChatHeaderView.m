//
//  XYChatHeaderView.m
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import "XYChatHeaderView.h"
#import "XYChatHeaderDelegate.h"
@implementation XYChatHeaderView
@synthesize headerDelegate = _headerDelegate,chatVC = _chatVC;

- (instancetype)init{
    self = [super initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 40)];
    if (self) {
        [self initSubview];
    }
    return self;
}

- (void)initSubview{
    self.clipsToBounds = YES;
    
    _tipsLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0,[UIScreen mainScreen].bounds.size.width, 40)];
    [self addSubview:_tipsLabel];
    
    _closeBtn = [[UIButton alloc]init];
    _closeBtn.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 60, 0, 60, 40);
    [_closeBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [_closeBtn addTarget:self action:@selector(clickCloseBtnEvent) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_closeBtn];
}

- (void)clickCloseBtnEvent{
    CGRect frame = self.frame;
    frame.size.height = 0;
    self.frame = frame;
    [self.headerDelegate chatHeader:self changeFrame:frame];
}

@end
