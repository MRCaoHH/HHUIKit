//
//  XYAlertViewController.m
//  XYNavigationController_Example
//
//  Created by henry on 2017/12/7.
//  Copyright © 2017年 henry. All rights reserved.
//

#import "XYAlertViewController.h"
#import <XYNavigationController/XYAlertDismiss.h>
#import <XYNavigationController/XYAlertPresent.h>
#import <XYNavigationController/XYPickerPresent.h>
#import <XYNavigationController/XYPickerDismiss.h>

@interface XYAlertViewController ()<UIViewControllerTransitioningDelegate>
@property (nonatomic,strong) UIButton *dismissBtn;
@end

@implementation XYAlertViewController

- (instancetype)init{
    self = [super init];
    if (self) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
    _dismissBtn = [UIButton new];
    _dismissBtn.frame = CGRectMake(100, 100, 100, 100);
    [_dismissBtn setTitle:@"dismiss" forState:UIControlStateNormal];
    [_dismissBtn addTarget:self action:@selector(clickDismissBtn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_dismissBtn];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)clickDismissBtn{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)xy_dismissVC{
    [self dismissViewControllerAnimated:NO completion:nil];
}

#pragma mark - UIViewControllerTransitioningDelegate -
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return ({
        XYAlertPresent *present =  [XYAlertPresent new];
        present.viewSize = CGSizeMake(375, 300);
        present;
    });
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return ({
        XYAlertDismiss *dismiss =  [XYAlertDismiss new];
        dismiss;
    });
}

@end
