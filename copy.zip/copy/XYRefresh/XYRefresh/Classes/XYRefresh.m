//
//  XYRefresh.m
//  Pods-XYRefresh_Example
//
//  Created by henry on 2017/11/6.
//

#import "XYRefresh.h"
#import <MJRefresh/MJRefresh.h>

@implementation XYRefresh

#pragma mark - 添加ScrollView头部刷新
+ (void)addHeaderRefresh:(UIScrollView *)scrollView target:(id)target action:(SEL)action{
    MJRefreshNormalHeader * refreshNormalHeader = [MJRefreshNormalHeader headerWithRefreshingTarget:target refreshingAction:action];
    [self configureHead:refreshNormalHeader];
    scrollView.mj_header = refreshNormalHeader;
}

+(void)addHeaderRefresh:(UIScrollView *)scrollView refreshingBlock:(void (^)())block{
    MJRefreshNormalHeader * refreshNormalHeader = [MJRefreshNormalHeader headerWithRefreshingBlock:block];
    [self configureHead:refreshNormalHeader];
    scrollView.mj_header = refreshNormalHeader;
}

#pragma mark -  配置下啦刷新文本
+ (void)configureHead:(MJRefreshNormalHeader *)refreshNormalHeader{
    // 设置header
    refreshNormalHeader.lastUpdatedTimeLabel.hidden= YES;//如果不隐藏这个会默认 图片在最左边不是在中间
    refreshNormalHeader.stateLabel.hidden = YES;
}

#pragma mark - 移除头部刷先
+(void)removeHeaderRefresh:(UIScrollView *)scrollView{
    scrollView.mj_header = nil;
}

#pragma mark - 刷新头部
+(void)refreshHead:(UIScrollView *)scrollView{
    MJRefreshNormalHeader * refreshHead = (MJRefreshNormalHeader *)scrollView.mj_header;
    [self configureHead:refreshHead];
}

#pragma mark - 添加ScrollView脚部刷新
+(void)addFooterRefresh:(UIScrollView *)scrollView target:(id)target action:(SEL)action{
    MJRefreshAutoNormalFooter * footView = [MJRefreshAutoNormalFooter footerWithRefreshingTarget:target refreshingAction:action];
    [self configureFoot:footView];
    scrollView.mj_footer = footView;
}

+ (void)addFooterRefresh:(UIScrollView *)scrollView refreshingBlock:(void (^)())block{
    MJRefreshAutoNormalFooter * footView = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:block];;
    [self configureFoot:footView];
    scrollView.mj_footer = footView;
}

#pragma mark -  配置上拉加载文本
+ (void)configureFoot:(MJRefreshAutoNormalFooter *)footer{
    footer.refreshingTitleHidden = YES;
    footer.stateLabel.hidden = YES;
    [footer setTitle:@"没有更多数据了~~" forState:MJRefreshStateNoMoreData];
}

#pragma mark - 移除脚部刷新
+(void)removeFooterRefresh:(UIScrollView *)scrollView{
    scrollView.mj_footer = nil;
}

#pragma mark - 开始头部刷新
+ (void)beginHeaderRefresh:(UIScrollView *)scrollView{
    [scrollView.mj_header beginRefreshing];
}

#pragma mark -  开始尾部刷新
+ (void)beginFooterRefresh:(UIScrollView *)scrollView{
    [scrollView.mj_footer beginRefreshing];
}

#pragma mark -  结束头部刷新
+ (void)endHeaderRefresh:(UIScrollView *)scrollView{
    [scrollView.mj_header endRefreshing];
}


#pragma mark - 结束尾部刷新
+ (void)endFooterRefresh:(UIScrollView *)scrollView{
    [scrollView.mj_footer endRefreshing];
}

#pragma mark - 隐藏尾部刷新
+ (void)hideFooterRefresh:(UIScrollView *)scrollView{
    scrollView.mj_footer.hidden = YES;
}

#pragma mark - 隐藏尾部刷新
+ (void)showFooterRefresh:(UIScrollView *)scrollView{
    scrollView.mj_footer.hidden = NO;
}

+(void)setFooterState:(XYRefreshState)state scrollView:(UIScrollView *)scrollView{
    [scrollView.mj_footer setState:(MJRefreshState)state];
    scrollView.bounces = YES;
}

@end
