# XYChatUI

[![CI Status](http://img.shields.io/travis/henry/XYChatUI.svg?style=flat)](https://travis-ci.org/henry/XYChatUI)
[![Version](https://img.shields.io/cocoapods/v/XYChatUI.svg?style=flat)](http://cocoapods.org/pods/XYChatUI)
[![License](https://img.shields.io/cocoapods/l/XYChatUI.svg?style=flat)](http://cocoapods.org/pods/XYChatUI)
[![Platform](https://img.shields.io/cocoapods/p/XYChatUI.svg?style=flat)](http://cocoapods.org/pods/XYChatUI)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYChatUI is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYChatUI'
```

## Author

henry, henry@xy.com

## License

XYChatUI is available under the MIT license. See the LICENSE file for more info.
