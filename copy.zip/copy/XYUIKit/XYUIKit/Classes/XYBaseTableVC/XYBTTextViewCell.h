//
//  XYBTTextViewCell.h
//  MJExtension
//
//  Created by henry on 2017/11/22.
//

#import <UIKit/UIKit.h>

@interface XYBTTextViewCell : UITableViewCell

/**
 标题
 */
@property (nonatomic,strong) UILabel *titleLabel;

/**
 文本输入框
 */
@property (nonatomic,strong) UITextView *textView;

/**
 占位文字
 */
@property (nonatomic,copy) NSString *placeholder;

/**
 文本内容
 */
@property (nonatomic,copy) NSString *text;

/**
 标题
 */
@property (nonatomic,copy) NSString *title;
/**
 边缘距离
 */
@property (nonatomic,assign) CGFloat edgeDistance;

/**
 title 到 titleToTextView的间距
 */
@property (nonatomic,assign) CGFloat titleToTextView;

/**
 文本输入框背景颜色
 */
@property (nonatomic,copy) NSString *textViewBgColor;

/**
 输入框文本字体颜色
 */
@property (nonatomic,copy) NSString *textViewTextColor;

/**
 标题字体颜色
 */
@property (nonatomic,copy) NSString *titleTextColor;

/**
 输入框字体大小
 */
@property (nonatomic,assign) CGFloat titleFontSize;

/**
 输入框字体大小
 */
@property (nonatomic,assign) CGFloat textViewFontSize;
@end
