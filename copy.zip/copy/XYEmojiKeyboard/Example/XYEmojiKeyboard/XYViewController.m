//
//  XYViewController.m
//  XYEmojiKeyboard
//
//  Created by henry on 11/15/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

#import "XYViewController.h"
#import <XYEmojiKeyboard/XYEmojiKeyboard.h>
@interface XYViewController ()<XYEmojiKeyboardDelegate,UIGestureRecognizerDelegate>{
    UITapGestureRecognizer *_tapGestureRecognizer;
}

@end

@implementation XYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    XYEmojiKeyboard *emoji = [[XYEmojiKeyboard alloc]initWithFrame:CGRectMake(0, 20, 0, 0)];
    emoji.delegate = self;
    [self.view addSubview:emoji];
    
    _tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapGestureRecognizer:)];
    _tapGestureRecognizer.delegate = self;
    [self.view addGestureRecognizer:_tapGestureRecognizer];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tapGestureRecognizer:(UITapGestureRecognizer *)tap{
    
}


#pragma mark - XYEmojiKeyboardDelegate -
- (void)emojiKeyboard:(XYEmojiKeyboard *)emojiKeyboard sendEmoji:(NSString *)emoji{
    NSLog(@"%@",emoji);
}

- (void)emojiKeyboardClickSendEvent:(XYEmojiKeyboard *)emojiKeyboard{
    NSLog(@"发送");
}

- (void)emojiKeyboardClickDeleteEvent:(XYEmojiKeyboard *)emojiKeyboard{
    NSLog(@"删除");
}
@end
