//
//  XYChatReviceTextMsgModel.h
//  Pods
//
//  Created by henry on 2018/9/29.
//

#import <Foundation/Foundation.h>

@interface XYChatReviceTextMsgModel : NSObject

@property (nonatomic,copy) NSString *from_mid;
@property (nonatomic,copy) NSString *message_id;
@property (nonatomic,copy) NSString *from_userface;
@property (nonatomic,copy) NSString *from_nickname;
@property (nonatomic,copy) NSString *message;
@property (nonatomic,assign) NSTimeInterval create_time;
@property (nonatomic,assign) NSInteger unread_count;
@end
