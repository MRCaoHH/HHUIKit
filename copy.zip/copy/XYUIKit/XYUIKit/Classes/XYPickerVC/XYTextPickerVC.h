//
//  XYTextPickerVC.h
//  Masonry
//
//  Created by henry on 2018/11/20.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol XYTextPickerVCDelegate;


@interface XYTextPickerVC : UIViewController
@property (nonatomic,weak) id<XYTextPickerVCDelegate> delegate;

/**
 根据代理初始化

 @param delegate 代理
 @return 实例
 */
- (instancetype)initWithDelegate:(id<XYTextPickerVCDelegate>)delegate;

/**
 设置选中的下标

 @param indexPath 下标
 */
- (void)setSelectIndexPath:(NSIndexPath *)indexPath;
@end

@protocol XYTextPickerVCDelegate <NSObject>

@required

/**
 picker的列数

 @param vc XYTextPickerVC
 @return 列数
 */
- (NSInteger)numberOfComponentTextPickerVC:(XYTextPickerVC *)vc;

/**
 picker每列的行数

 @param vc XYTextPickerVC
 @param component 列
 @return 行数
 */
- (NSInteger)textPickerVC:(XYTextPickerVC *)vc numberOfRowsInComponent:(NSInteger)component;


/**
 picker的标题

 @param vc XYTextPickerVC
 @param indexPath 下标
 @return 标题
 */
- (NSString *)textPickerVC:(XYTextPickerVC *)vc titleWithIndex:(NSIndexPath *)indexPath;

/**
 点击确定按钮的时候标题数组

 @param vc 控制器
 @param titles 标题数组
 */
- (void)textPickerVC:(XYTextPickerVC *)vc clickOkWithTitles:(NSArray *)titles;

/**
 是否可以点击确定

 @param vc 控制器
 @param titles 标题
 @return 是否可以提交
 */
- (BOOL)textPickerVC:(XYTextPickerVC *)vc canCommitWithTitles:(NSArray *)titles;

/**
 点击取消按钮

 @param vc 控制器
 */
- (void)clickCancelTextPickerVC:(XYTextPickerVC *)vc;

/**
 选中行

 @param vc 控制器
 @param row 行数
 @param component 块
 */
- (void)textPickerVC:(XYTextPickerVC *)vc didSelectRow:(NSInteger)row inComponent:(NSInteger)component;
@end

NS_ASSUME_NONNULL_END
