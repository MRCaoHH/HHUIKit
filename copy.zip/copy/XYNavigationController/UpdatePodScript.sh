#!/bin/bash

set -e

deleteTag=0
commit=1
release=1
while  getopts  " d:m:r: "  arg #选项后面的冒号表示该选项需要参数
do
case  $arg  in
d)
deleteTag=$OPTARG #是否删除原来tag
;;
m)
commit=$OPTARG
;;
r)
release=$OPTARG
;;
? )  #当有不认识的选项的时候arg为 ?
echo  " unkonw argument "
exit  1
;;
esac
done

podspecName=$(basename $(find . -name *.podspec) | sed 's/.podspec//g' )

version=$(awk '/\.version/' $podspecName.podspec | awk '/[0-9]\.[0-9]\.[0-9]/' | sed 's/.version//g'  | sed 's/[^0-9/.]//g')
describe=$(awk '/\.summary/' $podspecName.podspec | sed "s/\'//g" | sed "s/[a-zA-Z]*.summary//g" | sed "s/=//g")
#echo $podspecName
#echo $describe
#echo $version

if [[ $commit = '1' ]]; then
	git add .
	git commit -m "${describe}"
	git pull
	git push
fi


if [ $deleteTag = '1' ] ; then
    git tag --delete $version
    git push origin --delete tag $version
fi


git tag -a ${version} -m ${version}
git push origin --tags

if [[ $release = '1' ]]; then
	# ${userName}:${password}@
	publicSpecs="https://github.com/CocoaPods/Specs.git"
	privateSpecs="http://pods.xy.com:3000/iOSModule/iOSPod.git"

	#pod repo remove iOSPod LYCache.podspec
	#,http://iOS:123456@192.168.10.224:3000/iOS/iOSPod.git

	pod lib lint  --allow-warnings  --sources=$publicSpecs,$privateSpecs

	pod repo push iOSPod $podspecName.podspec --allow-warnings --sources=$publicSpecs,$privateSpecs

fi
