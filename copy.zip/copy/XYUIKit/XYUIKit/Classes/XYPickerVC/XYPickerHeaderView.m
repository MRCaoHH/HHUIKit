//
//  XYPickerHeaderView.m
//  XYUIKit
//
//  Created by henry on 2017/12/23.
//

#import "XYPickerHeaderView.h"

@implementation XYPickerHeaderView

- (instancetype)init{
    self = [super initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, kXYPickerHeaderViewHeight)];
    if (self) {
        [self initSubview];
    }
    return self;
}

- (void)initSubview{
    CGFloat btnWidth = 60;
    CGFloat btnToEdge = 5;
    CGFloat btnHeight = self.frame.size.height - btnToEdge - btnToEdge;
    _cancelButton = [[UIButton alloc]initWithFrame:CGRectMake(btnToEdge, btnToEdge, btnWidth, btnHeight)];
    [_cancelButton addTarget:self action:@selector(clickCancelBtn) forControlEvents:UIControlEventTouchUpInside];
    [_cancelButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [_cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    _cancelButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self addSubview:_cancelButton];
    
    CGFloat titleWidth = self.frame.size.width - btnWidth - btnWidth - btnToEdge - btnToEdge;
    _titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_cancelButton.frame), 0, titleWidth, self.frame.size.height)];
    _titleLabel.textColor  = [UIColor blackColor];
    _titleLabel.font = [UIFont systemFontOfSize:15];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.hidden = YES;
    [self addSubview:_titleLabel];
    
    _okButton = [[UIButton alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_titleLabel.frame), btnToEdge, btnWidth, btnHeight)];
    [_okButton addTarget:self action:@selector(clickOkBtn) forControlEvents:UIControlEventTouchUpInside];
    [_okButton setTitle:@"确定" forState:UIControlStateNormal];
    [_okButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    _okButton.titleLabel.font = [UIFont systemFontOfSize:15];
    [self addSubview:_okButton];
}

- (void)clickCancelBtn{
    if ([self.delegate respondsToSelector:@selector(clickCancelButtonEvent)]) {
        [self.delegate clickCancelButtonEvent];
    }
}

- (void)clickOkBtn{
    if ([self.delegate respondsToSelector:@selector(clickOkButtonEvent)]) {
        [self.delegate clickOkButtonEvent];
    }
}

@end
