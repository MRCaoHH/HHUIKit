//
//  XYLineChartView.m
//  Masonry
//
//  Created by henry on 2018/9/12.
//

#import "XYLineChartView.h"

@interface XYLineChartView()<UIScrollViewDelegate>

/**
 内容偏移
 */
//@property (nonatomic,assign) CGPoint contentOffset;
/**
 上一个点
 */
@property (nonatomic,assign) CGPoint prePoint;

/**
 y轴最大刻度值
 */
@property (nonatomic,assign) CGFloat yAxisMaxValue;
@end

@implementation XYLineChartView

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.delegate = self;
        self.bounces = NO;
        self.firstPointOffset = 20;
        self.lineWidth = 1.0/[UIScreen mainScreen].scale;
        self.showsHorizontalScrollIndicator = NO;
    }
    return self;
}

- (void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    NSInteger pointCount = rect.size.width / self.fixInterval;
    pointCount +=2;
    NSInteger maxPoint = [self.dataSource lineChartView:self lineIndex:0];
    pointCount = maxPoint > pointCount?pointCount:maxPoint;
    NSInteger startIndex = self.contentOffset.x/self.fixInterval;
    if (startIndex > 0) {
        startIndex -= 1;
    }
    if (startIndex <0) {
        startIndex = 0;
    }
    
    NSInteger endIndex = (self.contentOffset.x + rect.size.width) /self.fixInterval;
    if (endIndex < maxPoint - 1) {
        endIndex += 1;
    }
    
    if (endIndex >= [self.dataSource lineChartView:self lineIndex:0]) {
        endIndex = [self.dataSource lineChartView:self lineIndex:0];
    }
    
    NSInteger len =  endIndex - startIndex;
    if (len + startIndex + 1 <= [self.dataSource lineChartView:self lineIndex:0]) {
        len += 1;
    }
    NSRange range = NSMakeRange(startIndex, len);
    
    CGFloat maxFloat =  0;
    for (NSInteger index = 0; index < range.length; index ++) {
        CGFloat yValue =  [self.dataSource lineChartView:self yAxisNumWithIndexPath:[NSIndexPath indexPathForRow:index + range.location inSection:0]];
        if (maxFloat < yValue) {
            maxFloat = yValue;
            
        }
    }
    
    maxFloat = maxFloat * 1.1;
    self.yAxisMaxValue = maxFloat;
    
    ///绘制填充区域
    [self drawRectPoint:rect range:range];
    ///绘制x轴
    [self drawXAxis:rect range:range];
    ///绘制y轴
    [self drawYAxis:rect range:range];
    
}

- (void)drawXAxis:(CGRect)rect range:(NSRange)range{
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con,YES);
    
    ///绘制背景
    [self drawRect:con rect:CGRectMake(0, self.bounds.size.height - self.xAxisToBottomOffset, self.bounds.size.width, self.xAxisToBottomOffset) color:self.backgroundColor];
    
    //绘制x轴
    [self.xAxisColor set];
    CGFloat xAxisWidth  = self.lineWidth;
    CGContextSetLineWidth(con, xAxisWidth);
    CGFloat x = self.yAxisToLeftOffset;
    CGFloat y = CGRectGetMaxY(self.bounds) - self.yAxisToLeftOffset;
    CGContextMoveToPoint(con, x, y - xAxisWidth);
    CGContextAddLineToPoint(con, CGRectGetMaxX(self.bounds), y - xAxisWidth);
    CGContextStrokePath(con);
    
    //线标
    for (NSInteger index = 0; index < range.length; index ++) {
        //第一个点不在y轴上
        CGFloat pointX = (index + range.location) * self.fixInterval + self.yAxisToLeftOffset + self.firstPointOffset;
        if(pointX < self.yAxisToLeftOffset){
            continue;
        }
        [self.xAxisColor set];
        CGContextMoveToPoint(con, pointX, y - xAxisWidth - 5);
        CGContextAddLineToPoint(con, pointX, y - xAxisWidth);
        CGContextStrokePath(con);
        
        CGRect titleRect = CGRectMake(pointX - self.fixInterval/2,y, self.fixInterval, self.xAxisToBottomOffset);
        NSString *title  = [self.dataSource lineChartView:self xAxisTitlewithIndexPath:[NSIndexPath indexPathForRow:index + range.location inSection:0]];
        [self drawTextWithText:title rect:titleRect font:self.xAxisTitleFont textColor:self.xAxisTitleColor];
    }
    
}

- (void)drawYAxis:(CGRect)rect range:(NSRange)range{
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con,YES);
    
    ///绘制背景
    [self drawRect:con rect:CGRectMake(self.contentOffset.x, 0, self.yAxisToLeftOffset, self.bounds.size.height) color:self.backgroundColor];
    
    //绘制x轴
    [self.yAxisColor set];
    CGFloat yAxisWidth  = self.lineWidth;
    CGContextSetLineWidth(con, yAxisWidth);
    CGFloat x = self.yAxisToLeftOffset + self.contentOffset.x;
    CGFloat y = CGRectGetMaxY(self.bounds) - self.yAxisToLeftOffset;
    CGContextMoveToPoint(con, x, y - yAxisWidth);
    CGContextAddLineToPoint(con, x, 0);
    CGContextStrokePath(con);
    
    CGFloat maxFloat = self.yAxisMaxValue;
    NSInteger pointNum = (self.bounds.size.height - self.xAxisToBottomOffset)/self.fixInterval;
    
    CGFloat value = 0;
    if (maxFloat >0) {
        value = maxFloat/pointNum;
    }
    
    
    CGFloat spa = (self.bounds.size.height - self.xAxisToBottomOffset)/pointNum;
    
    for (int i = 0; i < pointNum; i++) {
        if (i == 0 ) {
            continue;
        }
        
        CGFloat pointY = spa * i;
        
        CGRect titleRect = CGRectMake(x - self.yAxisToLeftOffset, pointY - spa/2, self.yAxisToLeftOffset, spa);
        [self drawTextWithText:[NSString stringWithFormat:@"%0.2f",value * (pointNum -i)] rect:titleRect font:self.yAxisTitleFont textColor:self.yAxisTitleColor];
        
        [self.yAxisColor set];
        CGContextMoveToPoint(con, x,pointY);
        CGContextAddLineToPoint(con, x + 5, pointY);
        CGContextStrokePath(con);
    }
    
    
    
}


#pragma mark - 打点
- (void)drawRectPoint:(CGRect)rect range:(NSRange)range{
    if (range.length == 0) {
        return;
    }
    
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con,YES);
    
    CGFloat yAxisHeight = self.bounds.size.height - self.xAxisToBottomOffset;
    
    CGPoint points[range.length];
    for (NSInteger i = 0; i < range.length; i ++) {
        //第一个点不在y轴上
        CGFloat x = (i + range.location) * self.fixInterval + self.yAxisToLeftOffset + self.firstPointOffset;
        CGFloat y = [self.dataSource lineChartView:self yAxisNumWithIndexPath:[NSIndexPath indexPathForRow:i + range.location inSection:0]];
        y =  yAxisHeight - (y/self.yAxisMaxValue) * yAxisHeight;
        CGPoint point = CGPointMake(x, y );
        points[i] = point;
    }
    
    CGFloat y = CGRectGetMaxY(self.bounds) - self.yAxisToLeftOffset;
    
    CGFloat yAxisWidth  = self.lineWidth;
    [self.fillColor set];
    UIBezierPath *bezierPath = [UIBezierPath bezierPath];
    bezierPath.lineWidth = yAxisWidth;              //设置线条宽度
    for (int i = 0; i < range.length; i++) {
        if (i == 0) {
            CGPoint curPoint = points[i];
            [bezierPath moveToPoint:CGPointMake(curPoint.x, y)];
        }
        
        [bezierPath addLineToPoint:points[i]];
        
        if (i == range.length - 1 ) {
            CGPoint curPoint = points[i];
            [bezierPath addLineToPoint:CGPointMake(curPoint.x, y)];
            //            [bezierPath addLineToPoint:CGPointMake(x, y - yAxisWidth)];
        }
    }
    
    //关闭路径
    [bezierPath closePath];
    //根据坐标连线
    [bezierPath stroke];
    [bezierPath fill];
    
    //    CGFloat titleHeight = s
    
    for (int i = 0; i < range.length; i++) {
        CGPoint curPoint = points[i];
        CGRect ellipseFrame = CGRectMake(curPoint.x - 2.5, curPoint.y - 2.5, 5, 5);
        CGContextAddEllipseInRect(con, ellipseFrame);
        [self.pointColor set];
        CGContextFillPath(con);
        
        NSString *title = [[self.dataSource lineChartView:self yAxisTitlewithIndexPath:[NSIndexPath indexPathForRow:i+range.location inSection:0]] description];
        [self drawPointTitleWithTitle:title point:curPoint];
    }
    
}

#pragma mark - 绘制文本
- (void)drawPointTitleWithTitle:(NSString *)text point:(CGPoint)point{
    NSDictionary *attributesDic = @{NSFontAttributeName:self.pointTitleFont,NSForegroundColorAttributeName :self.pointTitleColor};
    CGSize size = [text sizeWithAttributes:attributesDic];
    CGRect rect = CGRectMake(point.x - size.width/2, point.y - 5 - size.height, size.width, size.height);
    [text drawInRect:rect withAttributes:attributesDic];
}

- (void)drawTextWithText:(NSString *)text rect:(CGRect)rect font:(UIFont *)font textColor:(UIColor *)textColor{
    NSDictionary *attributesDic = @{NSFontAttributeName:font,NSForegroundColorAttributeName :textColor};
    CGRect actualRect =  [text boundingRectWithSize:rect.size options:NSStringDrawingUsesLineFragmentOrigin attributes:attributesDic context:NULL];
    rect.origin.y += (rect.size.height - actualRect.size.height)/2;
    rect.origin.x += (rect.size.width - actualRect.size.width)/2;
    [text drawInRect:rect withAttributes:@{NSFontAttributeName:font,NSForegroundColorAttributeName:textColor}];
}


- (void)drawRect:(CGContextRef)con rect:(CGRect)rect color:(UIColor *)color{
    CGContextAddRect(con, rect);
    [color set];
    CGContextFillPath(con);
}

#pragma mark - 重新加载数据
- (void)reloadData{
    NSInteger count = [self.dataSource lineChartView:self lineIndex:0];
    CGFloat width = count * self.fixInterval + self.yAxisToLeftOffset;
    self.contentSize = CGSizeMake(width, self.bounds.size.height);
    [self setNeedsDisplay];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self setNeedsDisplay];
}

#pragma mark - 属性方法
- (UIColor *)lineColor{
    if (_lineColor == nil) {
        _lineColor = [UIColor redColor];
    }
    return _lineColor;
}

- (UIColor *)fillColor{
    if (_fillColor == nil) {
        _fillColor = [UIColor yellowColor];
    }
    return _fillColor;
}

- (UIColor *)xAxisColor{
    if (_xAxisColor == nil) {
        _xAxisColor = [UIColor greenColor];
    }
    return _xAxisColor;
}

- (UIColor *)yAxisColor{
    if (_yAxisColor == nil) {
        _yAxisColor = [UIColor greenColor];
    }
    return _yAxisColor;
}

- (UIColor *)pointTitleColor{
    if (_pointTitleColor == nil) {
        _pointTitleColor = [UIColor blackColor];
    }
    return _pointTitleColor;
}

- (UIColor *)xAxisTitleColor{
    if (_xAxisTitleColor == nil) {
        _xAxisTitleColor = [UIColor blackColor];
    }
    return _xAxisTitleColor;
}

- (UIColor *)yAxisTitleColor{
    if (_yAxisTitleColor == nil) {
        _yAxisTitleColor = [UIColor blackColor];
    }
    return _yAxisTitleColor;
}

- (CGFloat)fixInterval{
    if (_fixInterval <= 0) {
        _fixInterval = 40;
    }
    return _fixInterval;
}

- (UIFont *)xAxisTitleFont{
    if (_xAxisTitleFont == nil) {
        _xAxisTitleFont = [UIFont systemFontOfSize:14];
    }
    return _xAxisTitleFont;
}

- (UIFont *)yAxisTitleFont{
    if (_yAxisTitleFont == nil) {
        _yAxisTitleFont = [UIFont systemFontOfSize:14];
    }
    return _yAxisTitleFont;
}

- (UIColor *)pointColor{
    if (_pointColor == nil) {
        _pointColor = [UIColor redColor];
    }
    return _pointColor;
}

- (UIFont *)pointTitleFont{
    if (_pointTitleFont == nil) {
        _pointTitleFont = [UIFont systemFontOfSize:14];
    }
    return _pointTitleFont;
}
@end
