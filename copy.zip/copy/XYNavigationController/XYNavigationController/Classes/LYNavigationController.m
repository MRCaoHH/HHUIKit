//
//  NavigationController.m
//  Pods
//
//  Created by caohuihui on 2017/10/29.
//
//

#import "XYNavigationController.h"
#import "UIViewController+XYNavBar.h"

@interface XYNavigationController ()<UINavigationControllerDelegate,UIGestureRecognizerDelegate>

@end

@implementation XYNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.delegate = self;
    self.interactivePopGestureRecognizer.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc{
    NSLog(@"");
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    viewController.hidesBottomBarWhenPushed = [self.viewControllers count] > 0;
    [super pushViewController:viewController animated:YES];
}

- (nullable UIViewController *)childViewControllerForStatusBarStyle{
    if (self.visibleViewController.presentingViewController) {
        return self.topViewController;
    }
    return self.visibleViewController;
}

- (nullable UIViewController *)childViewControllerForStatusBarHidden{
    if (self.visibleViewController.presentingViewController) {
        return self.topViewController;
    }
    return self.visibleViewController;
}

#pragma mark - Touch event
- (void)clickBackItemEvent{
    [self popViewControllerAnimated:YES];
}

#pragma mark - UINavigationControllerDelegate
- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    [self setNavigationBarHidden:viewController.xy_hiddenNarBar animated:YES];
    [self initBackItem:navigationController.topViewController];
}

- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated{
    [self setNavigationBarHidden:viewController.xy_hiddenNarBar animated:YES];
    if (viewController.xy_disablePopGestureRecognizer) {
        self.interactivePopGestureRecognizer.enabled = NO;
        return;
    }
    self.interactivePopGestureRecognizer.enabled = navigationController.childViewControllers.count > 1;
}

- (void)initBackItem:(UIViewController *)vc{
    
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:self action:@selector(clickBackItemEvent)];
    
    vc.navigationItem.backBarButtonItem = backItem;
}


@end
