//
//  UIViewController+LYNavBar.h
//  HHNavBarDemo
//
//  Created by caohuihui on 2017/10/29..
//  Copyright © 2017年 caohuihui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (XYNavBar)
@property (nonatomic, assign) BOOL xy_hiddenNarBar;
@property (nonatomic,assign) BOOL xy_disablePopGestureRecognizer;
@end
