//
//  XYDatePickerVC.h
//  XYUIKit
//
//  Created by henry on 2017/12/26.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,XYDatePickerType) {
    XYDatePickerType_YYYYMMDD = 0,//年月日
    XYDatePickerType_MMDD = 1,//月日,默认2月29天
    XYDatePickerType_HHmmss = 2,//时分秒，24小时制
    XYDatePickerType_hhmmss = 3,//时分秒，12小时制
    XYDatePickerType_HHmm = 4,//时分秒，24小时制
    XYDatePickerType_hhmm = 5,//时分秒，12小时制
};

typedef struct {
    int year;//年
    int month;//月
    int day;//日
    int hour;//时
    int min;//分
    int second;//秒
}XYDateStruct;

#define XYDateStructIsZone(date) \
({\
BOOL isZone = NO;\
if(date.year == 0 && date.month == 0 && date.day == 0 && date.hour == 0 && date.min == 0 && date.second == 0){\
isZone = YES;\
}\
isZone;\
})

@protocol XYDatePickerVCDelegate;

@interface XYDatePickerVC : UIViewController

/**
 类型
 */
@property (nonatomic,assign,readonly) XYDatePickerType type;

/**
 最小日期
 */
@property (nonatomic,strong,readonly) NSDate *minDate;

/**
 最大日期
 */
@property (nonatomic,strong,readonly) NSDate *maxDate;

/**
 代理
 */
@property (nonatomic,weak) id<XYDatePickerVCDelegate> delegate;

/**
 初始化1900年到今天的选择器

 @param type 类型
 @return 实例
 */
- (instancetype)init1900ToTodayPicker:(XYDatePickerType)type;

/**
 根据类型、最大日期、最小日期初始化

 @param type 类型
 @param minDate 最小日期
 @param maxDate 最大日期
 @return 实例
 */
- (instancetype)initWithType:(XYDatePickerType)type minDate:(NSDate *)minDate maxDate:(NSDate *)maxDate;

/**
 选中日期

 @param date 日期
 */
- (void)selectDate:(XYDateStruct)date;
@end


@protocol XYDatePickerVCDelegate<NSObject>
@optional

/**
 标题准备改变
 
 @param datePickerVC 选择控制器
 @param title 新标题
 */
- (void)datePickerVC:(XYDatePickerVC *)datePickerVC  titleDidChange:(NSString *)title;


/**
 点击确认按钮
 
 @param datePickerVC 选择控制器
 @param year 年
 @param month 月
 @param day 日
 @param hour 小时
 @param min 分
 @param second 秒
 */
- (void)datePickerVC:(XYDatePickerVC *)datePickerVC year:(NSString *)year month:(NSString *)month day:(NSString *)day  hour:(NSString *)hour min:(NSString *)min second:(NSString *)second;

/**
 点击取消按钮
 
 @param pickerVC 选择视图
 */
- (void)pickerVCDidClickCancelBtn:(XYDatePickerVC *)pickerVC ;

@end
