//
//  XYArchiverTool.m
//  XYLawyerPlatform
//
//  Created by caohuihui on 2017/10/27.
//  Copyright © 2016年 华海乐盈. All rights reserved.
//

#import "XYArchiverTool.h"
#import <objc/runtime.h>

@implementation XYArchiverTool
#pragma mark - 归档
+ (void)archiver:(NSCoder *)encoder object:(id)object{
    return [self archiver:encoder object:object superArr:nil filter:nil];
}

+ (void)archiver:(NSCoder *)encoder object:(id)object superArr:(NSArray<NSString *>*)superArr{
    return [self archiver:encoder object:object superArr:superArr filter:nil];
}

+ (void)archiver:(NSCoder *)encoder object:(id)object filter:(NSArray *)filter{
    return [self archiver:encoder object:object superArr:nil filter:filter];
}

+ (void)archiver:(NSCoder *)encoder object:(id)object superArr:(NSArray<NSString *>*)superArr filter:(NSArray *)filter{
    NSMutableArray *proList = [[NSMutableArray alloc]init];
    NSArray *objectProList = [self propertyList:[object class]];
    [proList addObjectsFromArray:objectProList];
    for (NSString *className in superArr) {
        Class aclass = NSClassFromString(className);
        if (aclass) {
            [proList addObjectsFromArray:[self propertyList:aclass]];
        }
    }
    
    [proList removeObjectsInArray:filter];
    
    for (NSString *proName in proList) {
        [encoder encodeObject:[object valueForKey:proName] forKey:proName];
    }
}

#pragma mark - 解档
+ (void)unarchiver:(NSCoder *)decoder object:(id)object{
    return [self unarchiver:decoder object:object superArr:nil filter:nil];
}

+ (void)unarchiver:(NSCoder *)decoder object:(id)object superArr:(NSArray<NSString *>*)superArr{
    return [self unarchiver:decoder object:object superArr:superArr filter:nil];
}

+ (void)unarchiver:(NSCoder *)decoder object:(id)object filter:(NSArray *)filter{
    return [self unarchiver:decoder object:object superArr:nil filter:filter];
}

+ (void)unarchiver:(NSCoder *)decoder object:(id)object superArr:(NSArray<NSString *>*)superArr filter:(NSArray *)filter{
    NSMutableArray *proList = [[NSMutableArray alloc]init];
    NSArray *objectProList = [self propertyList:[object class]];
    [proList addObjectsFromArray:objectProList];
    for (NSString *className in superArr) {
        Class aclass = NSClassFromString(className);
        if (aclass) {
            [proList addObjectsFromArray:[self propertyList:aclass]];
        }
    }
    
    [proList removeObjectsInArray:filter];
    for (NSString *proName in proList) {
        if ([decoder containsValueForKey:proName]) {
            [object setValue:[decoder decodeObjectForKey:proName] forKey:proName];
        }
    }
}

#pragma mark - runtime
+ (NSArray *)propertyList:(Class)aclass{
    NSMutableArray *proList = [[NSMutableArray alloc]init];
    unsigned int  outCount;
    objc_property_t * propertyList =   class_copyPropertyList(aclass, &outCount);
    for (int i = 0; i<outCount; i++) {
        NSString * string = [NSString stringWithCString:property_getName(propertyList[i]) encoding:NSUTF8StringEncoding];
        [proList addObject:string];
    }
    free(propertyList);
    return proList;
}
@end
