//
//  XYArchiverModel.h
//  XYCacheDemo
//
//  Created by caohuihui on 2017/10/27.
//  Copyright © 2017年 caohuihui. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYArchiverModel : NSObject<NSCoding>

@end
