//
//  XYHUD.m
//  Pods-XYHUD_Example
//
//  Created by henry on 2017/11/13.
//

#import "XYHUD.h"
#import <SVProgressHUD/SVProgressHUD.h>
@implementation XYHUD

+ (void)load{
    [SVProgressHUD setMinimumDismissTimeInterval:1];
    [SVProgressHUD setMaximumDismissTimeInterval:2];
}

+ (void)show{
    [SVProgressHUD show];
}

+ (void)dismiss{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // time-consuming task
        dispatch_async(dispatch_get_main_queue(), ^{
            [SVProgressHUD dismiss];
        });
    });
}

+ (void)dismissWithDelay:(NSTimeInterval)delay{
    [SVProgressHUD dismissWithDelay:delay];
}

+ (void)showWithStatus:(NSString*)string{
    [SVProgressHUD showWithStatus:string.length>0?string:nil];
}

+ (void)showInfoWithStatus:(NSString*)string{
    [SVProgressHUD showInfoWithStatus:string.length>0?string:nil];
}

+ (void)showSuccessWithStatus:(NSString*)string{
    [SVProgressHUD showSuccessWithStatus:string.length>0?string:nil];
}

+ (void)showErrorWithStatus:(NSString*)string{
    [SVProgressHUD showErrorWithStatus:string.length>0?string:nil];
}

+ (void)showImage:(UIImage*)image status:(NSString*)string{
    [SVProgressHUD showImage:image status:string.length>0?string:nil];
}

@end
