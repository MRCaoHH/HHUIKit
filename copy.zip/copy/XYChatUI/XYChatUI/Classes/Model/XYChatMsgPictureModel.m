//
//  XYChatMsgPictureModel.m
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import "XYChatMsgPictureModel.h"

@implementation XYChatMsgPictureModel

@end
