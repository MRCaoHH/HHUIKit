//
//  XYBTCellConfig.m
//  Pods-XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//

#import "XYBTCellConfig.h"

@implementation XYBTCellConfig

@end
