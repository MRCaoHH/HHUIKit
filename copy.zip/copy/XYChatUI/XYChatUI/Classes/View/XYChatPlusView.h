//
//  XYChatPlusView.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/16.
//

#import <UIKit/UIKit.h>
@protocol XYChatPlusViewDelegate;
@class XYChatPlusItem;
@interface XYChatPlusView : UIView
@property (nonatomic,strong) NSArray *itemList;
@property (nonatomic,weak) id<XYChatPlusViewDelegate> delegate;
@end


@protocol XYChatPlusViewDelegate <NSObject>
@optional
- (void)plusView:(XYChatPlusView *)plusViwe didSelectItem:(XYChatPlusItem *)items;
@end
