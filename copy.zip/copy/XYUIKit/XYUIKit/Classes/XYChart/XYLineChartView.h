//
//  XYLineChartView.h
//  Masonry
//
//  Created by henry on 2018/9/12.
//

#import <UIKit/UIKit.h>

@protocol XYLineChartViewDataSource;

@interface XYLineChartView : UIScrollView

@property (nonatomic,strong) UIColor *lineColor;
@property (nonatomic,strong) UIColor *fillColor;
@property (nonatomic,strong) UIColor *xAxisColor;
@property (nonatomic,strong) UIColor *yAxisColor;
@property (nonatomic,strong) UIColor *xAxisTitleColor;
@property (nonatomic,strong) UIColor *yAxisTitleColor;
@property (nonatomic,strong) UIFont *yAxisTitleFont;
@property (nonatomic,strong) UIFont *xAxisTitleFont;
@property (nonatomic,assign) CGFloat firstPointOffset;
@property (nonatomic,strong) UIColor *pointColor;
@property (nonatomic,strong) UIColor *pointTitleColor;
@property (nonatomic,strong) UIFont *pointTitleFont;
@property (nonatomic,assign) CGFloat lineWidth;
/**
 固定间隔
 */
@property (nonatomic,assign) CGFloat fixInterval;

/**
 x轴到底部的间隔
 */
@property (nonatomic,assign) CGFloat xAxisToBottomOffset;

/**
 y轴到左边的间隔
 */
@property (nonatomic,assign) CGFloat yAxisToLeftOffset;
/**
 数据源
 */
@property (nonatomic,weak) id<XYLineChartViewDataSource> dataSource;

/**
 重新加载数据
 */
- (void)reloadData;
@end


@protocol XYLineChartViewDataSource<NSObject>
@required

/**
 折线图点数
 
 @param liveChartView 折线图
 @return 点数
 */
- (NSInteger)lineChartViewLineCount:(XYLineChartView *)liveChartView;

/**
 每条上点的个数
 
 @param liveChartView 这些图
 @param lineIndex 线的下标
 @return 点的个数
 */
- (NSInteger)lineChartView:(XYLineChartView *)liveChartView lineIndex:(NSInteger)lineIndex;

/**
 折线图x轴标题
 
 @param liveChartView 折线图
 @param indexPath 下标
 @return x标题
 */
- (NSString *)lineChartView:(XYLineChartView *)liveChartView xAxisTitlewithIndexPath:(NSIndexPath *)indexPath;

/**
 折线图x轴的数值
 
 @param liveChartView 折线图
 @param indexPath 下标
 @return x轴数值
 */
- (CGFloat)lineChartView:(XYLineChartView *)liveChartView xAxisNumWithIndexPath:(NSIndexPath *)indexPath;

/**
 折线图y轴坐标
 
 @param liveChartView 折线图
 @param indexPath 下标
 @return y标题
 */
- (NSString *)lineChartView:(XYLineChartView *)liveChartView yAxisTitlewithIndexPath:(NSIndexPath *)indexPath;

/**
 折线图y轴数值
 
 @param liveChartView 折线图
 @param indexPath 下标
 @return y轴数值
 */
- (CGFloat)lineChartView:(XYLineChartView *)liveChartView yAxisNumWithIndexPath:(NSIndexPath *)indexPath;

@end
