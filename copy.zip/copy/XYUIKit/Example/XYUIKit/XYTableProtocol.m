//
//  XYTableProtocol.m
//  XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//  Copyright © 2017年 blackman. All rights reserved.
//

#import "XYTableProtocol.h"
#import <XYUIKit/XYTextVC.h>
#import <XYUIKit/XYBaseTableVC.h>
#import <XYUIKit/XYBTCellConfig.h>
#import <XYExtension/XYExtension.h>

@implementation XYTableProtocol
@synthesize vc = _vc;
- (instancetype)init{
    self = [super init];
    if (self) {
        [self addNotification];
    }
    return self;
}

- (void)clickTextCell{
    NSLog(@"点击文本cell");
    XYTextVC *textVC = [XYTextVC new];
    textVC.placeholder = @"姓名";
    textVC.textViewHeight = 40;
    textVC.text = @"李四";
    [textVC setFinishCallback:^(XYTextVC *textVC, NSString *content) {
        [textVC.navigationController popViewControllerAnimated:YES];
    }];
    [self.vc.navigationController pushViewController:textVC animated:YES];
}

- (void)clickImgCell{
    NSLog(@"点击图片cell");
}

- (NSArray *)configArr{
    if (_configArr == nil) {
        NSString *path = [[NSBundle mainBundle]pathForResource:@"XYBaseTableConfig" ofType:@"plist"];
        NSArray *arr = [[NSArray alloc]initWithContentsOfFile:path];
        arr = [XYBTCellConfig xy_objectArrayWithKeyValuesArray:arr];
        _configArr = arr;
    }
    return _configArr;
}


- (void)addNotification{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(changeSwithValue:) name:@"XYLMSwitchNotification" object:nil];
}

- (void)changeSwithValue:(NSNotification *)notification{
    NSLog(@"%@",notification.object);
    
}

@end
