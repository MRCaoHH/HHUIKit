//
//  XYProgressView.h
//  Masonry
//
//  Created by henry on 2018/8/26.
//

#import <UIKit/UIKit.h>

@protocol XYProgressViewDelegate;

@interface XYProgressView : UIView


/**
 进度条进度
 */
@property (nonatomic,assign) CGFloat progress;

/**
 显示进度
 */
@property (nonatomic,copy) NSString *displayerProgress;

/**
 显示最大进度
 */
@property (nonatomic,copy) NSString *displayerMaxProgress;

/**
 背景颜色
 */
@property (nonatomic,strong) UIColor *bgColor;

/**
 进度颜色
 */
@property (nonatomic,strong) UIColor *progressColor;

/**
 进度字体
 */
@property (nonatomic,strong) UIFont *displayerFont;

/**
 显示字体颜色
 */
@property (nonatomic,strong) UIColor *displayerFontColor;

/**
 最大进度字体
 */
@property (nonatomic,strong) UIColor *displayerMaxFontColor;

/**
 是否手动调节,暂时不具备此功能
 */
@property (nonatomic,assign) BOOL isTouch;

/**
 协议
 */
@property (nonatomic,weak) id<XYProgressViewDelegate> delegate;
@end

@protocol XYProgressViewDelegate<NSObject>
@optional

/**
 拖动进度条更新进度回调

 @param progressView 进度视图
 @param progress 进度
 */
- (void)dragProgressEvent:(XYProgressView *)progressView progress:(CGFloat)progress;
@end
