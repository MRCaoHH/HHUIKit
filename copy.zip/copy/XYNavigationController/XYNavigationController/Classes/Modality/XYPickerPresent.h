//
//  XYPickerPresent.h
//  XYNavigationController
//
//  Created by henry on 2017/12/23.
//

#import <Foundation/Foundation.h>

@interface XYPickerPresent : NSObject <UIViewControllerAnimatedTransitioning>
/**
 视图大小
 */
@property (nonatomic, assign) CGSize viewSize;

/**
 动画时长 默认0.2秒
 */
@property (nonatomic,assign) NSTimeInterval duration;

/**
 背景遮罩颜色 默认 [[UIColor blackColor] colorWithAlphaComponent:0.2]
 */
@property (nonatomic,strong) UIColor *bgColor;

@end
