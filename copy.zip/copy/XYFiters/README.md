# XYFiters

[![CI Status](http://img.shields.io/travis/henry/XYFiters.svg?style=flat)](https://travis-ci.org/henry/XYFiters)
[![Version](https://img.shields.io/cocoapods/v/XYFiters.svg?style=flat)](http://cocoapods.org/pods/XYFiters)
[![License](https://img.shields.io/cocoapods/l/XYFiters.svg?style=flat)](http://cocoapods.org/pods/XYFiters)
[![Platform](https://img.shields.io/cocoapods/p/XYFiters.svg?style=flat)](http://cocoapods.org/pods/XYFiters)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYFiters is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYFiters'
```

## Author

henry, henry@xy.com

## License

XYFiters is available under the MIT license. See the LICENSE file for more info.
