//
//  XYChatPlusView.m
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/16.
//

#import "XYChatPlusView.h"
#import <XYMacro/XYMacro_Key.h>
#import "XYChatPlusCell.h"
#import <XYCategory/XYCategory.h>
#import "XYChatPlusItem.h"

static NSInteger kColumnCount = 4;
static NSInteger kRowCount = 2;
static NSString *kReuseIdentifier = @"kReuseIdentifier";
static NSInteger kCellWidth = 60;
static NSInteger kCellHeight = 100;
static CGFloat kEdgeToTop =  15;

@interface XYChatCollectionFlowLayout: UICollectionViewFlowLayout
@end

@implementation XYChatCollectionFlowLayout
- (NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect{
    
    NSArray *attArr = [super layoutAttributesForElementsInRect:rect];
    
    for (UICollectionViewLayoutAttributes* att in attArr) {
        CGSize size = att.size;
        NSInteger page = att.indexPath.section;
        CGFloat x = (att.indexPath.row % kColumnCount) * size.width + page * self.collectionView.frame.size.width;
        CGFloat y = ((att.indexPath.row / kColumnCount) % kRowCount) * size.height;
        CGRect frame = att.frame;
        frame.origin.x = x;
        frame.origin.y = y;
        att.frame = frame;
    }
    
    return attArr;
}
@end

@interface XYChatPlusView()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (nonatomic,strong) UICollectionView *collectionView;;
@end

@implementation XYChatPlusView

- (instancetype)init{
    self = [super init];
    if (self) {
        [self initSubview];
    }
    return self;
}

- (void)initSubview{
    CGFloat leftEdge = (XYScreen_Width -  kCellWidth * kColumnCount)/(kColumnCount+1);
    
    UICollectionViewFlowLayout *flowLayout = [UICollectionViewFlowLayout new];
    flowLayout.sectionInset = UIEdgeInsetsMake(kEdgeToTop, leftEdge, -(kEdgeToTop), -leftEdge) ;
    flowLayout.minimumInteritemSpacing = leftEdge;
    flowLayout.minimumLineSpacing = 0;
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, XYScreen_Width, kEdgeToTop*2 + kCellHeight * kRowCount ) collectionViewLayout:flowLayout];
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    [_collectionView registerClass:[XYChatPlusCell class] forCellWithReuseIdentifier:kReuseIdentifier];
    _collectionView.backgroundColor = [UIColor xy_colorWithHexString:@"#F5F5F6"];
    [self addSubview:_collectionView];
    
    CGRect frame = self.frame;
    frame.size = _collectionView.frame.size;
    self.frame = frame;
}

#pragma mark - 协议 -
#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [self.itemList count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    XYChatPlusCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kReuseIdentifier forIndexPath:indexPath];
    XYChatPlusItem *item = self.itemList[indexPath.row];
    cell.item = item;
    return cell;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if ([self.delegate respondsToSelector:@selector(plusView:didSelectItem:)]) {
        XYChatPlusItem *item = self.itemList[indexPath.row];
        [self.delegate plusView:self didSelectItem:item];
    }
    
}


@end
