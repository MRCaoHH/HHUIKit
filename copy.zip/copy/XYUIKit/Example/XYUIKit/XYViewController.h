//
//  XYViewController.h
//  XYUIKit
//
//  Created by blackman on 11/03/2017.
//  Copyright (c) 2017 blackman. All rights reserved.
//

@import UIKit;

@interface XYViewController : UIViewController

@end
