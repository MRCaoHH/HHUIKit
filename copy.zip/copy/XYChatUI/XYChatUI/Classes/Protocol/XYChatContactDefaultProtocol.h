//
//  XYChatContactDefaultProtocol.h
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import <Foundation/Foundation.h>
#import <XYChatUI/XYChatContactProtocol.h>
@interface XYChatContactDefaultProtocol : NSObject<XYChatContactProtocol>

@end
