//
//  XYStudentModel.h
//  XYCache
//
//  Created by henry on 2017/10/27.
//  Copyright © 2017年 henry. All rights reserved.
//

#import <XYCache/XYCache.h>
@class XYSchoolModel;

@interface XYStudentModel : XYArchiverModel

@property (nonatomic,copy) NSString *name;
@property (nonatomic,assign) int height;
@property (nonatomic,assign) BOOL sex;

@property (nonatomic,strong) XYSchoolModel *school;
@end
