//
//  XYChatContactModel.m
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import "XYChatContactModel.h"
#import "XYChatDateConvertTool.h"
#import <XYCache/XYArchiverTool.h>

@implementation XYChatContactModel

- (NSString *)displayTime{
    return [XYChatDateConvertTool getTimeWithTimeStamp:self.time.doubleValue];
}

- (id)initWithCoder:(NSCoder *)decoder {
    self = [super init];
    if (!self) {
        return nil;
    }
    [XYArchiverTool unarchiver:decoder object:self filter:@[@"displayTime"]];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder {
    [XYArchiverTool archiver:encoder object:self filter:@[@"displayTime"]];
}

@end
