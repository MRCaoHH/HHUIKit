//
//  XYBTTextFieldCell.m
//  MJExtension
//
//  Created by henry on 2017/11/22.
//

#import "XYBTTextFieldCell.h"
#import <XYCategory/XYCategory.h>

@interface XYUITextField:UITextField
@property (nonatomic,assign) BOOL xy_disablePaste;
@end

@implementation XYUITextField
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender{
    if (self.xy_disablePaste) {
        // 禁用粘贴功能
        if (action == @selector(paste:)){
            return NO;
        }
    }
    return [super canPerformAction:action withSender:sender];
}
@end

@interface XYBTTextFieldCell()<UITextFieldDelegate>
@end

@implementation XYBTTextFieldCell
@synthesize text = _text,textFieldBgColor = _textFieldBgColor;

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        _textFieldTopEdge = 5;
        _textFieldBottomEdge = 5;
        _textFieldRightEdge = 12;
        _titleLeftEdge = 12;
        _titleToTextField = 5;
    }
    return  self;
}

#pragma mark - 父类方法 -
- (void)layoutSubviews{
    [super layoutSubviews];
    [self.titleLabel sizeToFit];
    self.titleLabel.xy_centerY = self.contentView.xy_centerY;
    self.titleLabel.xy_x = _titleLeftEdge;
    
    self.textField.xy_width = self.contentView.xy_width - _titleToTextField  - _textFieldRightEdge - self.titleLabel.xy_right;
    self.textField.xy_x = self.titleLabel.xy_right + _titleToTextField;
    self.textField.xy_height = self.contentView.xy_height - _textFieldTopEdge -  _textFieldBottomEdge;
    self.textField.xy_centerY = self.titleLabel.xy_centerY;
}
#pragma mark - 协议 -
#pragma mark - UITextFieldDelegate
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [self.textField resignFirstResponder];
    return YES;
}


#pragma mark - 属性方法 -
- (UILabel *)titleLabel{
    if(_titleLabel == nil){
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.font = [UIFont systemFontOfSize:13];
        _titleLabel.textColor = [UIColor blackColor];
        [self.contentView addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (UITextField *)textField{
    if (_textField == nil) {
        _textField = [[XYUITextField alloc]init];
        _textField.font = [UIFont systemFontOfSize:14];
        _textField.textColor = [UIColor blackColor];
        _textField.returnKeyType = UIReturnKeyDone;
        _textField.leftView = ({
            UIView *view = [UIView new];
            view.frame = CGRectMake(0, 0, 5, 0);
            view;
        });
        _textField.leftViewMode =  UITextFieldViewModeAlways;
        _textField.rightView = ({
            UIView *view = [UIView new];
            view.frame = CGRectMake(0, 0, 5, 0);
            view;
        });
        _textField.rightViewMode =  UITextFieldViewModeAlways;
        _textField.delegate = self;
        _textField.backgroundColor = [UIColor xy_colorWithHexString:@"#F5F5F5"];
        [self.contentView addSubview:_textField];
    }
    return _textField;
}

- (void)setPlaceholder:(NSString *)placeholder{
    _placeholder = placeholder;
    self.textField.placeholder = self.placeholder;
}

- (void)setText:(NSString *)text{
    _text = text;
    self.textField.text = text;
}


- (void)setTitle:(NSString *)title{
    _title = title;
    self.titleLabel.text = _title;
}

-(void)setTextFieldBgColor:(NSString *)textFieldBgColor{
    _textFieldBgColor = textFieldBgColor;
    self.textField.backgroundColor = [UIColor xy_colorWithHexString:_textFieldBgColor];
}

- (void)setTextFieldTextColor:(NSString *)textFieldTextColor{
    _textFieldTextColor = textFieldTextColor;
    self.textField.textColor = [UIColor xy_colorWithHexString:_textFieldTextColor];
}
- (void)setTextFieldFontSize:(CGFloat)textFieldFontSize{
    _textFieldFontSize = textFieldFontSize;
    self.textField.font = [UIFont systemFontOfSize:textFieldFontSize];
}

- (void)setTitleTextColor:(NSString *)titleTextColor{
    _titleTextColor = titleTextColor;
    self.titleLabel.textColor = [UIColor xy_colorWithHexString:_titleTextColor];
}

- (void)setTitleFontSize:(CGFloat)titleFontSize{
    _titleFontSize = titleFontSize;
    self.titleLabel.font = [UIFont systemFontOfSize:_titleFontSize];
}

- (void)setDisablePaste:(BOOL)disablePaste{
    XYUITextField *textField = self.textField;
    textField.xy_disablePaste = disablePaste;
    _disablePaste = disablePaste;
}

@end
