//
//  XYViewController2.h
//  GPUImage
//
//  Created by henry on 2018/11/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XYViewController2 : UIViewController

@end

NS_ASSUME_NONNULL_END
