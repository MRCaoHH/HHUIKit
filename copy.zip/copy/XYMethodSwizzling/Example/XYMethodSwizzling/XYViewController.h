//
//  XYViewController.h
//  XYMethodSwizzling
//
//  Created by henry on 12/01/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

@import UIKit;

@interface XYViewController : UIViewController

@end
