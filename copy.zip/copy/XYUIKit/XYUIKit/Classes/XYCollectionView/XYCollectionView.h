//
//  XYCollectionView.h
//  XYUIKit
//
//  Created by henry on 2018/1/4.
//

#import <UIKit/UIKit.h>

@interface XYCollectionView : UICollectionView

@end
