//
//  XYNetworkingTests.m
//  XYNetworkingTests
//
//  Created by Henry on 10/26/2017.
//  Copyright (c) 2017 Henry. All rights reserved.
//

@import XCTest;
@import XYNetworking;
#import "XYExampleProtocol.h"
#import "XYBaseDataModel.h"

@interface Tests : XCTestCase

@end

@implementation Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
    [XYExampleProtocol registerClass:[XYExampleProtocol class]];
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

//post请求
- (void)testPostRequest{
    [self expectationForNotification:@"Post" object:nil handler:nil];
    [XYHttpRequest POST:@"" params:@{@"info":@"图灵的简介"} success:^(XYResponseModel *responseModel) {
        XCTAssertEqual([responseModel.baseModel class], [XYBaseDataModel class]);
        [[NSNotificationCenter defaultCenter]postNotificationName:@"Post" object:nil];
    } failure:^(XYResponseModel *responseModel) {
        XCTAssert(@"请求出错");
    }];
    [self waitForExpectationsWithTimeout:30 handler:nil];
}

//get请求
- (void)testGetRequest{
    [self expectationForNotification:@"Get" object:nil handler:nil];
    [XYHttpRequest GET:@"" params:@{@"info":@"图灵介绍"} success:^(XYResponseModel *responseModel) {
        XCTAssertEqual([responseModel.baseModel class], [XYBaseDataModel class]);
        [[NSNotificationCenter defaultCenter]postNotificationName:@"Get" object:nil];
    } failure:^(XYResponseModel *responseModel) {
        XCTAssert(@"请求出错");
    }];
    [self waitForExpectationsWithTimeout:30 handler:nil];
}

//上传请求
- (void)testUpLoadRequest{
   //暂无接口免测
}

@end

