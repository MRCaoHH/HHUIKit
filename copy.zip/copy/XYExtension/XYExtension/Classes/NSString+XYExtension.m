//
//  NSString+XYExtension.m
//  XYExtension
//
//  Created by henry on 2018/1/26.
//

#import "NSString+XYExtension.h"
#import <MJExtension/MJExtension.h>
@implementation NSString (XYExtension)

- (NSString *)xy_underlineFromCamel{
    return [self mj_underlineFromCamel];
}

- (NSString *)xy_camelFromUnderline{
    return [self mj_camelFromUnderline];
}

/**
 * 首字母变大写
 */
- (NSString *)xy_firstCharUpper{
    return [self mj_firstCharUpper];
}

/**
 * 首字母变小写
 */
- (NSString *)xy_firstCharLower{
    return [self mj_firstCharLower];
}

- (BOOL)xy_isPureInt{
    return [self mj_isPureInt];
}

- (NSURL *)xy_url{
    return [self mj_url];
}
@end
