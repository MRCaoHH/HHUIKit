//
//  XYMenuButton.m
//  XYMenuButton
//
//  Created by henry on 2017/10/20.
//

#import "XYMenuButton.h"
#import "XYMBViewController.h"

@implementation XYMenuButton

- (instancetype)init{
    self = [super init];
    if(self){
        [self initConfig];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if(self){
        [self initConfig];
    }
    return self;
}

- (void)initConfig{
    self.itemSpacing = 20;
    [self addTarget:self action:@selector(clickButton) forControlEvents:UIControlEventTouchUpInside];
}

- (void)clickButton{
    if (_orgSuperView != nil) {
        return;
    }
    
    UIViewController *rootVC = _orgViewController;
    if (_orgViewController == nil) {
        rootVC = [UIApplication sharedApplication].keyWindow.rootViewController;
    }
    XYMBViewController *vc = [[XYMBViewController alloc]initWithMenuButton:self];
    [rootVC presentViewController:vc animated:YES completion:nil];
}

- (void)record{
    //記錄
    _orgSuperView =  self.superview;
    _orgFrame = self.frame;
}

- (void)clearRecord{
    _orgSuperView = nil;
    _orgFrame = CGRectZero;
}

@end
