//
//  XYEmojiSourceProtocol.m
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/16.
//

#import "XYEmojiSourceProtocol.h"

@implementation XYEmojiSourceProtocol
static Class XYSourceProtocolRegisClass = nil;

+ (Class)regisclass{
    if (XYSourceProtocolRegisClass == nil) {
        return [self class];
    }
    return XYSourceProtocolRegisClass ;
}

+ (BOOL)registerClass:(Class)aclass{
    if([aclass isSubclassOfClass:[self class]]){
        XYSourceProtocolRegisClass = aclass;
        return YES;
    }
    return NO;
}

+ (void)unregisterClass:(Class)aclass{
    if (XYSourceProtocolRegisClass == aclass) {
        XYSourceProtocolRegisClass = [self class];
    }
}

+ (NSBundle *)sourceBundle{
    NSBundle *classBundle = [NSBundle bundleForClass:[self class]];
    NSString *bundlePath = [classBundle pathForResource:@"XYEmojiKeyboard" ofType:@"bundle"];
    NSBundle *newBundle = [NSBundle bundleWithPath:bundlePath];
    return newBundle;
}

+ (UIImage *)imageWithName:(NSString *)imageName{
    NSString *path = [[[self regisclass] sourceBundle] pathForResource:[NSString stringWithFormat:@"%@@2x",imageName] ofType:@"png"];
    return [UIImage imageWithContentsOfFile:path];
}

+ (NSString *)pathWithName:(NSString *)name withType:(NSString *)type{
    return [[[self regisclass] sourceBundle] pathForResource:name ofType:type];
}
@end
