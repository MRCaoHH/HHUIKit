//
//  XYChatContactDefaultProtocol.m
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import "XYChatContactDefaultProtocol.h"
#import "XYChatContactModel.h"
#import "XYChatVC.h"
#import "XYChatContactVC.h"
#import "XYChatServiceManager.h"

@interface XYChatContactDefaultProtocol()<XYChatServiceManagerDelegate>
@end

@implementation XYChatContactDefaultProtocol
@synthesize contactArray = _contactArray,contactVC = _contactVC;

- (instancetype)init{
    self = [super init];
    if (self) {
        XYChatServiceManager *manager =  [XYChatServiceManager shareInstance];
        [manager addDelegate:self];
        self.contactArray = manager.contactList;
    }
    return self;
}

- (void)dealloc{
    XYChatServiceManager *manager =  [XYChatServiceManager shareInstance];
    [manager removeDelegate:self];
}

- (void)didSelectWithContact:(XYChatContactModel *)contact{
    NSLog(@"%@",contact.name);
    XYChatVC *vc = [[XYChatVC alloc]initWithChatContactModel:contact];
    [self.contactVC.navigationController pushViewController:vc animated:YES];
}

- (void)downPullReloadData:(void(^)(BOOL succ))complete{
    XYChatServiceManager *manager =  [XYChatServiceManager shareInstance];
    __weak typeof(self) weakSelf = self ;
    [manager queryContactList:^(BOOL succ, NSArray *contactList) {
        if (succ) {
            weakSelf.contactArray = contactList;
        }
        complete(succ);
    }];
}


#pragma mark - 协议
- (void)chatService:(XYChatServiceManager *)manager changeContacts:(NSArray *)contacts{
    self.contactArray = manager.contactList;
    [self.contactVC.tableView reloadData];
}
@end
