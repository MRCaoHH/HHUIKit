//
//  XYTrendChartView.m
//  HHTestGestureRecognizer
//
//  Created by henry on 2018/5/29.
//  Copyright © 2018年 caohuihui. All rights reserved.
//

#import "XYTrendChartView.h"

@interface XYTrendChartView ()
@property (nonatomic,assign) CGFloat numberWidth;
@end

@implementation XYTrendChartView

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    //是否绘制表格
    if(self.type&XYTrendChartViewType_Form){
        [self drawForm:rect];
    }

    //绘制遗漏分层和补位
    if (self.type&XYTrendChartViewType_Complement) {
        [self drawComplement:rect];
    }
    
    //绘制期数
    if (self.type&XYTrendChartViewType_Vesion) {
        [self drawVesion:rect];
    }
    
    //绘制普通号码
    if (self.type&XYTrendChartViewType_Number) {
        [self drawNumber:rect];
    }
    
    //绘制连线
    if (self.type & XYTrendChartViewType_LinkLine) {
        [self drawChart:rect];
    }
    
    //绘制中奖
    if (self.type&XYTrendChartViewType_Winning) {
        [self drawWinning:rect];
    }
}

#pragma mark - 绘制表格 绘制一个不带文本，中奖连线、中奖圆圈的表格
- (void)drawForm:(CGRect)rect{
    
    //获取上下文
    CGContextRef con = UIGraphicsGetCurrentContext();
    //关闭抗锯齿
    CGContextSetAllowsAntialiasing(con,NO);
    //设置线条宽度
    CGFloat lineWidth = 1.0/[UIScreen mainScreen].scale;
    //开始位置偏移，当y=0时绘制的线条看不到
    CGFloat offsetY = lineWidth;
    //开始位置偏移，当x=0时绘制的线条看不到
    CGFloat offsetX = lineWidth;
    
    //颜色填充
    for (int i = 0; i <self.recordArr.count; i++) {
        CGFloat y = i * self.lineHeight + offsetY;
        CGFloat w = rect.size.width;
        CGFloat h = self.lineHeight - offsetX;
        CGRect rectFrame = CGRectMake(offsetX, y,w , h);
        if (i%2) {//奇数行
            [self drawRect:con rect:rectFrame color:self.oddNumberLineColor];
        }else{//偶数行
            [self drawRect:con rect:rectFrame color:self.evenNumberLineColor];
        }
    }
    
    //设置线条颜色
    [self.lineColor set];
    CGContextSetLineWidth(con, lineWidth);
    
    ///先画横线
    for (int i = 0; i< self.recordArr.count; i++) {
        CGFloat y = i * self.lineHeight + offsetY;
        CGPoint fromPoint = CGPointMake(offsetX, y);
        CGPoint toPoint = CGPointMake(rect.size.width, y);
        [self drawLine:con fromPoint:fromPoint toPoint:toPoint];
    }
    
    if (self.recordArr.count>0) {//最后面的封盖线
        CGFloat y = self.recordArr.count * self.lineHeight + offsetY;
        CGPoint fromPoint = CGPointMake(offsetX, y);
        CGPoint toPoint = CGPointMake(rect.size.width, y);
        [self drawLine:con fromPoint:fromPoint toPoint:toPoint];
    }
    
    ///绘制竖线
    XYTrendChartRecord *record = [self.recordArr firstObject];
    CGFloat maxY = self.recordArr.count * self.lineHeight + offsetY;
    CGFloat numFrameWidth = rect.size.width;
    if (record.numberArr.count) {
       numFrameWidth = (rect.size.width - self.firstColumnWidth)/record.numberArr.count;
    }
    self.numberWidth = numFrameWidth;
    
    //第一条线
    CGFloat firstX = offsetX;
    CGPoint firstFromPoint = CGPointMake(firstX, 0);
    CGPoint firstToPoint = CGPointMake(firstX, maxY);
    [self drawLine:con fromPoint:firstFromPoint toPoint:firstToPoint];
    
    //号码线条
    for (int i = 0; i< record.numberArr.count; i++) {
        CGFloat x = i * numFrameWidth + offsetX + self.firstColumnWidth;
        CGPoint fromPoint = CGPointMake(x, 0);
        CGPoint toPoint = CGPointMake(x, maxY);
        [self drawLine:con fromPoint:fromPoint toPoint:toPoint];
    }
    
    //最后一条线
    CGFloat lastX = CGRectGetMaxX(rect) - offsetX;
    CGPoint lastFromPoint = CGPointMake(lastX, 0);
    CGPoint lastToPoint = CGPointMake(lastX,maxY);
    [self drawLine:con fromPoint:lastFromPoint toPoint:lastToPoint];
    
    CGContextStrokePath(con);
    
}

- (void)drawLine:(CGContextRef)con fromPoint:(CGPoint)fromPoint toPoint:(CGPoint)toPoint{
    CGContextMoveToPoint(con, fromPoint.x, fromPoint.y);
    CGContextAddLineToPoint(con, toPoint.x, toPoint.y);
}

- (void)drawRect:(CGContextRef)con rect:(CGRect)rect color:(UIColor *)color{
    CGContextAddRect(con, rect);
    [color set];
    CGContextFillPath(con);
}

#pragma mark - 绘制期数
- (void)drawVesion:(CGRect)rect{
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con,YES);
    //设置线条宽度
    CGFloat lineWidth = 1.0/[UIScreen mainScreen].scale;
    //开始位置偏移，当y=0时绘制的线条看不到
    CGFloat offsetY = lineWidth;
    //开始位置偏移，当x=0时绘制的线条看不到
    CGFloat offsetX = lineWidth;
    //颜色填充
    for (int i = 0; i <self.recordArr.count; i++) {
        XYTrendChartRecord *record  = self.recordArr[i];
        CGFloat y = i * self.lineHeight + offsetY;
        CGFloat x = offsetX;
        CGFloat w = self.firstColumnWidth;
        CGFloat h = self.lineHeight - offsetX;
        //期数绘制
        CGRect versionFrame = CGRectMake(x, y, w, h);
        [self drawTextWithText:record.version rect:versionFrame];
    }
}

#pragma mark - 绘制普通号码,不含中奖号码
- (void)drawNumber:(CGRect)rect{
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con,YES);
    //设置线条宽度
    CGFloat lineWidth = 1.0/[UIScreen mainScreen].scale;
    //开始位置偏移，当y=0时绘制的线条看不到
    CGFloat offsetY = lineWidth;
    //开始位置偏移，当x=0时绘制的线条看不到
    CGFloat offsetX = lineWidth;
    //颜色填充
    for (int i = 0; i <self.recordArr.count; i++) {
        XYTrendChartRecord *record  = self.recordArr[i];
        CGFloat y = i * self.lineHeight + offsetY;
        CGFloat x = offsetX;
        CGFloat w = self.firstColumnWidth;
        CGFloat h = self.lineHeight - offsetX;

        x += w;
        w = self.numberWidth;
        //绘制号码
        for (int j = 0; j < record.numberArr.count; j++) {
            CGFloat numX = x + j * w;
            CGRect numberFrame = CGRectMake(numX, y, w, h);
            NSString *numberStr = record.numberArr[j];
            if (j == record.winning ){
                continue;
            }
            [self drawTextWithText:numberStr rect:numberFrame];
        }
    }
}

#pragma mark - 绘制中奖号码
- (void)drawWinning:(CGRect)rect{
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con,YES);
    //设置线条宽度
    CGFloat lineWidth = 1.0/[UIScreen mainScreen].scale;
    //开始位置偏移，当y=0时绘制的线条看不到
    CGFloat offsetY = lineWidth;
    //开始位置偏移，当x=0时绘制的线条看不到
    CGFloat offsetX = lineWidth;
    //颜色填充
    for (int i = 0; i <self.recordArr.count; i++) {
        XYTrendChartRecord *record  = self.recordArr[i];
        CGFloat y = i * self.lineHeight + offsetY;
        CGFloat x = offsetX;
        CGFloat w = self.firstColumnWidth;
        CGFloat h = self.lineHeight - offsetX;
        
        x += w;
        w = self.numberWidth;
        //绘制号码
        for (int j = 0; j < record.numberArr.count; j++) {
            CGFloat numX = x + j * w;
            CGRect numberFrame = CGRectMake(numX, y, w, h);
            NSString *numberStr = record.numberArr[j];
            if (j != record.winning) {//未中奖返回
                continue;
            }
            
            if (numberFrame.size.width > numberFrame.size.height) {//宽大于高
                numberFrame.size.height -=4;
                numberFrame.origin.y += 2;
                numberFrame.origin.x += (numberFrame.size.width - numberFrame.size.height)/2;
                numberFrame.size.width = numberFrame.size.height;
                
            }else{//高大于宽
                numberFrame.size.width -=4;
                numberFrame.origin.x += 2;
                numberFrame.origin.y += (numberFrame.size.height - numberFrame.size.width)/2;
                numberFrame.size.height = numberFrame.size.width;
            }
            CGContextAddEllipseInRect(con, numberFrame);
            [self.winningBgColor set];
            CGContextFillPath(con);
            [self drawTextWithText:numberStr rect:numberFrame];
        }
    }
}

#pragma mark - 绘制文本
- (void)drawTextWithText:(NSString *)text rect:(CGRect)rect{
    NSDictionary *attributesDic = @{NSFontAttributeName:self.textFont,NSForegroundColorAttributeName :self.textColor};
    CGRect actualRect =  [text boundingRectWithSize:rect.size options:NSStringDrawingUsesLineFragmentOrigin attributes:attributesDic context:NULL];

    rect.origin.y += (rect.size.height - actualRect.size.height)/2;
    rect.origin.x += (rect.size.width - actualRect.size.width)/2;
    [text drawInRect:rect withAttributes:@{NSFontAttributeName:self.textFont,NSForegroundColorAttributeName :self.textColor}];
}

#pragma mark - 绘制连线 中奖号码之间的连线
- (void)drawChart:(CGRect)rect{
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con,YES);
    //设置线条颜色
    [self.linkLineColor set];
    CGContextSetLineWidth(con, 2);
    
    //设置线条宽度
    CGFloat lineWidth = 1.0/[UIScreen mainScreen].scale;
    //开始位置偏移，当y=0时绘制的线条看不到
    CGFloat offsetY = lineWidth;
    //开始位置偏移，当x=0时绘制的线条看不到
    CGFloat offsetX = lineWidth;
    //颜色填充
    for (int i = 0; i <self.recordArr.count; i++) {
        XYTrendChartRecord *record  = self.recordArr[i];
        CGFloat y = i * self.lineHeight + offsetY;
        CGFloat x = offsetX;
        CGFloat w = self.firstColumnWidth;
        CGFloat h = self.lineHeight - offsetX;
    
        x += w;
        w = self.numberWidth;
        //绘制号码
        CGFloat numX = x + record.winning * w;
        CGRect versionFrame = CGRectMake(numX, y, w, h);
        CGFloat lineHeightMultiple = 1.5f;
        lineHeightMultiple = 1.35f;
        if (versionFrame.size.width > versionFrame.size.height) {//宽大于高
            versionFrame.size.height -=4;
            versionFrame.origin.y += 2;
            versionFrame.origin.x += (versionFrame.size.width - versionFrame.size.height)/2;
            versionFrame.size.width = versionFrame.size.height;
            
        }else{//高大于宽
            versionFrame.size.width -=4;
            versionFrame.origin.x += 2;
            versionFrame.origin.y += (versionFrame.size.height - versionFrame.size.width)/2;
            versionFrame.size.height = versionFrame.size.width;
        }
        
        CGFloat centerX = CGRectGetMidX(versionFrame);
        CGFloat centerY = CGRectGetMidY(versionFrame);
        if(i == 0){//起点
            CGContextMoveToPoint(con, centerX, centerY);
            
        }else{
            CGContextAddLineToPoint(con, centerX, centerY);
        }
    }
    
    CGContextStrokePath(con);
}

#pragma mark - 绘制补位方块 遗漏分层
- (void)drawComplement:(CGRect)rect{
    CGContextRef con = UIGraphicsGetCurrentContext();
    CGContextSetAllowsAntialiasing(con,YES);
    //最大的y值
    CGFloat maxY = self.recordArr.count * self.lineHeight;
    XYTrendChartRecord *record = [self.recordArr firstObject];
    CGFloat lineWidth = 1.0/[UIScreen mainScreen].scale;
    for (int i = 0; i <record.numberArr.count; i++) {
        int length = 0;
        for (NSInteger j = self.recordArr.count - 1; j >= 0;j--) {
            XYTrendChartRecord *aRecord = self.recordArr[j];
            if (aRecord.winning == i) {//如果中奖的号码是本列则退出循环
                break;
            }
            //中奖的号码不是是本列
            length +=1;
        }
        
        CGFloat x = self.firstColumnWidth + self.numberWidth * i + lineWidth + lineWidth;
        CGFloat h = self.lineHeight * length;
        CGFloat w = self.numberWidth - lineWidth - lineWidth;
        CGFloat y = maxY - h;
        
        CGRect rectFrame = CGRectMake(x, y, w,h);
        [self drawRect:con rect:rectFrame color:self.complementBgColor];
    }
}

#pragma mark - 数据整理
- (void)handleData{
    XYTrendChartRecord *record = [self.recordArr firstObject];
    for (int i = 0; i <record.numberArr.count; i++) {
        int length = 0;
        for (NSInteger j = self.recordArr.count - 1; j >= 0;j--) {
            XYTrendChartRecord *aRecord = self.recordArr[j];
            if (aRecord.winning == i) {//如果中奖的号码是本列则退出循环
                length = 0;
                continue;
            }
            //中奖的号码不是是本列
            length +=1;
            aRecord.numberArr[i] = [NSString stringWithFormat:@"%i",length];
        }
        
    }
}

#pragma mark - 属性方法 -
- (UIColor *)lineColor{
    if (_lineColor == nil) {
        _lineColor = [UIColor whiteColor];
    }
    return _lineColor;
}

- (CGFloat)lineHeight{
    if (_lineHeight == 0) {
        _lineHeight = 30;
    }
    return _lineHeight;
}

- (CGFloat)firstColumnWidth{
    if (_firstColumnWidth == 0) {
        _firstColumnWidth = 100;
    }
    return _firstColumnWidth;
}

- (UIColor *)oddNumberLineColor{
    if (_oddNumberLineColor == nil) {
        _oddNumberLineColor = [UIColor orangeColor];
    }
    return _oddNumberLineColor;
}

- (UIColor *)evenNumberLineColor{
    if (_evenNumberLineColor == nil) {
        _evenNumberLineColor = [UIColor blueColor];
    }
    return _evenNumberLineColor;
}

- (UIColor *)complementBgColor{
    if (_complementBgColor == nil) {
        _complementBgColor = [UIColor redColor];
    }
    return _complementBgColor;
}

- (UIColor *)winningBgColor{
    if (_winningBgColor == nil) {
        _winningBgColor = [UIColor purpleColor];
    }
    return _winningBgColor;
}

- (UIColor *)linkLineColor{
    if (_linkLineColor == nil) {
        _linkLineColor = [UIColor yellowColor];
    }
    return _linkLineColor;
}

- (UIFont *)textFont{
    if (_textFont == nil) {
        _textFont = [UIFont systemFontOfSize:12];
    }
    return _textFont;
}

- (UIColor *)textColor{
    if (_textColor == nil) {
        _textColor = [UIColor whiteColor];
    }
    return _textColor;
}
@end

@implementation XYTrendChartRecord
@end
