//
//  XYAppDelegate+Routes.m
//  XYLive
//
//  Created by henry on 2017/11/7.
//  Copyright © 2017年 XinYi. All rights reserved.
//

#import "XYAppDelegate+Routes.h"
#import <XYRoutes/XYRoutes.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <XYCategory/XYCategory.h>
#import <XYMacro/XYMacro_Func.h>
#import <XYNavigationController/XYNavigationController.h>
#import "XYRouteHandle.h"

@implementation XYAppDelegate (Routes)
static NSString *kClassName = @"className";
static NSString *kClassFunc = @"classFunc";
static NSString *kInstanceFunc = @"instanceFunc";
static NSString *kInstanceParam = @"iParam";
static NSString *kClassParam = @"cParam";
static NSString *kAction = @"action";

- (void)registerRoutes{
    XYWeakSelf;
    [[XYRoutes defaultRoutes] addRoute:@"push" handelEvent:^(NSString *routeUrl, NSDictionary *param) {
        NSLog(@"%@",routeUrl);
        id instance = [weakSelf getInstanceWithParams:param];
        if (!instance) {return;}
        UIViewController *vc = [weakSelf currentViewController];
        [vc.navigationController pushViewController:instance animated:YES];
    }];
    
    [[XYRoutes defaultRoutes] addRoute:@"show" handelEvent:^(NSString *routeUrl, NSDictionary *param) {
        NSLog(@"%@",routeUrl);
        id instance = [weakSelf getInstanceWithParams:param];
        if (!instance) {return;}
        if ([instance isKindOfClass:[UITabBarController class]] || [instance isKindOfClass:[UINavigationController class]]){
            self.window.rootViewController = instance;
            return;
        }
        XYNavigationController *nav = [[XYNavigationController alloc]initWithRootViewController:instance];
        self.window.rootViewController = nav;
    }];
    
    [[XYRoutes defaultRoutes] addRoute:@"popo" handelEvent:^(NSString *routeUrl, NSDictionary *param) {
        NSLog(@"%@",routeUrl);
        id instance = [weakSelf getInstanceWithParams:param];
        if (!instance) {return;}
        UIViewController *vc = [weakSelf currentViewController];
        [vc.navigationController pushViewController:instance animated:YES];
    }];
    
    [[XYRoutes defaultRoutes] addRoute:@"present" handelEvent:^(NSString *routeUrl, NSDictionary *param) {
        NSLog(@"%@",routeUrl);
        id instance = [weakSelf getInstanceWithParams:param];
        if (!instance) {return;}
        UIViewController *vc = [weakSelf currentViewController];
        XYNavigationController *navVC = [[XYNavigationController alloc]initWithRootViewController:instance];
        [vc presentViewController:navVC animated:YES completion:nil];
    }];
    
    [[XYRoutes defaultRoutes] addRoute:@"none" handelEvent:^(NSString *routeUrl, NSDictionary *param) {
        NSLog(@"%@",routeUrl);
        id instance = [weakSelf getInstanceWithParams:param];
        if (!instance) {return;}
        UIViewController *vc = [weakSelf currentViewController];
        [vc.navigationController pushViewController:instance animated:YES];
    }];
}

- (id)getInstanceWithParams:(NSDictionary *)params{
    NSLog(@"%@",params);
    NSString *className = params[kClassName];
    Class aClass = NSClassFromString(className);
    if (!aClass) {
        //类不存在
        return nil;
    }
    
    BOOL action = [params[kAction] boolValue];
    NSString *classFunc = params[kClassFunc];
    if (classFunc == nil) {
        if (action) { return  nil;}//action = 1 且不存在类方法 不执行直接返回
        classFunc = @"alloc";
    }
    SEL classSel = NSSelectorFromString(classFunc);
    NSMutableDictionary *cParams = [self getParamsWithParams:params withParamKey:kClassParam];

    if (![aClass respondsToSelector:classSel]) {
        if (action) { return  nil;}//action = 1 存在类方法 但该类并没有实现 不执行直接返回
        classSel = @selector(alloc);
        [cParams removeAllObjects];
    }

    id classInstance = [XYRouteHandle sendMsgWithInstance:aClass withSelector:classSel withParams:cParams];
    NSString *instanceFunc = params[kInstanceFunc];
    if (instanceFunc == nil) {
        if (action) { return  classInstance;}//action = 1 不存在实例方法，则直接返回类方法的返回值
        instanceFunc = @"init";
    }

    SEL instanceSel = NSSelectorFromString(instanceFunc);
    NSMutableDictionary *iParams = [self getParamsWithParams:params withParamKey:kInstanceParam];
    if (![classInstance respondsToSelector:instanceSel]) {
        if (action) { return  nil;}//action = 1 存在实例方法 ， 但该类并没有实现 ，则直接返回类方法的返回值
        classSel = @selector(init);
        [iParams removeAllObjects];
    }
    id instance =  [XYRouteHandle sendMsgWithInstance:classInstance withSelector:instanceSel withParams:iParams];
    return instance;
//    return instance;
}

- (NSMutableDictionary *)getParamsWithParams:(NSDictionary *)params withParamKey:(NSString *)paramKey{
    NSMutableDictionary *aParams = @{}.mutableCopy;
    for (int i = 0; i< 5; i++) {//最多5个类参数
        NSString *aParamKey = [NSString stringWithFormat:@"%@%i",paramKey,i+1];
        id aParam = params[aParamKey];
        if ([aParam isKindOfClass:[NSString class]]) {
            aParam = [(NSString *)aParam xy_base64Decode];
        }
        if(!aParam){
            return aParams;
            break;
        }
        
        [aParams setObject:aParam forKey:@(i)];
    }
    return nil;
}



- (UIViewController *)currentViewController{
    return [self getTopViewController:self.window.rootViewController];
}

- (UIViewController *)getTopViewController:(UIViewController *)vc{
    if ([vc isKindOfClass:[UINavigationController class]]) {
        UINavigationController *nav = (UINavigationController *)vc;
        return [self getTopViewController:nav.visibleViewController];
    }
    
    if ([vc isKindOfClass:[UITabBarController class]]) {
        UITabBarController *tabbar = (UITabBarController *)vc;
        return [self getTopViewController:tabbar.selectedViewController];
    }
    
    return vc;
}
@end
