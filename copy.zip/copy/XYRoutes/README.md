# XYRoutes

[![CI Status](http://img.shields.io/travis/henry/XYRoutes.svg?style=flat)](https://travis-ci.org/henry/XYRoutes)
[![Version](https://img.shields.io/cocoapods/v/XYRoutes.svg?style=flat)](http://cocoapods.org/pods/XYRoutes)
[![License](https://img.shields.io/cocoapods/l/XYRoutes.svg?style=flat)](http://cocoapods.org/pods/XYRoutes)
[![Platform](https://img.shields.io/cocoapods/p/XYRoutes.svg?style=flat)](http://cocoapods.org/pods/XYRoutes)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYRoutes is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYRoutes'
```
## Usage



## Author

henry, henry@xy.com

## License

XYRoutes is available under the MIT license. See the LICENSE file for more info.


