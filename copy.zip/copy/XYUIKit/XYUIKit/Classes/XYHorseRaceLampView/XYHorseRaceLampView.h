//
//  XYHorseRaceLampView.h
//  Masonry
//
//  Created by henry on 2019/2/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@protocol XYHorseRaceLampViewDelegate;

@interface XYHorseRaceLampView : UIView

/**
 标题
 */
@property (nonatomic,strong) NSArray *titles;

/**
 根据frame和titles初始化跑马灯

 @param frame frame
 @param titles 标题数组
 @return 实例
 */
- (instancetype)initWithFrame:(CGRect)frame withTitles:(NSArray *)titles;

/**
 根据frame 和标题数组、标题颜色、标题字体初始化

 @param frame frame
 @param titles 标题数组
 @param titleColor 标题颜色
 @param titleFont 标题字体
 @return 实例
 */
- (instancetype)initWithFrame:(CGRect)frame withTitles:(NSArray *)titles withTitleColor:(UIColor *)titleColor withTitleFont:(UIFont *)titleFont;

/**
 标题颜色
 */
@property (nonatomic,strong) UIColor *titleColor;

/**
 标题字体
 */
@property (nonatomic,strong) UIFont *titleFont;

/**
 协议
 */
@property (nonatomic,weak) id<XYHorseRaceLampViewDelegate> delegate;
@end

@protocol XYHorseRaceLampViewDelegate <NSObject>

@optional
/**
 点击跑马灯

 @param lampView 视图
 @param title 标题
 @param index 下标
 */
- (void)tapHorseRaceLampView:(XYHorseRaceLampView *)lampView title:(NSString *)title index:(NSInteger)index;

@end

NS_ASSUME_NONNULL_END
