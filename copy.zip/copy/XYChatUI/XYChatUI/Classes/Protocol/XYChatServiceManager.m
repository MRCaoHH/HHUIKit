//
//  XYChatServiceManager.m
//  MJExtension
//
//  Created by henry on 2018/9/28.
//

#import "XYChatServiceManager.h"
#import "XYChatSendMsgParams.h"
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonDigest.h>
#import <XYWebSocket/XYWebSocket.h>
#import "XYChatReviceMsgBaseModel.h"
#import <XYExtension/XYExtension.h>
#import "XYChatMsgTextModel.h"
#import "XYChatContactModel.h"
#import "XYChatDelayedTaskTool.h"
#import <XYMacro/XYMacro_Func.h>
#import "XYChatMsgTextModel.h"
#import "XYChatReviceTextMsgModel.h"
#import "XYChatDataManager.h"
#import "XYChatReviceTipsMsgModel.h"

@interface XYChatServiceManager()<XYWebSocketDelegate>

/**
 websocket
 */
@property (nonatomic,strong) XYWebSocket *webSocket;

/**
 代理字典
 */
@property (nonatomic,strong) NSMutableDictionary *delegateDic;

/**
 通用代理数组
 */
@property (nonatomic,strong) NSMutableArray *commonDelegates;

/**
 历史记录回调字典
 */
@property (nonatomic,strong) NSMutableDictionary *callbackDict;

/**
 发送消息列表
 */
@property (nonatomic,strong) NSMutableDictionary *sendMsgDict;

/**
 超时处理
 */
@property (nonatomic,strong) NSMutableDictionary *outTimeDict;

/**
 发送正常消息字典
 */
@property (nonatomic,strong) NSMutableDictionary *sendNoneMsgDict;
@end

@implementation XYChatServiceManager

static int64_t kOutTime = 10;

+ (void)load{
    [XYChatContactModel  xy_setupReplacedKeyFromPropertyName:^NSDictionary *{
        return @{
                 @"toUserId":@"mid",
                 @"name":@"nickname",
                 @"iconUrl":@"userface",
                 @"msg":@"content",
                 @"unreadCount":@"count",
                 @"time":@"create_time"
                 };
    }];
    
    [XYChatMsgTextModel xy_setupReplacedKeyFromPropertyName:^NSDictionary *{
        return @{@"isSend":@"is_from",
                 @"createTime":@"create_time",
                 @"messageId":@"message_id"
                 };
    }];
}

+ (XYChatServiceManager *)shareInstance{
    static id shareInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareInstance = [[self class] new];
    });
    return shareInstance;
}

- (void)logout{
    self.sessionId = nil;
    [self.webSocket disconnect];
    
}

- (void)loginWithSessionId:(NSString *)sessionId{
    if (self.sessionId == nil) {
        return;
    }
    self.sessionId = sessionId;
    self.webSocket.url = [NSString stringWithFormat:@"%@/%@",self.host,sessionId];
    [self.webSocket connect];
}

- (void)updateSessionId:(NSString *)sessionId{
    self.sessionId = sessionId;
}

- (void)sendMsg:(XYChatSendMsgParams *)params{
    params.create_time = [[NSDate date]timeIntervalSince1970] * 1000;
    params.timestamp = (NSInteger)params.create_time;
    params.session_id = self.sessionId;
    params.message_id = [self generateMessageId:params];
    [self.webSocket sendMsg:params];
    if (params.message_id&&params) {
        [self.sendMsgDict setObject:params forKey:params.message_id];
    }
}

- (void)sendTextMsg:(XYChatMsgTextModel *)textModel{
    XYChatSendMsgParams *params = [XYChatSendMsgParams new];
    params.message = textModel.content;
    params.to_mid = textModel.toUid;
    params.code = XYChatMsgCode_Send;
    [self sendMsg:params];
    textModel.messageId = params.message_id;
    if (textModel.messageId.length) {
        [self.sendNoneMsgDict setObject:textModel forKey:textModel.messageId];
        [self outTimeEvent:[params.message_id copy]];
    }
}

- (NSString *)generateMessageId:(XYChatSendMsgParams *)params{
    NSString *orgString = [NSString stringWithFormat:@"#%@#%@#%@#%0.f#",params.message,self.mid,params.to_mid,params.create_time];
    NSString *messageId = [self md5:orgString];
    return messageId;
}

- (NSString *)md5:(NSString *)string{
    NSString *pas = [string copy];
    const char *cStr = [pas UTF8String];
    unsigned char digest[CC_MD5_DIGEST_LENGTH];
    
    CC_MD5(cStr, (CC_LONG)strlen(cStr), digest);
    NSMutableString *result = [NSMutableString stringWithCapacity:CC_MD5_DIGEST_LENGTH * 2];
    for (int i = 0; i < CC_MD5_DIGEST_LENGTH; i++) {
        [result appendFormat:@"%02x", digest[i]];
    }
    
    return result;
}

- (void)flagReadStataWithMid:(NSString *)mid{
    XYChatSendMsgParams *params = [XYChatSendMsgParams new];
    params.mid = mid;
    params.code = XYChatMsgCode_FlagRead;
    [self sendMsg:params];
}
#pragma mark - delegate 管理
- (void)addDelegate:(id<XYChatServiceManagerDelegate>)delegate subscribeWithMid:(NSString  *)mid{
    if (mid.length == 0 || delegate == nil) {
        return;
    }
    self.delegateDic[mid] = delegate;
}

- (void)addDelegate:(id<XYChatServiceManagerDelegate>)delegate{
    if (![self.commonDelegates containsObject:delegate] && delegate) {
        [self.commonDelegates addObject:delegate];
    }
}

- (void)removeDelegate:(id<XYChatServiceManagerDelegate>)delegate{
    if (!delegate) {
        return;
    }
    [self.commonDelegates removeObject:delegate];
    
    NSMutableArray *keys = [NSMutableArray new];
    for (NSString *key in self.delegateDic.allKeys) {
        NSString *object = self.delegateDic[key];
        if ([object isEqual:delegate]) {
            [keys addObject:key];
        }
    }
    
    [self.delegateDic removeObjectsForKeys:keys];
}

- (NSArray *)allDelegate{
    NSMutableArray *delegateArr = [NSMutableArray new];
    [delegateArr addObjectsFromArray:self.commonDelegates];
    [delegateArr addObjectsFromArray:[self.delegateDic allValues]];
    return delegateArr;
}

- (NSArray *)delegatesWithMid:(NSString *)mid{
    NSMutableArray *delegateArr = [NSMutableArray new];
    [delegateArr addObjectsFromArray:self.commonDelegates];
    id obj = self.delegateDic[mid];
    if (obj) {
        [delegateArr addObject:obj];
    }
    return delegateArr;
}

#pragma mark - 消息查询
- (void)queryMsgListWithMid:(NSString *)mid messageId:(NSString *)messageId callback:(void(^)(BOOL succ,NSArray *msgs))callback{
    XYChatSendMsgParams *params = [XYChatSendMsgParams new];
    params.code = XYChatMsgCode_History;
    params.page_id = messageId;
    params.mid = mid;
    [self sendMsg:params];
    if (callback && params.message_id) {
        [self.callbackDict setObject:callback forKey:params.message_id];
    }
}

- (void)queryContactList:(void(^)(BOOL succ,NSArray *contactList))callback{
    XYChatSendMsgParams *params = [XYChatSendMsgParams new];
    params.code = XYChatMsgCode_Contact;
    [self sendMsg:params];
    if (callback && params.message_id) {
        [self.callbackDict setObject:callback forKey:params.message_id];
        [self outTimeEvent:[params.message_id copy]];
    }
}

- (void)sendJoinMsg{
    XYChatSendMsgParams *params = [XYChatSendMsgParams new];
    params.code = XYChatMsgCode_Join;
    [self sendMsg:params];
}

- (void)outTimeEvent:(NSString *)msgId{
    XYWeakSelf;
    dispatch_block_t block =  [XYChatDelayedTaskTool createDelayedTask:kOutTime task:^{
        
        id  obj = weakSelf.sendNoneMsgDict[msgId];
        if ([obj isKindOfClass:[XYChatMsgTextModel class]]) {
            XY_Dispatch_main_async_safe(^{
                XYChatMsgTextModel *textModel = obj;
                textModel.state = XYChatMsgSendState_Fail;
            });
            [weakSelf.sendNoneMsgDict removeObjectForKey:msgId];
        }
        
        void(^callback)(BOOL succ,NSArray *arr) = self.callbackDict[msgId];
        if (callback) {
            XY_Dispatch_main_async_safe(^{
                callback(NO,nil);
            });
        }
        [weakSelf.callbackDict removeObjectForKey:msgId];
        [weakSelf.outTimeDict removeObjectForKey:msgId];
        [weakSelf.sendMsgDict removeObjectForKey:msgId];
    }];
    [self.outTimeDict setObject:block forKey:msgId];
}

- (void)cancelOutTimeTask:(NSString *)msgId{
    dispatch_block_t block = self.outTimeDict[msgId];
    if (block) {
        [XYChatDelayedTaskTool cancelBlock:block];
    }
}

#pragma mark - XYWebSocketDelegate
- (void)webSocketDidConnect:(XYWebSocket *)webSocket{
    NSArray *delegates = [self allDelegate];
    for (id<XYChatServiceManagerDelegate> delegate in delegates) {
        if ([delegates respondsToSelector:@selector(chatServiceManagerConnectSucc:)]) {
            [delegate chatServiceManagerConnectSucc:self];
        }
    }
}

- (void)webSocket:(XYWebSocket *)webSocket connectFail:(NSError *)err{
    NSArray *delegates = [self allDelegate];
    for (id<XYChatServiceManagerDelegate> delegate in delegates) {
        if ([delegates respondsToSelector:@selector(chatServiceManagerConnectFail:)]) {
            [delegate chatServiceManagerConnectFail:self];
        }
    }
}

- (void)webSocketDidDisconnect:(XYWebSocket *)webSocket{
    [self loginWithSessionId:self.sessionId];
    NSArray *delegates = [self allDelegate];
    for (id<XYChatServiceManagerDelegate> delegate in delegates) {
        if ([delegates respondsToSelector:@selector(chatServiceManagerDisconnect:)]) {
            [delegate chatServiceManagerDisconnect:self];
        }
    }
}

-(void)webSocket:(XYWebSocket *)webSocket didReceiveMessage:(id)message{
    XYChatReviceMsgBaseModel *baseModel  = [XYChatReviceMsgBaseModel xy_objectWithKeyValues:message];
    [self cancelOutTimeTask:baseModel.message_id];
    
    switch (baseModel.code) {
        case XYChatMsgCode_Receive:
            [self receiveNoneMsg:message];
            break;
        case XYChatMsgCode_Unread:
            [self receiveUnreadMsg:baseModel];
            break;
        case XYChatMsgCode_Confirm:
            [self receiveConfirmMsg:baseModel];
            break;
        case XYChatMsgCode_Contact:
            [self receiveContactMsg:baseModel];
            break;
        case XYChatMsgCode_History:
            [self receiveHistoryMsg:baseModel];
            break;
        case XYChatMsgCode_LoginOutTime:
            [self receiveLoginOuttime:baseModel];
            break;
        case XYChatMsgCode_Tips:
            [self receiveTips:message];
            break;
        default:
            break;
    }
}

- (void)receiveLoginOuttime:(XYChatReviceMsgBaseModel *)message{
    
}

- (void)receiveTips:(NSDictionary *)message{
    XYChatReviceTipsMsgModel *tipsMsg = [XYChatReviceTipsMsgModel xy_objectWithKeyValues:message];
    if (tipsMsg.message_id.length) {
        
    }
    NSArray *delegates = [self delegatesWithMid:tipsMsg.to_mid];
    for (id<XYChatServiceManagerDelegate> delegate in delegates) {
        if ([delegate respondsToSelector:@selector(chatServiceManager:receiveMsg:)]) {
            [delegate chatServiceManager:self receiveMsg:tipsMsg.message];
        }
    }
}


- (void)receiveNoneMsg:(NSDictionary *)message{
    XYChatReviceTextMsgModel *model = [XYChatReviceTextMsgModel xy_objectWithKeyValues:message];
    [self updateContactWithTextMsgModel:model];

    NSArray *delegates = [self delegatesWithMid:model.from_mid];
    for (id<XYChatServiceManagerDelegate> delegate in delegates) {
        if ([delegate respondsToSelector:@selector(chatServiceManager:receiveMsg:)]) {
            XYChatMsgTextModel *textModel = [XYChatMsgTextModel new];
            textModel.id = model.message_id;
            textModel.content = model.message;
            textModel.createTime = model.create_time;
            textModel.isSend = NO;
            textModel.sendUId = model.from_mid;
            textModel.toUid = self.mid;
            [delegate chatServiceManager:self receiveMsg:textModel];
        }
    }
}

- (void)receiveConfirmMsg:(XYChatReviceMsgBaseModel *)message{
    XYChatSendMsgParams *params =   self.sendMsgDict[message.message_id];
    params.isFinsh = YES;
    if (params.message_id) {
        [self.sendMsgDict removeObjectForKey:params.message_id];
        id  obj = self.sendNoneMsgDict[params.message_id];
        if ([obj isKindOfClass:[XYChatMsgTextModel class]]) {
            XYChatMsgTextModel *textModel = obj;
            if (message.status == -1) {
                textModel.state = XYChatMsgSendState_Fail;
            }else{
                textModel.state = XYChatMsgSendState_None;
            }
            [self.sendNoneMsgDict removeObjectForKey:params.message_id];
        }
    }
}

- (void)receiveUnreadMsg:(XYChatReviceMsgBaseModel *)message{
    self.unreadCount = [message.unread_count integerValue];
}

- (void)receiveContactMsg:(XYChatReviceMsgBaseModel *)message{
    NSArray *contactArr = [XYChatContactModel xy_objectArrayWithKeyValuesArray:message.data];
    [self updateContactList:contactArr];
    void(^callback)(BOOL succ,NSArray *arr) = self.callbackDict[message.message_id];
    if (callback) {
        XYWeakSelf;
        XY_Dispatch_main_async_safe(^{
            callback(YES,weakSelf.contactList);
        });
        [self.callbackDict removeObjectForKey:message.message_id];
    }
}

- (void)receiveHistoryMsg:(XYChatReviceMsgBaseModel *)message{
    NSArray *msgArr = [XYChatMsgTextModel xy_objectArrayWithKeyValuesArray:message.data];
    void(^callback)(BOOL succ,NSArray *arr) = self.callbackDict[message.message_id];
    if (callback) {
        XY_Dispatch_main_async_safe(^{
            callback(YES,msgArr);
        });
        [self.callbackDict removeObjectForKey:message.message_id];
    }
}

#pragma mark - 联系人管理
- (void)updateContactWithTextMsgModel:(XYChatReviceTextMsgModel *)msgModel{
    if(![msgModel.from_mid isEqualToString:self.mid]){
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"toUserId = %@",msgModel.from_mid];
        XYChatContactModel *contact = [[self.contactList filteredArrayUsingPredicate:predicate] firstObject];
        if (contact == nil) {
            contact = [XYChatContactModel new];
            [self.contactList addObject:contact];
        }
        contact.toUserId = msgModel.from_mid;
        contact.msg = msgModel.message;
        contact.time = [NSString stringWithFormat:@"%0.f",msgModel.create_time];
        contact.unreadCount = msgModel.unread_count;
        contact.name = msgModel.from_nickname;
        contact.iconUrl = msgModel.from_userface;
        
        NSSortDescriptor *sorkDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"time" ascending:NO];
        [self.contactList sortUsingDescriptors:@[sorkDescriptor]];
        [self changeContactListCallback];
    }
}

- (void)updateContactList:(NSArray *)contactList{
    self.contactList = [contactList mutableCopy];
    NSSortDescriptor *sorkDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"time" ascending:NO];
    [self.contactList sortUsingDescriptors:@[sorkDescriptor]];
    [self changeContactListCallback];
}

- (void)changeContactListCallback{
    NSArray *delegates = [self allDelegate];
    for (id<XYChatServiceManagerDelegate> delegate in delegates) {
        if ([delegate respondsToSelector:@selector(chatService:changeContacts:)]) {
            [delegate chatService:self changeContacts:self.contactList];
        }
    }
}

#pragma mark - 属性
- (XYWebSocket *)webSocket{
    if (_webSocket == nil) {
        _webSocket = [[XYWebSocket alloc]init];
        [_webSocket addDelegate:self];
    }
    return _webSocket;
}

- (NSMutableDictionary *)delegateDic{
    if (_delegateDic == nil) {
        _delegateDic = [NSMutableDictionary new];
    }
    return _delegateDic;
}

- (NSMutableArray *)commonDelegates{
    if (_commonDelegates == nil) {
        _commonDelegates = [NSMutableArray new];
    }
    return _commonDelegates;
}

- (NSMutableDictionary *)callbackDict{
    if (_callbackDict == nil) {
        _callbackDict = [NSMutableDictionary new];
    }
    return _callbackDict;
}

- (NSMutableDictionary *)sendMsgDict{
    if (_sendMsgDict == nil) {
        _sendMsgDict = [NSMutableDictionary new];
    }
    return _sendMsgDict;
}

- (NSMutableDictionary *)sendNoneMsgDict{
    if (_sendNoneMsgDict == nil) {
        _sendNoneMsgDict = [NSMutableDictionary new];
    }
    return _sendNoneMsgDict;
}


- (NSMutableDictionary *)outTimeDict{
    if (_outTimeDict == nil) {
        _outTimeDict = [NSMutableDictionary new];
    }
    return _outTimeDict;
}

- (void)setUnreadCount:(NSUInteger)unreadCount{
    [self willChangeValueForKey:@"unreadCount"];
    _unreadCount = unreadCount;
    [self didChangeValueForKey:@"unreadCount"];
}

- (void)setMid:(NSString *)mid{
    if (![_mid isEqualToString:mid]) {
        XYChatDataManager *manager = [XYChatDataManager shareInstance];
        [manager connectWithMid:mid];
    }
    _mid = mid;
}
@end
