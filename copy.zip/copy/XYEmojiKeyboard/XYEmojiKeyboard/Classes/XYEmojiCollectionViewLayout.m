//
//  XYEmojiCollectionViewLayout.m
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/15.
//

#import "XYEmojiCollectionViewLayout.h"

@implementation XYEmojiCollectionViewLayout
- (NSArray<UICollectionViewLayoutAttributes *> *)layoutAttributesForElementsInRect:(CGRect)rect{
    
    NSArray *attArr = [super layoutAttributesForElementsInRect:rect];

    for (UICollectionViewLayoutAttributes* att in attArr) {
        CGSize size = att.size;
        NSInteger page = att.indexPath.section;
        CGFloat x = (att.indexPath.row % kEmojiColumnCount) * size.width + page * self.collectionView.frame.size.width;
        CGFloat y = ((att.indexPath.row / kEmojiColumnCount) % kEmojiRowCount) * size.height;
        CGRect frame = att.frame;
        frame.origin.x = x;
        frame.origin.y = y;
        att.frame = frame;
    }
    
    return attArr;
}

@end
