//
//  XYResponseModel.h
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import <Foundation/Foundation.h>

@interface XYResponseModel : NSObject


/**
 任务
 */
@property (nonatomic, strong) id task;


/**
 基础模型
 */
@property (nonatomic, strong) id baseModel;

/**
 错误信息
 */
@property (nonatomic, strong) NSError *err;

/**
 提示信息
 */
@property (nonatomic,copy) NSString *tipMsg;


/**
 根据task和基础模型创建实例

 @param task 任务
 @param baseModel 基础模型
 @return 相应模型
 */
+(XYResponseModel *)newWithTask:(id)task baseModel:(id)baseModel;


/**
 根据task和基础模型创建实例
 
 @param task 任务
 @param err 错误
 @return 相应模型
 */
+(XYResponseModel *)newWithTask:(id)task err:(NSError *)err;
    
@end
