//
//  XYChatModalityController.m
//  MJExtension
//
//  Created by henry on 2018/9/27.
//

#import "XYChatModalityController.h"
#import "XYChatContactVC.h"
#import "XYChatVC.h"
#import <XYNavigationController/XYPickerPresent.h>
#import <XYNavigationController/XYPickerDismiss.h>
#import <XYCategory/XYCategory.h>

@interface XYChatModalityController ()<UIViewControllerTransitioningDelegate>

@end

@implementation XYChatModalityController

+ (instancetype)initContactVC{
    XYChatContactVC *contactVC = [XYChatContactVC new];
    XYChatModalityController *vc = [[XYChatModalityController alloc]initWithRootViewController:contactVC];;
    return vc;
}

+ (instancetype)initChatVCWithContactModel:(XYChatContactModel *)contactModel{
    XYChatVC *chatVC = [[XYChatVC alloc]initWithChatContactModel:contactModel];
    XYChatModalityController *vc = [[XYChatModalityController alloc]initWithRootViewController:chatVC];;
    return vc;
}

- (instancetype)initWithRootViewController:(UIViewController *)rootViewController{
    self = [super initWithRootViewController:rootViewController];
    if (self) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;

    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#define kHeight ({\
static CGFloat kContentHeight =  0;\
static dispatch_once_t onceToken;\
dispatch_once(&onceToken, ^{\
    kContentHeight = [UIScreen mainScreen].bounds.size.height - 200;\
    kContentHeight = kContentHeight < 480 ? 480 :kContentHeight;\
});\
kContentHeight;\
})

//static CGFloat kHeight = 388;

#pragma mark - UIViewControllerTransitioningDelegate -
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return ({
        XYPickerPresent *present =  [XYPickerPresent new];
        present.viewSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, kHeight);
        present;
    });
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return ({
        XYPickerDismiss *dismiss =  [XYPickerDismiss new];
        dismiss;
    });
}

- (void)xy_dismissVC{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 其他方法
- (void)recoveryLayout{
    self.view.alpha = 0;
    self.view.xy_height = kHeight;
    self.view.xy_bottom = [UIScreen mainScreen].bounds.size.height;
    [UIView animateWithDuration:0.2 animations:^{
        self.view.alpha = 1;
    }];
}

- (void)hiddenLayout{
    self.view.alpha = 0;
}
@end
