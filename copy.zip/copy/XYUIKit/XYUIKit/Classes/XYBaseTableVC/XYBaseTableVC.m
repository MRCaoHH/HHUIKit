//
//  XYBaseTableVC.m
//  Pods-XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//

#import "XYBaseTableVC.h"
#import "XYBTCellConfig.h"
#import <objc/message.h>
#import <ReactiveObjC/ReactiveObjC.h>
#import <ReactiveObjC/NSObject+RACKVOWrapper.h>
#import "UITableViewCell+XYTBCell.h"

@interface XYBaseTableVC (){
    ///是否多个section
    BOOL _isMultipleSection;
}

@end

@implementation XYBaseTableVC

- (instancetype)initWithConfigArr:(NSArray *)configiArr{
    return  [self initWithConfigArr:configiArr actionProtocol:nil];
}

- (instancetype)initWithConfigArr:(NSArray *)configiArr actionProtocol:(id<XYBTActionProtocol>)actionProtocol{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
        self.configArr = configiArr;
        self.protocol = actionProtocol;
        self.protocol.vc = self;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.tableHeaderView = ({
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0,self.view.frame.size.width, 15)];
        view;
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 其他方法
+ (XYBTCellConfig *)cellConfigWithArr:(NSArray *)configArr Identifier:(NSString *)identifier{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"identifier = %@",identifier];
    NSMutableArray *sumArr = @[].mutableCopy;
    if ([[configArr firstObject] isKindOfClass:[NSArray class]]) {
        for (NSArray *arr in configArr) {
            [sumArr addObjectsFromArray:arr];
        }
    }else{
        [sumArr addObjectsFromArray:configArr];
    }
    NSArray *arr = [sumArr filteredArrayUsingPredicate:predicate];
    return [arr firstObject];
}

- (id)getValueWithIdentifier:(NSString *)identifier{
    XYBTCellConfig *config = [self cellConfigWithIdentifier:identifier];
    return config.value;
}

- (XYBTCellConfig *)cellConfigWithIdentifier:(NSString *)identifier{
    return [XYBaseTableVC cellConfigWithArr:self.configArr Identifier:identifier];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if(_isMultipleSection){
        return [self.configArr count];
    }
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if(_isMultipleSection){
        NSArray *arr = self.configArr[section];
        return [arr count];
    }
    return [self.configArr count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    XYBTCellConfig *config = nil;
    if(_isMultipleSection){
        NSArray *arr = self.configArr[indexPath.section];
        config = arr[indexPath.row];
    }else{
        config = self.configArr[indexPath.row];
    }
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:config.reuseIdentifier];
    if (cell == nil) {
        Class aclass = NSClassFromString(config.className);
        if (aclass == nil) {
            aclass = [UITableViewCell class];
        }
        cell = [[aclass alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:config.reuseIdentifier];
       
    }
    [cell.xy_disposable dispose];
    
    for (NSString *key in config.attributedDic.allKeys) {
        [cell setValue:config.attributedDic[key] forKeyPath:key];
    }
    
    if (config.value) {
        [cell setValue:config.value forKeyPath:config.valueKey];
    }
    
    if (config.valueKey){
        cell.xy_disposable =  [cell rac_observeKeyPath:config.valueKey options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld observer:self block:^(id value, NSDictionary *change, BOOL causedByDealloc, BOOL affectedOnlyLastComponent) {
            config.value =  value;
        }];
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    XYBTCellConfig *config = nil;
    if(_isMultipleSection){
        NSArray *arr = self.configArr[indexPath.section];
        config = arr[indexPath.row];
    }else{
        config = self.configArr[indexPath.row];
    }
    SEL action =  NSSelectorFromString(config.action);
    if ([self.protocol respondsToSelector:action]) {
        ((void (*)(id,SEL))objc_msgSend)(self.protocol,action);
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    XYBTCellConfig *config = nil;
    if(_isMultipleSection){
        NSArray *arr = self.configArr[indexPath.section];
        config = arr[indexPath.row];
    }else{
        config = self.configArr[indexPath.row];
    }
    return config.cellHeight;
}


#pragma mark - 属性方法 -
- (void)setConfigArr:(NSArray *)configArr{
    _configArr = configArr;
    id objc= [_configArr firstObject];
    _isMultipleSection = [objc isKindOfClass:[NSArray class]];//如果数组中包含数组就是多个section
}
@end
