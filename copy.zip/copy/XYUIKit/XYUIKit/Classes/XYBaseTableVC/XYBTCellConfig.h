//
//  XYBTCellConfig.h
//  Pods-XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//

#import <Foundation/Foundation.h>

@interface XYBTCellConfig : NSObject

/**
 cell的类名
 */
@property (nonatomic,copy) NSString *className;

/**
 重用id
 */
@property (nonatomic,copy) NSString *reuseIdentifier;

/**
 cell高度
 */
@property (nonatomic,assign) float cellHeight;

/**
 点击的执行的方法
 */
@property (nonatomic,copy) NSString *action;

/**
 cell的属性键值
 */
@property (nonatomic,strong) NSDictionary *attributedDic;

/**
 唯一标识
 */
@property (nonatomic,copy) NSString *identifier;

/**
 输出值得键名
 */
@property (nonatomic,copy) NSString *valueKey;

/**
 值
 */
@property (nonatomic,strong) id value;

@end
