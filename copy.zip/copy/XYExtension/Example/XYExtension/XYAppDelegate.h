//
//  XYAppDelegate.h
//  XYExtension
//
//  Created by henry on 10/26/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

@import UIKit;

@interface XYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
