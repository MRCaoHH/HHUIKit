//
//  XYChatVC.m
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import "XYChatVC.h"
#import "XYChatVCDefaultProtocol.h"
#import "XYChatHeaderDelegate.h"
#import "XYChatFooterDelegate.h"
#import <XYCategory/XYCategory.h>
#import <XYRefresh/XYRefresh.h>
#import "XYChatContactModel.h"

@interface XYChatVC ()<UITableViewDelegate,UITableViewDataSource,XYChatFooterDelegate,XYChatHeaderDelegate,UIScrollViewDelegate>
@property (nonatomic,strong) UITapGestureRecognizer *tapGestureRecognizer;
@property (nonatomic,assign) BOOL flag;
@end

@implementation XYChatVC
#pragma mark - 构造方法
- (instancetype)initWithProtocol:(id<XYChatVCProtocol>)protocol{
    self = [self initWithProtocol:protocol chatContactModel:nil];
    return self;
}

- (instancetype)initWithChatContactModel:(XYChatContactModel *)model{
    self = [self initWithProtocol:nil chatContactModel:model];
    return self;
}

- (instancetype)initWithMid:(NSString *)mid name:(NSString *)name{
    XYChatContactModel *model  = [XYChatContactModel new];
    model.name = name;
    model.toUserId = mid;
    self = [self initWithProtocol:nil chatContactModel:model];
    return self;
}

- (instancetype)init{
    return [self initWithProtocol:nil chatContactModel:nil];
}

- (instancetype)initWithProtocol:(id<XYChatVCProtocol>)protocol chatContactModel:(XYChatContactModel *)model{
    self = [super init];
    if (self) {
        _protocol = protocol;
        if (_protocol == nil) {
            _protocol = [XYChatVCDefaultProtocol new];
        }
        _protocol.chatVC = self;
        _protocol.contactModel = model;
        _contactModel = model;
    }
    return self;
}

#pragma mark - 父类方法 -
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initSubview];
    [self adjustSubviewLayout];
    self.title = self.contactModel.name;
    [self loadMoreData];
    [self addObserver:self forKeyPath:@"view.frame" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:nil];
}

- (void)dealloc{
    [self removeObserver:self forKeyPath:@"view.frame"];
    [self.protocol leaveRoom];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    if ([keyPath isEqualToString:@"view.frame"]) {
        [self adjustSubviewLayout];
    }
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if (!self.flag) {
        self.flag = YES;
        [self adjustSubviewLayout];
        [self scrollToBottom:NO];
    }
    [self.protocol enterRoom];
}

#pragma mark - 初始化 -
- (void)initSubview{
    _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    
    _headerView = self.protocol.headerView;
    _headerView.headerDelegate = self;
    [self.view addSubview:_headerView];
    
    _footerView = self.protocol.footerView;
    _footerView.footerDelegate = self;
    [self.view addSubview:_footerView];

    
    _headerView.backgroundColor = [UIColor redColor];
    _tableView.backgroundColor = [UIColor xy_colorWithHexString:@"#EBEBEB"];
    self.automaticallyAdjustsScrollViewInsets = NO;

    __weak typeof(self) weakSelf = self;
    [XYRefresh addHeaderRefresh:self.tableView refreshingBlock:^{
        [weakSelf loadMoreData];
    }];
    
    
    _tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapHidenKeyBoard)];
    _tapGestureRecognizer.enabled = self.footerView.isExpand;
    [self.tableView addGestureRecognizer:_tapGestureRecognizer];
}

- (void)tapHidenKeyBoard{
    [self.footerView dragTableView];
}

- (void)loadMoreData{
    __weak typeof(self) weakSelf = self;
    [weakSelf.protocol loadMore:^{
        [XYRefresh endHeaderRefresh:weakSelf.tableView];
        [weakSelf.tableView reloadData];
    }];
}

#pragma mark - 调节布局
- (void)adjustSubviewLayout{
    CGFloat headerViewHeight = _headerView.frame.size.height;
    CGRect tabarFrame = [self.navigationController.navigationBar convertRect:self.navigationController.navigationBar.bounds toView:self.view];
    CGFloat headerY = CGRectGetMaxY(tabarFrame);
    _headerView.frame = CGRectMake(0, headerY, self.view.frame.size.width, headerViewHeight);
    
    CGFloat footerViewHeight = _footerView.frame.size.height;
    _footerView.frame = CGRectMake(0 , self.view.frame.size.height - footerViewHeight, self.view.frame.size.width, footerViewHeight);
    
    CGRect tableViweFrame = CGRectMake(0, CGRectGetMaxY(_headerView.frame), self.view.frame.size.width, CGRectGetMinY(_footerView.frame) - CGRectGetMaxY(_headerView.frame));
    [self adjustTableViewContentOffset:tableViweFrame];
    _tableView.frame = tableViweFrame;

}

- (void)adjustTableViewContentOffset:(CGRect)tableViweFrame{
    CGPoint contentOffset = _tableView.contentOffset;
    if (_tableView.contentOffset.y + _tableView.xy_height >= _tableView.contentSize.height) {
        //滚动到底部
        contentOffset.y = _tableView.contentSize.height - tableViweFrame.size.height;
    }else if(_tableView.contentSize.height <= tableViweFrame.size.height){
        contentOffset.y = 0;
    }else{
        //
        contentOffset.y =  _tableView.contentOffset.y + _tableView.xy_height - tableViweFrame.size.height;
    }
    contentOffset.y = contentOffset.y < 0 ? 0:contentOffset.y;
    [_tableView setContentOffset:contentOffset];
}

- (void)scrollToBottom:(BOOL)animated{
    NSInteger row =  [self.protocol.msgArr count] - 1;
    if ( row >=0) {
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:row inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:animated];
    }
    
}
#pragma mark - 协议 -
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.protocol getCellCountWithTableView:tableView];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [self.protocol getCellWithTableView:tableView indexPath:indexPath];
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [self.protocol getCellHeightWithTableView:tableView indexPath:indexPath];
}


#pragma mark - XYChatHeaderDelegate
- (void)chatHeader:(id<XYChatHeaderProtocol>)chatHeader changeFrame:(CGRect)frame{
    [self adjustSubviewLayout];
}

#pragma mark - XYChatFooterDelegate
- (void)chatFooter:(id<XYChatFooterProtocol>)footerView sendMsg:(id)msg{
    [self.protocol sendMsg:msg];
}

- (void)chatFooter:(id<XYChatHeaderProtocol>)chatFooter changeFrame:(CGRect)frame{
    [self adjustSubviewLayout];
}

- (void)chatFooter:(id<XYChatFooterProtocol>)footerView didSelectItem:(XYChatPlusItem *)item{
    [self.protocol selectPlusItem:item];
}

- (void)chatFooter:(id<XYChatFooterProtocol>)footerView isExpand:(BOOL)isExpand{
    _tapGestureRecognizer.enabled = self.footerView.isExpand;
}

@end
