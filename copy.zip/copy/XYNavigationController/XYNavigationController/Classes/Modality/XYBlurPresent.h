//
//  XYBlurPresent.h
//  XYNavigationController
//
//  Created by caohuihui on 2017/12/07.
//  Copyright © 2017年 Xin YI. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,XYBlurPresentAnimateType){
    XYBlurPresentAnimateType_EaseInOut = 0,//淡入淡出
    XYBlurPresentAnimateType_BottomPsuh = 1,//从下面出来
};

@interface XYBlurPresent : NSObject <UIViewControllerAnimatedTransitioning>
@property (nonatomic, assign) CGSize viewSize;
@property (nonatomic,assign) NSTimeInterval duration;
@property (nonatomic,assign) XYBlurPresentAnimateType type;

/**
 开始执行动画回调
 */
@property (nonatomic,copy) void(^presentAnimate)(void);

@end
