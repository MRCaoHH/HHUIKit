//
//  XYRequestModel.h
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import <Foundation/Foundation.h>

@interface XYRequestModel : NSObject
    
@property (nonatomic, strong) id task;
    
+ (XYRequestModel *)newWithTask:(id)task;
- (BOOL)isFinish;
- (void)cancel;
    
@end
