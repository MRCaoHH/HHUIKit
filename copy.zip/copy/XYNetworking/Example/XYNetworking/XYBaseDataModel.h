//
//  XYBaseDataModel.h
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//  Copyright © 2017年 Henry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYBaseDataModel : NSObject
@property (nonatomic,copy) NSString *text;
@property (nonatomic,copy) NSString *code;
@end
