//
//  XYWebSocketProtocol.h
//  XYWebSocket
//
//  Created by henry on 2017/11/28.
//

#import <Foundation/Foundation.h>

@interface XYWebSocketProtocol : NSObject
/**
 注册的类
 */
@property (nonatomic, class, readonly) Class regisclass;

/**
 注册协议对象
 
 @param aclass 对象类
 */
+ (BOOL)registerClass:(Class)aclass;


/**
 取消注册协议对象
 
 @param aclass 对象类
 */
+ (void)unregisterClass:(Class)aclass;


/**
 转换接收的消息类型

 @param message 消息
 @return 新消息
 */
- (id)convertReceiveMessage:(id)message;
@end
