//
//  XYChatContactModel.h
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import <Foundation/Foundation.h>
@class XYChatMsgBaseModel;
@interface XYChatContactModel : NSObject

/**
 对方的用户id
 */
@property (nonatomic,copy) NSString *toUserId;

/**
 对方用户名
 */
@property (nonatomic,copy) NSString  *name;

/**
 最后一条消息
 */
@property (nonatomic,copy) NSString *msg;

/**
 时间
 */
@property (nonatomic,copy) NSString *time;

/**
 未读数
 */
@property (nonatomic,assign) NSInteger unreadCount;

/**
 头像
 */
@property (nonatomic,copy) NSString *iconUrl;

/**
 显示时间
 */
@property (nonatomic,copy) NSString *displayTime;
@end
