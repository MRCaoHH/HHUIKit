//
//  IFHefeFilter.h
//  GPUImage-Instagram
//
//  Created by Kim Daewook.
//  Copyright (c) 2015 Kim Daewook. All rights reserved.
//

#import "IFImageFilter.h"

@interface IFHefeFilter : IFImageFilter

@end
