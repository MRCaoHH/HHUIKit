//
//  XYAlertPresent.h
//  XYNavigationController
//
//  Created by caohuihui on 2017/12/07.
//  Copyright © 2017年 Xin YI. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYAlertPresent : NSObject <UIViewControllerAnimatedTransitioning>

/**
 视图大小
 */
@property (nonatomic, assign) CGSize viewSize;

/**
 动画时长 默认0.2秒
 */
@property (nonatomic,assign) NSTimeInterval duration;

/**
 背景遮罩颜色 默认 [[UIColor blackColor] colorWithAlphaComponent:0.8]
 */
@property (nonatomic,strong) UIColor *bgColor;

@end
