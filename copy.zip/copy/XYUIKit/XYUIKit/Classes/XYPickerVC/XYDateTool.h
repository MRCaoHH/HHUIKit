//
//  HHDateTool.h
//  HHCalendar
//
//  Created by caohuihui on 16/8/18.
//  Copyright © 2016年 caohuihi. All rights reserved.
//

#ifndef HHDateTool_h
#define HHDateTool_h

#include <stdio.h>
int dayOfWeek(int day, int month, int year);
int monthDayCount(int year, int month);
int leapYear(int year);
#endif /* HHDateTool_h */
