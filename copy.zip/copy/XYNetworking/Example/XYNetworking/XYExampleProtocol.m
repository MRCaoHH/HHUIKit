//
//  XYExampleProtocol.m
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//  Copyright © 2017年 Henry. All rights reserved.
//

#import "XYExampleProtocol.h"
#import "XYBaseDataModel.h"
@import MJExtension;

@implementation XYExampleProtocol

+ (NSString *)host{
    return @"http://www.tuling123.com/openapi/api";
}

+ (void)publicOutParam:(id)dataModel{
    
}

+ (NSDictionary *)publicInputParams{
    return @{@"key":@"c20c3e12f4840ee3564fa795fbc4ac75"};
}

+ (id)handelResponseObject:(id)responseObject{
    XYBaseDataModel *model = [XYBaseDataModel mj_objectWithKeyValues:responseObject];
    return model;
}

@end
