//
//  XYChildViewController.h
//  XYMenuViewController_Example
//
//  Created by henry on 2017/11/3.
//  Copyright © 2017年 henry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYChildViewController : UIViewController

@end
