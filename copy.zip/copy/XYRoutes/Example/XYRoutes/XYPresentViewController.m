//
//  XYPresentViewController.m
//  XYRoutes_Example
//
//  Created by henry on 2017/10/27.
//  Copyright © 2017年 henry. All rights reserved.
//

#import "XYPresentViewController.h"

@interface XYPresentViewController ()

@end

@implementation XYPresentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor purpleColor];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 120, 60)];
    [btn setTitle:@"dismiss" forState:UIControlStateNormal];
    btn.backgroundColor = [UIColor orangeColor];
    btn.center = self.view.center;
    [btn addTarget:self action:@selector(clickDimissBtn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)clickDimissBtn{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}


- (void)dealloc{
    NSLog(@"%@",NSStringFromSelector(_cmd));
}

@end
