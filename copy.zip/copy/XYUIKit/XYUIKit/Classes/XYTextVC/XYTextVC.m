//
//  XYTextVC.m
//  MJExtension
//
//  Created by henry on 2017/11/22.
//

#import "XYTextVC.h"
#import <XYCategory/XYCategory.h>

@interface XYTextVC ()

@end

@implementation XYTextVC
@synthesize textViewHeight = _textViewHeight;
#pragma mark - 父类方法 -
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initSubview];
}

#pragma mark - 初始化 -
- (void)initSubview{
    self.view.backgroundColor = [UIColor colorWithRed:0.95 green:0.95 blue:0.95 alpha:1.00];
    
    CGRect frame = [self.navigationController.navigationBar convertRect:self.navigationController.navigationBar.bounds toView:self.view];
    _textView = [[UITextView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(frame) + 10, self.view.frame.size.width, self.textViewHeight)];
    _textView.font = [UIFont systemFontOfSize:18];
    _textView.xy_placeholder = self.placeholder;
    _textView.text = self.text;
    [self.view addSubview:_textView];
    [_textView becomeFirstResponder];
    
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem xy_initItemWithTitle:@"完成" titleColor:[UIColor blackColor] titleFont:[UIFont systemFontOfSize:13] target:self action:@selector(clickFinishItem)];
}

#pragma mark - 交互 -
- (void)clickFinishItem{
    [self.view endEditing:YES];
    if (self.finishCallback) {
        self.finishCallback(self, self.textView.text);
    }
}

#pragma mark - 属性方法 -
- (CGFloat)textViewHeight{
    if (_textViewHeight == 0) {
        _textViewHeight = 40;
    }
    return _textViewHeight;
}

- (void)setPlaceholder:(NSString *)placeholder{
    _placeholder = placeholder;
    _textView.xy_placeholder = self.placeholder;
}

- (void)setTextViewHeight:(CGFloat)textViewHeight{
    _textViewHeight = textViewHeight;
    _textView.xy_height = textViewHeight;
}

- (void)setText:(NSString *)text{
    self.textView.text = text;
}

- (NSString *)text{
    return self.textView.text;
}
@end
