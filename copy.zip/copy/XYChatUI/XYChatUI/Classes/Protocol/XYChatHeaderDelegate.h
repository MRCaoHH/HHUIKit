//
//  XYChatHeaderDelegate.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import <Foundation/Foundation.h>
@protocol XYChatHeaderProtocol;
@protocol XYChatHeaderDelegate <NSObject>
@required
- (void)chatHeader:(id<XYChatHeaderProtocol>)chatHeader changeFrame:(CGRect)frame;
@end
