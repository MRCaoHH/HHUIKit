//
//  XYRouteHandle.m
//  XYRoutes_Example
//
//  Created by henry on 2018/4/8.
//  Copyright © 2018年 henry. All rights reserved.
//

#import "XYRouteHandle.h"
#import <objc/runtime.h>
#import <objc/message.h>

@implementation XYRouteHandle

+ (id)sendMsgWithInstance:(id)instance withSelector:(SEL)selector withParams:(NSDictionary *)params{
    id obj = nil;
    switch (params.allKeys.count) {
        case 0:
            obj = ((id (*)(id,SEL))objc_msgSend)(instance,selector);
            break;
        case 1:
            return  [((id (*)(id,SEL,id))objc_msgSend)(instance,selector,params[@0]) autorelease];
            break;
        case 2:
            return  [((id (*)(id,SEL,id,id))objc_msgSend)(instance,selector,params[@0],params[@1]) autorelease];
            break;
        case 3:
            return  [((id (*)(id,SEL,id,id,id))objc_msgSend)(instance,selector,params[@0],params[@1],params[@2]) autorelease];
            break;
        case 4:
            return  [((id (*)(id,SEL,id,id,id,id))objc_msgSend)(instance,selector,params[@0],params[@1],params[@2],params[@3]) autorelease];
            break;
        case 5:
            return  [((id (*)(id,SEL,id,id,id,id,id))objc_msgSend)(instance,selector,params[@0],params[@1],params[@2],params[@3],params[@4]) autorelease];
            break;
        default:
            break;
    }
//    while ([obj retainCount]>1) {
//        [obj release];
//    }
    if ([obj retainCount] > 1) {
        return [obj autorelease];
    }
    return obj;
}

@end
