//
//  XYResponseModel.m
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import "XYResponseModel.h"

@implementation XYResponseModel

+(XYResponseModel *)newWithTask:(id)task baseModel:(id )baseModel{
    XYResponseModel * model = [[XYResponseModel alloc]init];
    model.task = task;
    model.baseModel = baseModel;
    return  model;
}

+(XYResponseModel *)newWithTask:(id)task err:(NSError *)err{
    XYResponseModel * model = [[XYResponseModel alloc]init];
    model.task = task;
    model.err = err;
    return  model;
}

@end
