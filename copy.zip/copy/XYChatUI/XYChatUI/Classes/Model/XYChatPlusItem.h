//
//  XYChatPlusItem.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/16.
//

#import <UIKit/UIKit.h>

@interface XYChatPlusItem : NSObject
@property (nonatomic,strong) UIImage *coverImg;//封面
@property (nonatomic,copy) NSString *title;//标题
@property (nonatomic,copy) NSString *imgName;//图片名字
@end
