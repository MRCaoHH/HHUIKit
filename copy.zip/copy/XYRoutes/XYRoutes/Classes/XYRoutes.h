//
//  XYRoutes.h
//  Pods
//
//  Created by henry on 2017/10/27.
//

#import <Foundation/Foundation.h>
#import <XYRoutes/XYRouteRequest.h>
#import <XYRoutes/XYRouteResponse.h>

/**
 控制页面跳转的路由
 */
@interface XYRoutes : NSObject

/**
 路由列表
 */
@property (class, readonly, strong) NSMutableDictionary *routesMap;


/**
 scheme 名字
 */
@property (nonatomic, readonly) NSString *scheme;


/**
 线路列表
 */
@property (nonatomic, readonly) NSMutableDictionary <NSString *,XYRouteResponse *>*routeMap;


/**
 默认的路由
 */
+ (instancetype)defaultRoutes;


/**
 根据Scheme得到路由
 
 @param scheme scheme名字
 */
+ (instancetype)routesForScheme:(NSString *)scheme;


/**
 根据Scheme注销路由
 
 @param scheme scheme名字
 */
+ (void)unregisterScheme:(NSString *)scheme;


/**
 添加线路
 
 @param routePattern 线路统配符
 @param handelEvent 捕获事件
 */
- (void)addRoute:(NSString *)routePattern handelEvent:(void(^)(NSString *routeUrl,NSDictionary *param))handelEvent;


/**
 移除线路
 
 @param routePattern 线路统配符
 */
- (void)removeRoute:(NSString *)routePattern;



/**
 根据url处理线路
 
 @param url URL
 */
- (BOOL)routeURL:(NSURL *)url;

@end
