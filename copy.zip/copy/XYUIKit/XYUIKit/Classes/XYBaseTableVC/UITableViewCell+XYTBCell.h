//
//  UITableViewCell+XYTBCell.h
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import <UIKit/UIKit.h>
@class RACDisposable;
@interface UITableViewCell (XYTBCell)
@property (nonatomic,strong) RACDisposable *xy_disposable;
@end
