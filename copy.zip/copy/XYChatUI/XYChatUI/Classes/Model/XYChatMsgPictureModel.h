//
//  XYChatMsgPictureModel.h
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import <XYChatUI/XYChatMsgBaseModel.h>

@interface XYChatMsgPictureModel : XYChatMsgBaseModel

/**
 宽度
 */
@property (nonatomic,assign) float width;

/**
 高度
 */
@property (nonatomic,assign) float height;

/**
 缩略图地址
 */
@property (nonatomic,copy) NSString *thumbPicUrl;

/**
 原图地址
 */
@property (nonatomic,copy) NSString *orgPicUrl;

/**
 本地图片
 */
@property (nonatomic,strong) UIImage *localImg;

/**
 进度
 */
@property (nonatomic,assign) NSInteger progress;

/**
 图片上传进度
 */
@property (nonatomic,copy) void(^uploadPicProgress) (NSInteger progress);

/**
 图像的frame
 */
@property (nonatomic,assign) CGRect imgFrame;
@end
