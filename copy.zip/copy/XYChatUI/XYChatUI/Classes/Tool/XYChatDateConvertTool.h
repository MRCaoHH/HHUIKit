//
//  XYChatDateConvertTool.h
//  MJExtension
//
//  Created by henry on 2018/9/29.
//

#import <Foundation/Foundation.h>

@interface XYChatDateConvertTool : NSObject
+ (NSString *)getTimeWithDate:(NSDate *)date;

+ (NSString *)getTimeWithTimeStamp:(NSTimeInterval)timeStamp;
@end
