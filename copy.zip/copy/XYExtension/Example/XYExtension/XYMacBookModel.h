//
//  XYMacBookModel.h
//  XYExtension
//
//  Created by henry on 2017/10/27.
//  Copyright © 2017年 henry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYColorModel : NSObject
@property (nonatomic,copy) NSString *en_name;
@property (nonatomic,copy) NSString *ch_name;
@end

@interface XYMacBookModel : NSObject
@property (nonatomic,copy) NSString *price;
@property (nonatomic,copy) NSString *size;
@property (nonatomic,copy) NSString *display;
@property (nonatomic,copy) NSString *processor;
@property (nonatomic,strong) NSArray *colors;
@property (nonatomic,copy) NSString *memory;
@property (nonatomic,copy) NSString *storage;
@end
