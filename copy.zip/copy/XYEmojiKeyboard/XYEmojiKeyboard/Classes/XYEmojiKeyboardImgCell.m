//
//  XYEmojiKeyboardImgCell.m
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/16.
//

#import "XYEmojiKeyboardImgCell.h"
#import "XYEmojiSourceProtocol.h"

@implementation XYEmojiKeyboardImgCell

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubView];
    }
    return self;
}

- (void)initSubView{
    self.imgView = [UIImageView new];
    self.imgView.translatesAutoresizingMaskIntoConstraints = NO;
    self.imgView.userInteractionEnabled = YES;
    self.imgView.image = [XYEmojiSourceProtocol imageWithName:@"aio_face_delete"];
    self.imgView.highlightedImage = [XYEmojiSourceProtocol imageWithName:@"aio_face_delete_pressed"];
    self.imgView.contentMode =  UIViewContentModeCenter;
    [self addSubview:self.imgView];
    
    NSString *vflH = @"H:|-0-[_imgView]-0-|";
    NSString  *vflV = @"V:|-0-[_imgView]-0-|";
    
    NSDictionary *views =  NSDictionaryOfVariableBindings(_imgView);
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:vflH options:0 metrics:nil views:views]];
    [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:vflV options:0 metrics:nil views:views]];
}

@end
