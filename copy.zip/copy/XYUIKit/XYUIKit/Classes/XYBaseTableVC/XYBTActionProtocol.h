//
//  XYBTActionProtocol.h
//  MJExtension
//
//  Created by henry on 2017/11/22.
//

#import <Foundation/Foundation.h>
@class XYBaseTableVC;
@protocol XYBTActionProtocol <NSObject>
@property (nonatomic,weak) XYBaseTableVC *vc;
@end
