//
//  XYChatFooterDelegate.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import <Foundation/Foundation.h>
@protocol XYChatFooterProtocol;
@class XYChatPlusItem;
@protocol XYChatFooterDelegate <NSObject>
@required

/**
 改变脚视图的frame

 @param footerView 脚视图
 @param frame 位置大小
 */
- (void)chatFooter:(id<XYChatFooterProtocol>)footerView changeFrame:(CGRect)frame;

/**
 脚视图plus选中item，附加功能触发

 @param footerView 脚视图
 @param item 附加item
 */
- (void)chatFooter:(id<XYChatFooterProtocol>)footerView didSelectItem:(XYChatPlusItem *)item;

/**
 发送消息

 @param footerView 脚视图
 @param msg 消息
 */
- (void)chatFooter:(id<XYChatFooterProtocol>)footerView sendMsg:(id)msg;


/**
 展开状态改编
 
 @param isExpand 是否展开
 */
- (void)chatFooter:(id<XYChatFooterProtocol>)footerView isExpand:(BOOL)isExpand;
@end
