//
//  XYAlertController.h
//  XYAlert
//
//  Created by henry on 2017/12/29.
//

#import <UIKit/UIKit.h>
@class YYLabel;
@interface XYAlertController : UIViewController

/**
 标题
 */
@property (nonatomic,strong) YYLabel *titleLabel;

/**
 取消按钮
 */
@property (nonatomic,strong) UIButton *cancelButton;

/**
 确认按钮
 */
@property (nonatomic,strong) UIButton *okButton;

/**
 中间内容页面，子类重写
 */
@property (nonatomic,strong) UIView *contentView;

/**
 内容高度
 */
@property (nonatomic,assign) CGFloat contentHeight;

/**
 初始化方法
 
 @param title 标题
 @param cancelTitle 取消按钮标题
 @param okTitle 确定按钮标题
 @return 实例
 */
- (instancetype)initWithTitle:(NSString *)title cancelTitle:(NSString *)cancelTitle okTitle:(NSString *)okTitle;

/**
 初始化方法
 
 @param title 标题
 @param okTitle 确定按钮标题
 @return 实例
 */
- (instancetype)initWithTitle:(NSString *)title okTitle:(NSString *)okTitle;


/**
 根据属性字符串

 @param title 标题
 @param cancelTitle 取消按钮
 @param okTitle 确定按钮
 @return 实例
 */
- (instancetype)initWithAttributedString:(NSAttributedString *)title cancelTitle:(NSString *)cancelTitle okTitle:(NSString *)okTitle;

/**
 初始化方法
 
 @param title 标题
 @param okTitle 确定按钮标题
 @return 实例
 */
- (instancetype)initWithAttributedString:(NSAttributedString *)title okTitle:(NSString *)okTitle;

/**
 点击确认按钮，回调
 */
@property (nonatomic,copy) void(^clickOkButtonCallback)(XYAlertController *alertVC);

/**
 点击确认按钮，取消
 */
@property (nonatomic,copy) void(^clickCancelButtonCallback)(XYAlertController *alertVC);
@end
