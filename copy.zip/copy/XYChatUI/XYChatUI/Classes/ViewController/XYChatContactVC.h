//
//  XYChatContactVC.h
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import <UIKit/UIKit.h>
@protocol XYChatContactProtocol;

@interface XYChatContactVC : UITableViewController

- (instancetype)initWithProtocol:(id<XYChatContactProtocol>)protocol;

@end
