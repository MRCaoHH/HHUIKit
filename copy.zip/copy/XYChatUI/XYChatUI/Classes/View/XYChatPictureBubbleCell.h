//
//  XYChatPictureBubbleCell.h
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import <XYChatUI/XYChatBubbleCell.h>
@class XYChatMsgPictureModel;
@interface XYChatPictureBubbleCell : XYChatBubbleCell

/**
 图像视图
 */
@property (nonatomic,strong) UIImageView *imgView;

/**
 进度显示
 */
@property (nonatomic,strong) UILabel *progressLabel;

/**
 遮盖层
 */
@property (nonatomic,strong) UIView *coverView;


/**
 根据图像模型计算frame

 @param picModel 图像模型
 */
+ (void)calFrameWithPictModel:(XYChatMsgPictureModel **)picModel;
@end
