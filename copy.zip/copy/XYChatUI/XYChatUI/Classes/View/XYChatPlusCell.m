//
//  XYChatPlusCell.m
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/17.
//

#import "XYChatPlusCell.h"
#import "XYChatPlusItem.h"
#import <XYCategory/XYCategory.h>

@implementation XYChatPlusCell

- (instancetype)initWithFrame:(CGRect)frame{
    self =  [super initWithFrame:frame];
    if (self) {
        [self initSubView];
    }
    return self;
    
}

- (void)initSubView{
    _imgView = [UIImageView new];
    _imgView.xy_size = CGSizeMake(self.xy_width, self.xy_width);
    _imgView.xy_centerX = self.xy_centerX;
    _imgView.layer.cornerRadius = 5;
    _imgView.layer.borderColor = [UIColor colorWithRed:0.86 green:0.86 blue:0.87 alpha:1.00].CGColor;
    _imgView.layer.borderWidth = 1.0 / [UIScreen mainScreen].scale;
    _imgView.backgroundColor = [UIColor colorWithRed:0.98 green:0.98 blue:0.99 alpha:1.00];
    _imgView.contentMode = UIViewContentModeCenter;
    [self addSubview:_imgView];
    
    _nameLabel = [UILabel new];
    _nameLabel.font = [UIFont systemFontOfSize:12];
    _nameLabel.textColor = [UIColor colorWithRed:0.53 green:0.53 blue:0.53 alpha:1.00];
    [self addSubview:_nameLabel];
    
}

#pragma mark - 属性方法 -
- (void)setItem:(XYChatPlusItem *)item{
    _item = item;
    _imgView.image = item.coverImg;
    _imgView.xy_size = CGSizeMake(self.xy_width, self.xy_width);
    _imgView.xy_x = 0;
    
    _nameLabel.text = item.title;
    [_nameLabel sizeToFit];
    _nameLabel.xy_top = _imgView.xy_bottom + 7;
    _nameLabel.xy_centerX = _imgView.xy_centerX;
}
@end
