//
//  XYHUD.h
//  Pods-XYHUD_Example
//
//  Created by henry on 2017/11/13.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface XYHUD : NSObject
+ (void)show;

+ (void)dismiss;

+ (void)dismissWithDelay:(NSTimeInterval)delay;

+ (void)showWithStatus:(NSString*)string;

+ (void)showInfoWithStatus:(NSString*)string;

+ (void)showSuccessWithStatus:(NSString*)string;

+ (void)showErrorWithStatus:(NSString*)string;

+ (void)showImage:(UIImage*)image status:(NSString*)string;
@end
