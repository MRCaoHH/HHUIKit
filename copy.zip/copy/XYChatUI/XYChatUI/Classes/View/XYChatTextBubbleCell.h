//
//  XYChatTextBubbleCell.h
//  MJExtension
//
//  Created by henry on 2017/11/17.
//

#import <XYChatUI/XYChatBubbleCell.h>

@class XYChatMsgTextModel;
@interface XYChatTextBubbleCell : XYChatBubbleCell
+ (void)calFrameWithTextModel:(XYChatMsgTextModel **)textModel;
@end
