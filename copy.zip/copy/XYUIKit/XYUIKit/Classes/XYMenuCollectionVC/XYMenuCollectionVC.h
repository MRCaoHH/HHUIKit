//
//  XYMenuCollectionVC.h
//  XYUIKit
//
//  Created by henry on 2018/1/2.
//

#import <UIKit/UIKit.h>

@interface XYMenuCollectionVC : UICollectionViewController

/**
 数据源items
 */
@property (nonatomic,strong) NSArray *items;

/**
 头部显示
 */
@property (nonatomic,strong) UICollectionReusableView *headerView;

/**
 选中实现的方法目标
 */
@property (nonatomic,strong) id actionTarget;
@end
