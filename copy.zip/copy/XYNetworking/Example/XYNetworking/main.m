//
//  main.m
//  XYNetworking
//
//  Created by Henry on 10/26/2017.
//  Copyright (c) 2017 Henry. All rights reserved.
//

@import UIKit;
#import "XYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XYAppDelegate class]));
    }
}
