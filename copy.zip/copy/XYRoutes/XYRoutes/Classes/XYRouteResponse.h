//
//  XYRouteResponse.h
//  Pods
//
//  Created by henry on 2017/10/27.
//

#import <Foundation/Foundation.h>

/**
 路线结果
 */
@interface XYRouteResponse : NSObject

/**
 地址
 */
@property (nonatomic, strong) NSURL *url;


/**
 路线统配符
 */
@property (nonatomic, copy) NSString *routePattern;

/**
 参数
 */
@property (nonatomic, strong) NSDictionary *params;


/**
 事件处理
 */
@property (nonatomic, copy) void (^routeHandelEvent)(NSString *routeUrl,NSDictionary *params);


/**
 激活路线
 */
- (void)actionRoute;

@end
