//
//  XYMenuViewController.h
//  TestOC
//
//  Created by henry on 2017/11/03.
//  Copyright © 2017年 caohuihui. All rights reserved.
//

#import "YZDisplayViewController.h"
#import "YZDisplayViewHeader.h"
@interface XYMenuViewController : YZDisplayViewController

/**
 初始化viewModel,子类重写
 */
- (void)initViewModel;

/**
 初始化导航栏,子类重写
 */
- (void)initNavBar;

/**
 初始化UI,子类重写
 */
- (void)initUI;

/**
 初始化约束,子类重写
 */
- (void)initConstraint;


/**
 准备选中vc
 */
- (void)didSelectViewController:(UIViewController *)viewController;
@end
