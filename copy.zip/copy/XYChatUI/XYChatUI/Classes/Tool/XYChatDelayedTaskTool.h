//
//  XYChatDelayedTaskTool.h
//  MJExtension
//
//  Created by henry on 2018/9/29.
//

#import <Foundation/Foundation.h>

@interface XYChatDelayedTaskTool : NSObject

+ (dispatch_block_t)createDelayedTask:(int64_t)delayedTime task:(void(^)(void))task;

+ (void)cancelBlock:(dispatch_block_t)block;
@end
