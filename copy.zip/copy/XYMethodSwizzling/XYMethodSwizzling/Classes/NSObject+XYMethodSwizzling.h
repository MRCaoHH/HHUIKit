//
//  NSObject+XYMethodSwizzling.h
//  XYMethodSwizzling
//
//  Created by henry on 2017/12/1.
//

#import <Foundation/Foundation.h>

@interface NSObject (XYMethodSwizzling)

/**
 交换类方法

 @param class 类
 @param originSelector 原方法
 @param otherSelector 替换方法
 */
+ (void)xy_swizzleClassMethod:(Class)class originSelector:(SEL)originSelector otherSelector:(SEL)otherSelector;

/**
 交换实例方法
 
 @param class 类
 @param originSelector 原方法
 @param otherSelector 替换方法
 */
+ (void)xy_swizzleInstanceMethod:(Class)class originSelector:(SEL)originSelector otherSelector:(SEL)otherSelector;
@end
