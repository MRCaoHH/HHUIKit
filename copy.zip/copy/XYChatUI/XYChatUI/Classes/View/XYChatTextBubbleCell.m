//
//  XYChatTextBubbleCell.m
//  MJExtension
//
//  Created by henry on 2017/11/17.
//

#import "XYChatTextBubbleCell.h"
#import "XYChatSourceProtocol.h"
#import <XYCategory/XYCategory.h>
#import "XYChatMsgTextModel.h"

@interface XYChatTextBubbleCell()
@property (nonatomic,strong) UILabel *msgLabel;
@property (nonatomic,strong) UILongPressGestureRecognizer *longPress;
@end

@implementation XYChatTextBubbleCell

static CGFloat kTextFontSize = 14;
static NSString *kReceviveTextColorHex = @"#333333";
static NSString *kSendTextColorHex = @"#000000";

#pragma mark - 初始化 -
- (void)initSubview{
    [super initSubview];
    _msgLabel = [UILabel new];
    _msgLabel.font = [UIFont systemFontOfSize:kTextFontSize];
    _msgLabel.numberOfLines = 0;
    _msgLabel.textColor = [UIColor xy_colorWithHexString:kReceviveTextColorHex];
    [self.bubbleImgView addSubview:_msgLabel];
    
    _longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressEvent:)];
    _longPress.minimumPressDuration = 1;
    self.bubbleImgView.userInteractionEnabled = YES;
    [self.bubbleImgView addGestureRecognizer:_longPress];
    
}
#pragma mark - 其他方法 -
#pragma mark - 计算高度
+ (void)calFrameWithTextModel:(XYChatMsgTextModel **)textModel{
    XYChatMsgTextModel *model = *textModel;
    //计算文本标签的最大宽度
    CGFloat maxWidth = [UIScreen mainScreen].bounds.size.width - kChatLeaveBlankWidth - kChatContentArrowEdge - kChatContentOtheEdge - kChatBubbleEdgeOffset;
    //文本标签的Frame
    CGRect textFrame = [model.content boundingRectWithSize:CGSizeMake(maxWidth, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:kTextFontSize]} context:nil];
    //  _______________________________________________
    //  |                      |                        |
    //  |            kChatContentOtheEdge               |
    //  |                      |                        |
    // < -- kChatContentArrowEdge--   文本  -- kChatContentOtheEdge -- |  外面的框是气泡 接收的消息
    //  |                      |                        |
    //  |            kChatContentOtheEdge               |
    //  |                      |                        |
    //  |______________________|________________________|
    //  _______________________________________________
    //  |                      |                        |
    //  |            kChatContentOtheEdge               |
    //  |                      |                        |
    //  |-- kChatContentOtheEdge --  文本 -- kChatContentArrowEdge --   >  外面的框是气泡 发送的
    //  |                      |                        |
    //  |            kChatContentOtheEdge               |
    //  |                      |                        |
    //  |______________________|________________________|
    textFrame.origin.x = model.isSend ? kChatContentOtheEdge:kChatContentArrowEdge;
    textFrame.origin.y = kChatContentOtheEdge;
    
    CGRect bubbleFrame = [self calBubbleFrameWithContentSize:textFrame.size isSend:model.isSend];
    
    CGFloat cellHeight = [self calCellHeightWithBubbleFrame:bubbleFrame];
    model.bubbleFrame = bubbleFrame;
    model.cellHeight = cellHeight;
    model.msgFrame = textFrame;
    
}

#pragma mark - 复制 -
- (void)longPressEvent:(UILongPressGestureRecognizer *)longPress{
    if (longPress.state == UIGestureRecognizerStateBegan) {
        [self becomeFirstResponder];
        UIMenuController *menuController = [UIMenuController sharedMenuController];
        [menuController setTargetRect:self.bubbleImgView.bounds inView:self.bubbleImgView];
        [menuController setMenuVisible:YES animated:YES];
    }
}

/**
 * 让Label具备成为第一响应者的资格
 */
- (BOOL)canBecomeFirstResponder
{
    return YES;
}

/**
 * 通过第一响应者的这个方法告诉UIMenuController可以显示什么内容
 */
- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if(action == @selector(copy:)){
        return YES;
    }
    return NO;
}

- (void)copy:(UIMenuController *)menu{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = self.msgLabel.text;
}

#pragma mark - 属性方法 -
- (void)setModel:(XYChatMsgBaseModel *)model{
    [super setModel:model];
    XYChatMsgTextModel *textModel = (XYChatMsgTextModel *)model;
    _msgLabel.text = textModel.content;
    _msgLabel.frame = textModel.msgFrame;
}

- (void)setIsSend:(BOOL)isSend{
    [super setIsSend:isSend];
    _msgLabel.textColor = isSend ?[UIColor xy_colorWithHexString:kSendTextColorHex]:[UIColor xy_colorWithHexString:kReceviveTextColorHex];
}

@end
