//
//  UIViewController+LYNavBar.m
//  HHNavBarDemo
//
//  Created by caohuihui on 2017/10/29..
//  Copyright © 2017年 caohuihui. All rights reserved.
//

#import "UIViewController+XYNavBar.h"
#import <objc/runtime.h>
@implementation UIViewController (XYNavBar)

- (BOOL)xy_hiddenNarBar{
    return [objc_getAssociatedObject(self, "xy_hiddenNarBar") boolValue];
}

- (void)setXy_hiddenNarBar:(BOOL)xy_hiddenNarBar{
    objc_setAssociatedObject(self, "xy_hiddenNarBar", @(xy_hiddenNarBar), OBJC_ASSOCIATION_ASSIGN);
}


- (BOOL)xy_disablePopGestureRecognizer{
    return [objc_getAssociatedObject(self, "xy_disablePopGestureRecognizer") boolValue];
}

- (void)setXy_disablePopGestureRecognizer:(BOOL)xy_disablePopGestureRecognizer{
    objc_setAssociatedObject(self, "xy_disablePopGestureRecognizer", @(xy_disablePopGestureRecognizer), OBJC_ASSOCIATION_ASSIGN);
}
@end
