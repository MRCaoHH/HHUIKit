//
//  XYTextFieldAlertController.h
//  XYAlert
//
//  Created by henry on 2017/12/14.
//

#import <XYAlert/XYAlertController.h>

@interface XYTextFieldAlertController : XYAlertController

/**
 文本输入框
 */
@property (nonatomic,strong) UITextField *textField;

@end
