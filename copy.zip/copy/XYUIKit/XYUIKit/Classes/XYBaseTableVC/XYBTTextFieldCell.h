//
//  XYBTTextFieldCell.h
//  MJExtension
//
//  Created by henry on 2017/11/22.
//

#import <UIKit/UIKit.h>

@interface XYBTTextFieldCell : UITableViewCell

/**
 文本输入框
 */
@property (nonatomic,strong) UITextField *textField;

/**
 标题标签
 */
@property (nonatomic,strong) UILabel *titleLabel;

/**
 标题
 */
@property (nonatomic,copy) NSString *title;

/**
 禁止粘贴
 */
@property (nonatomic,assign) BOOL disablePaste;

/**
 边缘距离
 */
@property (nonatomic,assign) CGFloat edgeDistance;

/**
 标题距离左边的边距
 */
@property (nonatomic,assign) CGFloat titleLeftEdge;

/**
 标题左边距
 */
@property (nonatomic,assign) CGFloat textFieldRightEdge;

/**
 输入框的上边距
 */
@property (nonatomic,assign) CGFloat textFieldTopEdge;

/**
 输入框的下边距
 */
@property (nonatomic,assign) CGFloat textFieldBottomEdge;

/**
 占位文字
 */
@property (nonatomic,copy) NSString *placeholder;

/**
 文本内容
 */
@property (nonatomic,copy) NSString *text;

/**
 title 到 titleToTextView的间距
 */
@property (nonatomic,assign) CGFloat titleToTextField;

/**
 文本输入框背景颜色
 */
@property (nonatomic,copy) NSString *textFieldBgColor;

/**
 输入框文本字体颜色
 */
@property (nonatomic,copy) NSString *textFieldTextColor;

/**
 标题字体颜色
 */
@property (nonatomic,copy) NSString *titleTextColor;

/**
 输入框字体大小
 */
@property (nonatomic,assign) CGFloat titleFontSize;

/**
 输入框字体大小
 */
@property (nonatomic,assign) CGFloat textFieldFontSize;
@end
