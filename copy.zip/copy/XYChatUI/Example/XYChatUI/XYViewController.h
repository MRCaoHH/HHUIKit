//
//  XYViewController.h
//  XYChatUI_Example
//
//  Created by henry on 2018/9/27.
//  Copyright © 2018年 henry. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYViewController : UIViewController

@end
