//
//  XYRouteRegularly.h
//  Pods
//
//  Created by henry on 2017/10/27.
//

#import <Foundation/Foundation.h>

/**
 路由正则处理
 */
@interface XYRouteRegularly : NSObject

/**
 匹配路径
 
 @param path 路径
 @param pattern 路线统配符
 @return 匹配结果
 */
+ (BOOL)matchRouteWithPath:(NSString *)path routePattern:(NSString *)pattern;

@end
