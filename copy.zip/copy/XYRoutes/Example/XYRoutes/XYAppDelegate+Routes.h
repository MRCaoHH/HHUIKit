//
//  XYAppDelegate+Routes.h
//  XYLive
//
//  Created by henry on 2017/11/7.
//  Copyright © 2017年 XinYi. All rights reserved.
//

#import "XYAppDelegate.h"

@interface XYAppDelegate (Routes)


/**
 注册路线
 */
- (void)registerRoutes;

- (UIViewController *)currentViewController;
@end
