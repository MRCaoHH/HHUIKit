//
//  XYChatReviceTextMsgModel.m
//  Pods
//
//  Created by henry on 2018/9/29.
//

#import "XYChatReviceTextMsgModel.h"

@implementation XYChatReviceTextMsgModel

@end
