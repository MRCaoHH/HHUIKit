//
//  HHMenuViewController.m
//  FBSnapshotTestCase
//
//  Created by henry on 2017/10/20.
//

#import "XYMBViewController.h"
#import "XYMenuDismissAnimator.h"
#import "XYMenuPresentAnimator.h"
#import "XYMenuButton.h"

@interface XYMBViewController ()<UIViewControllerTransitioningDelegate>{
    UITapGestureRecognizer *_tapGestureRecognizer;
}
@end

@implementation XYMBViewController
static const NSInteger kItemButtonTag = 675;

- (instancetype)initWithMenuButton:(XYMenuButton *)menuButtion{
    self = [super init];
    if (self) {
        _menuButton = menuButtion;
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor clearColor];
    
    _bgView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
    _bgView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    _bgView.layer.opacity = 0;
    _tapGestureRecognizer = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapEvent)];
    [self.view addGestureRecognizer:_tapGestureRecognizer];
    [self.view addSubview:_bgView];
    
    [_menuButton record];
    CGRect frame = [_menuButton convertRect:_menuButton.bounds toView:[UIApplication sharedApplication].keyWindow];
    _menuButton.frame = frame;
    [self.view addSubview:_menuButton];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)showAnimated{
    [_menuButton addTarget:self action:@selector(tapEvent) forControlEvents:UIControlEventTouchUpInside];
    CGFloat centerY = _menuButton.center.y;
    CGFloat preBtnH = _menuButton.frame.size.height;
    for (int i = 0; i < _menuButton.items.count; i++) {
        UIButton *button = _menuButton.items[i];
        button.center = _menuButton.center;
        button.tag = kItemButtonTag + i;
        [button addTarget:self action:@selector(clickMenuButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.view insertSubview:button belowSubview:_menuButton];
        
        CGPoint center = button.center;
        center.y = centerY - (preBtnH/2 + _menuButton.itemSpacing + button.frame.size.height/2);
        button.center = center;
        centerY = center.y;
        preBtnH = button.frame.size.height;
        
        
        CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
        UIBezierPath *bezierPath = [self getPathWithStartPath:_menuButton.center endPoint:button.center];
        animation.path = bezierPath.CGPath;
        animation.fillMode=kCAFillModeForwards;
        animation.removedOnCompletion = NO;
        [button.layer addAnimation:animation forKey:@"offsetAnimation"];
    }
}

- (void)hiddenAnimated{
    [_menuButton removeTarget:self action:@selector(tapEvent) forControlEvents:UIControlEventTouchUpInside];
    for (int i = 0; i < _menuButton.items.count; i++) {
        UIButton *button = [self.view viewWithTag:kItemButtonTag + i];
        [button removeTarget:self action:@selector(clickMenuButton:) forControlEvents:UIControlEventTouchUpInside];
        UIBezierPath *bezierPath = [self getPathWithStartPath:button.center endPoint:_menuButton.center];
        CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
        animation.path = bezierPath.CGPath;
        animation.fillMode=kCAFillModeForwards;
        animation.removedOnCompletion = NO;
        [button.layer addAnimation:animation forKey:@"offsetAnimation"];
    }
}

- (UIBezierPath *)getPathWithStartPath:(CGPoint)startPoint endPoint:(CGPoint)endPoint{
    UIBezierPath *bezierPath = [UIBezierPath bezierPath];
    [bezierPath moveToPoint:startPoint];
    [bezierPath addLineToPoint:endPoint];
    return bezierPath;
}

- (void)clickMenuButton:(UIButton *)btn{
    __weak typeof(self) weakSelf = self;
    [self dismissViewControllerAnimated:YES completion:^{
        if ([weakSelf.menuButton.delegate respondsToSelector:@selector(menuButton:clickIndex:)]) {
            [weakSelf.menuButton.delegate menuButton:weakSelf.menuButton clickIndex:btn.tag - kItemButtonTag];
        }
    }];
}

#pragma mark - tapEvent
- (void)tapEvent{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UIViewControllerTransitioningDelegate
- (id<UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented
                                                                  presentingController:(UIViewController *)presenting
                                                                      sourceController:(UIViewController *)source{
    return ({
        XYMenuPresentAnimator *animator =  [XYMenuPresentAnimator new];
        animator.timeInterval = 0.2;
        animator;
    });
}

- (id<UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return ({
        XYMenuDismissAnimator *animator =  [XYMenuDismissAnimator new];
        animator.timeInterval = 0.2;
        animator;
    });
}


@end
