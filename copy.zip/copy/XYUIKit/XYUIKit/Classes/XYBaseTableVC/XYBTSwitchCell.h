//
//  XYBTSwitchCell.h
//  XYUIKit
//
//  Created by henry on 2017/12/16.
//

#import <UIKit/UIKit.h>

@interface XYBTSwitchCell : UITableViewCell

/**
 开关
 */
@property (nonatomic,strong) UISwitch *switchView;

/**
 标题
 */
@property (nonatomic,strong) UILabel *titleLabel;

/**
 标题字体
 */
@property (nonatomic,assign) CGFloat titleFontSize;

/**
 标题文本颜色
 */
@property (nonatomic,copy) NSString *titleColor;

/**
 标题到边沿的距离
 */
@property (nonatomic,assign) CGFloat titleToEdge;

/**
 开关到边沿的距离
 */
@property (nonatomic,assign) CGFloat switchToEdge;

/**
 开关打开的tintColor
 */
@property (nonatomic,copy) NSString *switchOnTintColor;

/**
 开关关闭的tintColor
 */
@property (nonatomic,copy) NSString *switchTintColor;

/**
 开关Thumb的tintColor
 */
@property (nonatomic,copy) NSString *switchThumbTintColor;

/**
 通知名
 */
@property (nonatomic,copy) NSString *notificationName;


@end
