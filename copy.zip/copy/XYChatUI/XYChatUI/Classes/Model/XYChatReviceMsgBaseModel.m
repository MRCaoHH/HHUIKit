//
//  XYChatReviceMsgBaseModel.m
//  Pods
//
//  Created by henry on 2018/9/28.
//

#import "XYChatReviceMsgBaseModel.h"

@implementation XYChatReviceMsgBaseModel

@end
