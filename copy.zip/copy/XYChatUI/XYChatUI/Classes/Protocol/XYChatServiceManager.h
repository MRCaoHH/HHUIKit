//
//  XYChatServiceManager.h
//  MJExtension
//
//  Created by henry on 2018/9/28.
//

#import <Foundation/Foundation.h>
@class XYChatSendMsgParams;
@class XYChatMsgTextModel;
@class XYChatReviceMsgBaseModel;

@protocol XYChatServiceManagerDelegate;

@interface XYChatServiceManager : NSObject

@property (nonatomic,strong,readonly,class) XYChatServiceManager *shareInstance;

/**
 websocket 地址
 */
@property (nonatomic,copy) NSString *host;

/**
 会话id
 */
@property (nonatomic,copy) NSString *sessionId;

/**
 未读数
 */
@property (nonatomic,assign) NSUInteger unreadCount;

/**
 自己的mid
 */
@property (nonatomic,copy) NSString *mid;

/**
 联系人列表
 */
@property (nonatomic,strong) NSMutableArray *contactList;


/**
 发消息

 @param params 参数
 */
- (void)sendMsg:(XYChatSendMsgParams *)params;

/**
 发送文本消息

 @param textModel 文本消息模型
 */
- (void)sendTextMsg:(XYChatMsgTextModel *)textModel;

/**
 添加代理

 @param delegate 代理
 @param mid 用户id数组 当mid为空数组时接收所有消息
 */
- (void)addDelegate:(id<XYChatServiceManagerDelegate>)delegate subscribeWithMid:(NSString  *)mid;

/**
 添加代理，这里接收所有消息

 @param delegate 代理
 */
- (void)addDelegate:(id<XYChatServiceManagerDelegate>)delegate;

/**
 移除代理

 @param delegate 代理
 */
- (void)removeDelegate:(id<XYChatServiceManagerDelegate>)delegate;

/**
 根据用户id查找消息列表

 @param mid 用户id
 @param messageId 消息id，当消息id为nil时获取最新消息
 @params callback 回调
 */
- (void)queryMsgListWithMid:(NSString *)mid messageId:(NSString *)messageId callback:(void(^)(BOOL succ,NSArray *msgs))callback;

/**
 获取联系人列表

 @param callback 回调
 */
- (void)queryContactList:(void(^)(BOOL succ,NSArray *contactList))callback;

/**
 退出登录
 */
- (void)logout;

/**
 根据sessionId登录

 @param sessionId 会话id
 */
- (void)loginWithSessionId:(NSString *)sessionId;

/**
 不退出登录的情况下更新会话id

 @param sessionId 会话id
 */
- (void)updateSessionId:(NSString *)sessionId;

/**
 标记已读
 
 @param mid mid
 */
- (void)flagReadStataWithMid:(NSString *)mid;


/*****************************************************
 *            接收消息处理子类有必要可以重写               *
 *****************************************************/

/**
 接收登录超时消息

 @param message 消息
 */
- (void)receiveLoginOuttime:(XYChatReviceMsgBaseModel *)message;

/**
 接收正常文本消息

 @param message 消息
 */
- (void)receiveNoneMsg:(NSDictionary *)message;

/**
 接收回复消息

 @param message 消息
 */
- (void)receiveConfirmMsg:(XYChatReviceMsgBaseModel *)message;

/**
 接收未读数消息

 @param message 消息
 */
- (void)receiveUnreadMsg:(XYChatReviceMsgBaseModel *)message;

/**
 接收联系人消息

 @param message 消息
 */
- (void)receiveContactMsg:(XYChatReviceMsgBaseModel *)message;

/**
 接收历史记录消息

 @param message 消息
 */
- (void)receiveHistoryMsg:(XYChatReviceMsgBaseModel *)message;
@end


@protocol XYChatServiceManagerDelegate<NSObject>
@optional

/**
 接收到消息

 @param manager 管理者
 @param msg 消息
 */
- (void)chatServiceManager:(XYChatServiceManager *)manager receiveMsg:(id)msg;

/**
 连接断开

 @param manager 管理者
 */
- (void)chatServiceManagerDisconnect:(XYChatServiceManager *)manager;

/**
 连接成功

 @param manager 管理者
 */
- (void)chatServiceManagerConnectSucc:(XYChatServiceManager *)manager;

/**
 连接失败

 @param manager 管理者
 */
- (void)chatServiceManagerConnectFail:(XYChatServiceManager *)manager;

/**
 退出登录

 @param manager 管理者
 */
- (void)chatServiceLogout:(XYChatServiceManager *)manager;

/**
 联系人改变

 @param manager 管理者
 @param contacts 联系人列表
 */
- (void)chatService:(XYChatServiceManager *)manager changeContacts:(NSArray *)contacts;
@end
