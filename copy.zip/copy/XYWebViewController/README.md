# XYWebViewController

[![CI Status](http://img.shields.io/travis/henry/XYWebViewController.svg?style=flat)](https://travis-ci.org/henry/XYWebViewController)
[![Version](https://img.shields.io/cocoapods/v/XYWebViewController.svg?style=flat)](http://cocoapods.org/pods/XYWebViewController)
[![License](https://img.shields.io/cocoapods/l/XYWebViewController.svg?style=flat)](http://cocoapods.org/pods/XYWebViewController)
[![Platform](https://img.shields.io/cocoapods/p/XYWebViewController.svg?style=flat)](http://cocoapods.org/pods/XYWebViewController)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYWebViewController is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYWebViewController'
```

## Author

henry, henry@xy.com

## License

XYWebViewController is available under the MIT license. See the LICENSE file for more info.
