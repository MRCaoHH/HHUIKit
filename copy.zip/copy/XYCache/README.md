# XYCache

[![CI Status](http://img.shields.io/travis/henry/XYCache.svg?style=flat)](https://travis-ci.org/henry/XYCache)
[![Version](https://img.shields.io/cocoapods/v/XYCache.svg?style=flat)](http://cocoapods.org/pods/XYCache)
[![License](https://img.shields.io/cocoapods/l/XYCache.svg?style=flat)](http://cocoapods.org/pods/XYCache)
[![Platform](https://img.shields.io/cocoapods/p/XYCache.svg?style=flat)](http://cocoapods.org/pods/XYCache)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYCache is available through [CocoaPods](http://cocoapods.org). To install
it, simpXY add the following line to your Podfile:

```ruby
pod 'XYCache'
```

## Author

henry, henry@xxx.com

## License

XYCache is available under the MIT license. See the LICENSE file for more info.
