//
//  XYViewController.m
//  XYFiters
//
//  Created by henry on 11/21/2018.
//  Copyright (c) 2018 henry. All rights reserved.
//

#import "XYViewController.h"
#import "XYViewController2.h"

@interface XYViewController ()
//@property (nonatomic,strong) XYFiterCamera *camera;
@end

@implementation XYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.

    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(100, 500, 60, 30)];
    [button setBackgroundColor:[UIColor redColor]];
    [button setTitle:@"滤镜" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(clickButtonEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    
}

- (void)clickButtonEvent{
    XYViewController2 *vc = [XYViewController2 new];
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
