//
//  XYChatModalityController.h
//  MJExtension
//
//  Created by henry on 2018/9/27.
//

#import <XYNavigationController/XYNavigationController.h>
@class XYChatContactModel;

@interface XYChatModalityController : XYNavigationController

/**
 初始化联系人列表

 @return 实例
 */
+ (instancetype)initContactVC;

/**
 初始化聊天消息列表

 @param contactModel 联系人模型
 @return 实例
 */
+ (instancetype)initChatVCWithContactModel:(XYChatContactModel *)contactModel;

/**
 恢复布局
 */
- (void)recoveryLayout;

/**
 隐藏布局
 */
- (void)hiddenLayout;
@end
