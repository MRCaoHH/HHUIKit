//
//  XYTextFieldAlertController.m
//  XYAlert
//
//  Created by henry on 2017/12/14.
//

#import "XYTextFieldAlertController.h"
#import <XYNavigationController/XYAlertPresent.h>
#import <XYNavigationController/XYAlertDismiss.h>
#import <XYCategory/XYCategory.h>

@interface XYTextFieldAlertController ()
@end

@implementation XYTextFieldAlertController

static CGFloat kTextFiledWidth = 270;
static CGFloat kTextFiledFontSize = 15;
static CGFloat kTextFieldHeight = 37;
static CGFloat kTextFieldFontSize = 15;
static NSString *kTextFieldBgColorHexString = @"#F6F6F6";
static NSString *kTextFieldtTextColorHexString = @"#656565";
static CGFloat kSubviewCornerRadius = 3;

#pragma mark - 父类方法
- (void)viewDidLoad{
    [super viewDidLoad];
    [self addNotification];
}

- (void)dealloc{
    [self removeNotification];
}

#pragma mark - 通知管理 -
#pragma mark - 通知管理
- (void)addNotification{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyBoardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyBoardWillHide:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)removeNotification{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
}


#pragma mark - 键盘管理
- (void)keyBoardWillShow:(NSNotification *)notification{
    NSDictionary *userInfo = notification.userInfo;
    NSNumber *duration = userInfo[UIKeyboardAnimationDurationUserInfoKey];
    NSValue *value = userInfo[UIKeyboardFrameEndUserInfoKey];
    CGRect rect;
    [value getValue:&rect];
    CGFloat curY = self.view.xy_y;
    CGFloat y = [UIScreen mainScreen].bounds.size.height - rect.size.height - self.contentHeight - 10;
    if (y < curY) {
        [UIView animateWithDuration:duration.floatValue animations:^{
            self.view.xy_top = y;
        }];
    }
}

- (void)keyBoardWillHide:(NSNotification *)notification{
    NSDictionary *userInfo = notification.userInfo;
    NSNumber *duration = userInfo[UIKeyboardAnimationDurationUserInfoKey];
    [UIView animateWithDuration:duration.floatValue animations:^{
        CGFloat orgBottom = ([UIScreen mainScreen].bounds.size.height - self.contentHeight)/2 + self.contentHeight;
        self.view.xy_bottom = orgBottom;
    }];
}

#pragma mark - 属性方法
- (UIView *)contentView{
    return self.textField;
}

- (UITextField *)textField{
    if (_textField == nil) {
        _textField = [[UITextField alloc]initWithFrame:CGRectMake(0,0, kTextFiledWidth, kTextFieldHeight)];
        _textField.font = [UIFont systemFontOfSize:kTextFiledFontSize];
        _textField.backgroundColor = [UIColor xy_colorWithHexString:kTextFieldBgColorHexString];
        _textField.textColor = [UIColor xy_colorWithHexString:kTextFieldtTextColorHexString];
        _textField.layer.cornerRadius = kSubviewCornerRadius;
        _textField.font = [UIFont systemFontOfSize:kTextFieldFontSize];
        _textField.leftViewMode = UITextFieldViewModeAlways;
        _textField.leftView =({
            UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, kTextFieldHeight)];
            view;
        });
        _textField.rightViewMode = UITextFieldViewModeAlways;
        _textField.rightView =({
            UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, 10, kTextFieldHeight)];
            view;
        });
        _textField.layer.masksToBounds = YES;
    }
    return _textField;
}
@end
