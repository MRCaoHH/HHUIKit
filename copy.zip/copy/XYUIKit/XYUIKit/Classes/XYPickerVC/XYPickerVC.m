//
//  XYPickerVC.m
//  XYUIKit
//
//  Created by henry on 2017/12/23.
//

#import "XYPickerVC.h"
#import <XYNavigationController/XYPickerDismiss.h>
#import <XYNavigationController/XYPickerPresent.h>
#import "XYPickerHeaderView.h"
@interface XYPickerVC ()<UIViewControllerTransitioningDelegate,UIPickerViewDataSource,UIPickerViewDelegate,XYPickerHeaderViewDelegate>{
    NSUInteger _component;
}
@property (nonatomic,strong) XYPickerHeaderView *headerView;
@property (nonatomic,strong) UIPickerView *pickerView;
@property (nonatomic,strong) NSMutableDictionary *componentSelDic;
@end

@implementation XYPickerVC
static CGFloat kPickerViewHeight = 200;
- (instancetype)initWithTitleArr:(NSArray <id<XYPickerItem>>*)titlArr;{
    self = [super init];
    if (self) {
        self.titleArr = titlArr;
        self.modalPresentationStyle = UIModalPresentationCustom;
        self.transitioningDelegate = self;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initSubview];
    for (NSNumber *component in self.componentSelDic.allKeys) {
        NSInteger row = [self.componentSelDic[component] integerValue];
        [self.pickerView selectRow:row inComponent:[component integerValue] animated:NO];
        [self pickerView:self.pickerView didSelectRow:row inComponent:[component integerValue]];
    }
}

#pragma mark - 初始化 -
- (void)initSubview{
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.headerView];
    [self.view addSubview:self.pickerView];
}

#pragma mark - 其他方法 -
- (void)setSelectRow:(NSInteger)row component:(NSInteger)component{
    if (component >= _component) {
        return;
    }
    [self.componentSelDic setObject:@(row) forKey:@(component)];
    [self.pickerView selectRow:row inComponent:component animated:NO];
    [self pickerView:self.pickerView didSelectRow:row inComponent:component];
}

#pragma mark - 协议 -
#pragma mark - UIViewControllerTransitioningDelegate
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return ({
        XYPickerPresent *present = [XYPickerPresent new];
        present.viewSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, kXYPickerHeaderViewHeight+kPickerViewHeight);
        present;
    });
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return ({
        XYPickerDismiss *dismiss = [XYPickerDismiss new];
        dismiss;
    });
}

#pragma mark - XYPickerHeaderViewDelegate
- (void)clickOkButtonEvent{
    if (self.clickOkButtonCallback) {
        self.clickOkButtonCallback(self.headerView.titleLabel.text);
    }
    if ([self.delegate respondsToSelector:@selector(pickerVC:didClickOkBtn:)]) {
        NSMutableArray *mutableArr = @[].mutableCopy;
        for (int i = 0; i< _component; i++) {
            NSArray * arr =  [self getComponentArr:_titleArr currentComponent:0 component:i];
            NSInteger index =  [self.componentSelDic[@(i)] integerValue];
            if (index < arr.count) {
                [mutableArr addObject:arr[index]];
            }
        }
        [self.delegate pickerVC:self didClickOkBtn:mutableArr];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)clickCancelButtonEvent{
    if ([self.delegate respondsToSelector:@selector(pickerVCDidClickCancelBtn:)]) {
        [self.delegate pickerVCDidClickCancelBtn:self];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return _component;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    NSArray *arr = [self getComponentArr:_titleArr currentComponent:0 component:component];
    return [arr count];
}

#pragma mark - UIPickerViewDelegate
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    return pickerView.frame.size.width / _component;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 30;
}

- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    NSArray *arr = [self getComponentArr:_titleArr currentComponent:0 component:component];
    if ([arr count]<=row) {
        return @"";
    }
    
    id obj = arr[row];
    if ([obj isKindOfClass:[NSString class]]) {
        return obj;
    }
    if ([obj respondsToSelector:@selector(title)]) {
        return [obj performSelector:@selector(title)];
    }
    return @"";
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    NSInteger componentDef = _component - component;
    [self.componentSelDic setObject:@(row) forKey:@(component)];
    for (int i = 1; i<componentDef; i++) {
        [pickerView reloadComponent:component+i];
        [pickerView selectRow:0 inComponent:component + i animated:NO];
        [self.componentSelDic setObject:@(0) forKey:@(component + i)];
    }
    
    NSMutableString *mutableString = @"".mutableCopy;
    for (int i = 0; i< _component; i++) {
        NSInteger aRow = [self.componentSelDic[@(i)] integerValue];
        NSString *title =  [self pickerView:pickerView titleForRow:aRow forComponent:i];
        [mutableString appendString:title];
        [mutableString appendString:@" "];
    }
    _headerView.titleLabel.text = mutableString;
    
    if ([self.delegate respondsToSelector:@selector(pickerVC:titleDidChange:)]) {
        [self.delegate pickerVC:self titleDidChange:_headerView.titleLabel.text];
    }
}
#pragma mark - 属性方法 -
- (void)setTitleArr:(NSArray *)titleArr{
    _titleArr = titleArr;
    _component = [self countComponent:_titleArr.firstObject component:1];
    for (int i = 0; i< _component; i++) {
        [self setSelectRow:0 component:i];
    }
}

- (NSInteger)countComponent:(id<XYPickerItem>)obj component:(NSInteger)compnent{
    if ([obj.subTitle count]) {
        compnent +=1;
        NSArray *arr = obj.subTitle;
        return [self countComponent:[arr firstObject] component:compnent];
    }
    return compnent;
}

- (NSArray *)getComponentArr:(NSArray *)arr currentComponent:(NSInteger)currentComponent component:(NSInteger)component{
    if (component<= 0) {
        return arr;
    }
    NSInteger index = [self.componentSelDic[@(currentComponent)] integerValue];
    id<XYPickerItem> item = arr[index];
    return [self getComponentArr:item.subTitle currentComponent:currentComponent+1 component:component - 1];
}

- (XYPickerHeaderView *)headerView{
    if (_headerView == nil) {
        _headerView = [XYPickerHeaderView new];
        _headerView.backgroundColor = [UIColor whiteColor];
        _headerView.delegate = self;
    }
    return _headerView;
}

- (UIPickerView *)pickerView{
    if (_pickerView == nil) {
        _pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, kXYPickerHeaderViewHeight, self.view.frame.size.width, kPickerViewHeight)];
        _pickerView.delegate = self;
        _pickerView.dataSource = self;
        _pickerView.backgroundColor = [UIColor colorWithRed:0.97 green:0.97 blue:0.97 alpha:1.00];
    }
    return _pickerView;
}

- (NSMutableDictionary *)componentSelDic{
    if (_componentSelDic == nil) {
        _componentSelDic = @{}.mutableCopy;
    }
    return _componentSelDic;
}
@end

@implementation XYPickerItemModel

@end
