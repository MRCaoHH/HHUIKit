//
//  XYBlurPresent.m
//  XYNavigationController
//
//  Created by caohuihui on 2017/12/07.
//  Copyright © 2017年 Xin YI. All rights reserved.
//

#import "XYBlurPresent.h"
#import <POP/POP.h>

@implementation XYBlurPresent
- (instancetype)init{
    self = [super init];
    if (self) {
        self.duration = 0.2;
        self.type = XYBlurPresentAnimateType_EaseInOut;
    }
    return self;
}

- (NSTimeInterval)transitionDuration:(id <UIViewControllerContextTransitioning>)transitionContext{
    return self.duration;
}

- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext
{
    UIView *fromView = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey].view;
    fromView.tintAdjustmentMode = UIViewTintAdjustmentModeDimmed;
    
    UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    UIVisualEffectView *dimmingView = [[UIVisualEffectView alloc] initWithEffect:effect];
    dimmingView.frame = fromView.bounds;
    dimmingView.layer.opacity = 1.0;
    [self addTapDismissGuesture:dimmingView toViewController:[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey]];
    
    UIView *toView = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey].view;
    

    [transitionContext.containerView addSubview:dimmingView];
    [transitionContext.containerView addSubview:toView];
    
    switch (self.type) {
        case XYBlurPresentAnimateType_EaseInOut:{
            toView.frame = CGRectMake(0,
                                      0,
                                      self.viewSize.width,
                                      self.viewSize.height);
            toView.center = transitionContext.containerView.center;
            
            toView.layer.opacity = 0.0;
            POPBasicAnimation *opacityAnimation = [POPBasicAnimation animationWithPropertyNamed:kPOPLayerOpacity];
            opacityAnimation.toValue = @(1.0);
            [opacityAnimation setCompletionBlock:^(POPAnimation *anim, BOOL finished) {
                [transitionContext completeTransition:YES];
            }];
            
            [toView.layer pop_addAnimation:opacityAnimation forKey:@"opacityAnimation"];
        }
            break;
        case XYBlurPresentAnimateType_BottomPsuh:{
            toView.frame = CGRectMake((fromView.frame.size.width - self.viewSize.width)/2,
                                      fromView.frame.size.height,
                                      self.viewSize.width,
                                      self.viewSize.height);
            
            POPSpringAnimation *positionAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerPositionY];
            positionAnimation.toValue = @(transitionContext.containerView.frame.size.height - self.viewSize.height/2);
            [positionAnimation setCompletionBlock:^(POPAnimation *anim, BOOL finished) {
                [transitionContext completeTransition:YES];
            }];
            
            dimmingView.layer.opacity = 0.0;
            POPBasicAnimation *opacityAnimation = [POPBasicAnimation animationWithPropertyNamed:kPOPLayerOpacity];
            opacityAnimation.toValue = @(1.0);
            
            [toView.layer pop_addAnimation:positionAnimation forKey:@"positionAnimation"];
            [dimmingView.layer pop_addAnimation:opacityAnimation forKey:@"opacityAnimation"];
        }
            
        default:
            break;
    }
    
    ///执行动画
    if (self.presentAnimate) {
        self.presentAnimate();
    }
}

- (UIImage*)convertViewToImage:(UIView*)v{
    CGSize s = v.bounds.size;
    // 下面方法，第一个参数表示区域大小。第二个参数表示是否是非透明的。如果需要显示半透明效果，需要传NO，否则传YES。第三个参数就是屏幕密度了
    UIGraphicsBeginImageContextWithOptions(s, NO, [UIScreen mainScreen].scale);
    [v.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage*image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)addTapDismissGuesture:(UIView *)view toViewController:(UIViewController *)viewController{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wundeclared-selector"
    if ([viewController respondsToSelector:@selector(xy_dismissVC)]) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:viewController action:@selector(xy_dismissVC)];
        [view addGestureRecognizer:tap];
    }
#pragma clang diagnostic pop
}

@end
