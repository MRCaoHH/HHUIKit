//
//  XYChatFooterView.m
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import "XYChatFooterView.h"
#import "XYChatSourceProtocol.h"
#import "XYChatFooterDelegate.h"
#import <XYCategory/XYCategory.h>
#import <XYEmojiKeyboard/XYEmojiKeyboard.h>
#import "XYChatPlusView.h"
#import "XYChatPlusItem.h"
#import <XYExtension/XYExtension.h>
#import <XYCategory/XYCategory.h>

typedef  NS_ENUM(NSInteger,XYChatFooterExpandType){
    XYChatFooterExpandType_None = 0,//无
    XYChatFooterExpandType_Keyboard = 1,//键盘
    XYChatFooterExpandType_Emoji = 2,//表情
    XYChatFooterExpandType_Plus = 3,//加号
};

@interface XYChatFooterView()<UITextViewDelegate,XYChatPlusViewDelegate,XYEmojiKeyboardDelegate>{
    CGFloat _expandHeight;//展开增加的高度
}
///拓展类型
@property (nonatomic,assign) XYChatFooterExpandType expandType;
///emoji 键盘
@property (nonatomic,strong) XYEmojiKeyboard *emojiKeyboard;
///拓展视图
@property (nonatomic,strong) XYChatPlusView *plusView;
///分割线
@property (nonatomic,strong) UIView *sepLineView;
@end

@implementation XYChatFooterView
@synthesize footerDelegate = _footerDelegate,chatVC = _chatVC,isExpand = _isExpand;

- (instancetype)init{
    self = [super initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 50)];
    if (self) {
        [self initSubview];
        [self addNotification];
    }
    return self;
}

-(void)dealloc{
    [self removeNotification];
}

- (void)initSubview{
    self.backgroundColor = [UIColor xy_colorWithHexString:@"#F5F5F6"];
    
    _emojiButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
    [_emojiButton setImage:[XYChatSourceProtocol imageWithName:@"chat_emoji"] forState:UIControlStateNormal];
    [_emojiButton setImage:[XYChatSourceProtocol imageWithName:@"chat_keyboard"] forState:UIControlStateSelected];
    [_emojiButton addTarget:self action:@selector(clickEmojiButton) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_emojiButton];
    
    _plusButton = [[UIButton alloc]initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - 70, 5, 60, 40)];
//    [_plusButton setImage:[XYChatSourceProtocol imageWithName:@"chat_plus"] forState:UIControlStateNormal];
//    [_plusButton setImage:[XYChatSourceProtocol imageWithName:@"chat_keyboard"] forState:UIControlStateSelected];
    [_plusButton setBackgroundImage:[UIImage xy_createImageFromColor:[UIColor xy_colorWithHexString:@"#09bb06"]] forState:UIControlStateNormal];
    [_plusButton setTitle:@"发送" forState:UIControlStateNormal];
    _plusButton.layer.masksToBounds = YES;
    _plusButton.layer.cornerRadius = 5;
    [_plusButton addTarget:self action:@selector(clickPlusButton) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_plusButton];
    
    _textView = [[UITextView alloc]initWithFrame:CGRectMake(CGRectGetMaxX(_emojiButton.frame), 7.5, CGRectGetMinX(_plusButton.frame)-CGRectGetMaxX(_emojiButton.frame) - 5, [self calTextViewHeight])];
    _textView.layer.cornerRadius = 3;
    _textView.layer.borderColor = [UIColor grayColor].CGColor;
    _textView.layer.borderWidth = 1.0/[UIScreen mainScreen].scale;
    _textView.backgroundColor = [UIColor xy_colorWithHexString:@"#FFFFFF"];
    _textView.font = [UIFont systemFontOfSize:[UIFont systemFontSize]];
    _textView.delegate = self;
    _textView.returnKeyType = UIReturnKeySend;
    _textView.contentInset = UIEdgeInsetsMake(2, 2, -2, -2);
    [self addSubview:_textView];
    
    _emojiKeyboard = [XYEmojiKeyboard new];
    _emojiKeyboard.hidden = YES;
    _emojiKeyboard.delegate = self;
    [self addSubview:_emojiKeyboard];
    
    _plusView = [XYChatPlusView new];
    _plusView.hidden = YES;
    NSArray *temsDic =  [NSArray arrayWithContentsOfFile:[XYChatSourceProtocol pathWithName:@"XYChatPlusItems" withType:@"plist"]]; 
    _plusView.itemList = [XYChatPlusItem xy_objectArrayWithKeyValuesArray:temsDic];
    _plusView.delegate = self;
    [self addSubview:_plusView];
    
    _sepLineView = [UIView new];
    _sepLineView.xy_width = [UIScreen mainScreen].bounds.size.width;
    _sepLineView.xy_height = 1.0/[UIScreen mainScreen].scale;
    _sepLineView.xy_x = 0;
    _sepLineView.backgroundColor = [UIColor xy_colorWithHexString:@"#D7D7D9"];
    [self  addSubview:_sepLineView];
}

- (CGFloat)calTextViewHeight{
    CGSize size =  [_textView sizeThatFits:CGSizeMake(CGRectGetMinX(_plusButton.frame)-CGRectGetMaxX(_emojiButton.frame), 100)];
    CGFloat height = size.height;
    height = height < 35?35:height;
    height = height > 70?70:height;
    return height;
}

- (void)adjustFrame{
    _textView.xy_height = [self calTextViewHeight];
    _emojiKeyboard.xy_y = [self calTextViewHeight] + 15;
    _plusView.xy_y = [self calTextViewHeight] + 15;
    _sepLineView.xy_y = [self calTextViewHeight] + 15;
    self.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [self calTextViewHeight] + 15 + _expandHeight);
    [self.footerDelegate chatFooter:self changeFrame:self.frame];
}

#pragma mark - 通知管理
- (void)addNotification{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyBoardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keyBoardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(textFieleTextChange:) name:UITextViewTextDidChangeNotification object:nil];
    
}

- (void)removeNotification{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:UITextViewTextDidChangeNotification object:nil];
}


#pragma mark - 键盘管理
- (void)keyBoardWillShow:(NSNotification *)notification{
    NSDictionary *userInfo = notification.userInfo;
    NSNumber *duration = userInfo[UIKeyboardAnimationDurationUserInfoKey];
    NSValue *value = userInfo[UIKeyboardFrameEndUserInfoKey];
    CGRect rect;
    [value getValue:&rect];
    [self settingExpandType:XYChatFooterExpandType_Keyboard withHeight:rect.size.height withDuration:duration.floatValue];
}

- (void)keyBoardWillHide:(NSNotification *)notification{
    NSDictionary *userInfo = notification.userInfo;
    NSNumber *duration = userInfo[UIKeyboardAnimationDurationUserInfoKey];
    if (self.expandType == XYChatFooterExpandType_Keyboard) {
        [self settingExpandType:XYChatFooterExpandType_None withHeight:0 withDuration:duration.floatValue];
    }
}

- (void)clickEmojiButton{
    if (self.emojiKeyboard.hidden) {
        [self settingExpandType:XYChatFooterExpandType_Emoji withHeight:0 withDuration:0.3];
    }else{
        [self settingExpandType:XYChatFooterExpandType_Keyboard withHeight:0 withDuration:0.3];
    }
}

- (void)clickPlusButton{
    if (self.textView.text.length) {
        [self.footerDelegate chatFooter:self sendMsg:self.textView.text];
        self.textView.text = @"";
        [self textFieleTextChange:nil];
    }
//    if (self.plusView.hidden) {
//        [self settingExpandType:XYChatFooterExpandType_Plus withHeight:0 withDuration:0.3];
//    }else{
//        [self settingExpandType:XYChatFooterExpandType_Keyboard withHeight:0 withDuration:0.3];
//    }
}

#pragma mark - 输入框内容改变
- (void)textFieleTextChange:(NSNotification *)notification{
    CGFloat height = [self calTextViewHeight];
    if (height != _textView.frame.size.height) {
        [self adjustFrame];
    }
}

#pragma mark - 协议 -
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [self.footerDelegate chatFooter:self sendMsg:textView.text];
        self.textView.text = @"";
        [self textFieleTextChange:nil];
        return NO;
    }
    return YES;
}

#pragma mark - XYChatPlusViewDelegate -
- (void)plusView:(XYChatPlusView *)plusViwe didSelectItem:(XYChatPlusItem *)items{
    if ([self.footerDelegate respondsToSelector:@selector(chatFooter:didSelectItem:)]) {
        [self.footerDelegate chatFooter:self didSelectItem:items];
    }
}

#pragma mark - XYChatFooterProtocol
- (void)dragTableView{
    [self settingExpandType:XYChatFooterExpandType_None withHeight:0 withDuration:0.3];
}

#pragma mark - XYEmojiKeyboardDelegate
- (void)emojiKeyboard:(XYEmojiKeyboard *)emojiKeyboard sendEmoji:(NSString *)emoji{
    [self.textView insertText:emoji];
}

- (void)emojiKeyboardClickDeleteEvent:(XYEmojiKeyboard *)emojiKeyboard{
    [self.textView deleteBackward];
}

- (void)emojiKeyboardClickSendEvent:(XYEmojiKeyboard *)emojiKeyboard{
    [self.footerDelegate chatFooter:self sendMsg:self.textView.text];
    self.textView.text = @"";
}
#pragma mark - 其他方法 -
- (void)settingExpandType:(XYChatFooterExpandType)expandType withHeight:(CGFloat)height withDuration:(float)duration{
    _expandType = expandType;
    
    BOOL isExpand = expandType != XYChatFooterExpandType_None;
    if (isExpand != self.isExpand) {
        _isExpand = isExpand;
        if ([self.footerDelegate respondsToSelector:@selector(chatFooter:isExpand:)]) {
            [self.footerDelegate chatFooter:self isExpand:self.isExpand];
        }
    }
    
    switch (_expandType) {
        case XYChatFooterExpandType_None:{
            self.emojiKeyboard.hidden = YES;
            self.emojiButton.selected = NO;
            self.plusButton.selected = NO;
            self.plusView.hidden = YES;
            [self endEditing:YES];
            _expandHeight = 0;
        }
            break;
        case XYChatFooterExpandType_Keyboard:{
            if (!self.textView.isFirstResponder) {
                [self.textView becomeFirstResponder];
                return;
            }
            self.emojiKeyboard.hidden = YES;
            self.emojiButton.selected = NO;
            self.plusButton.selected = NO;
            self.plusView.hidden = YES;
            _expandHeight = height;
        }
            break;
        case XYChatFooterExpandType_Emoji:{
            self.emojiKeyboard.hidden = NO;
            self.emojiButton.selected = YES;
            self.plusButton.selected = NO;
            self.plusView.hidden = YES;
            [self endEditing:YES];
            _expandHeight = self.emojiKeyboard.xy_height;
        }
            break;
        case XYChatFooterExpandType_Plus:{
            self.emojiButton.selected = NO;
            self.emojiKeyboard.hidden = YES;
            self.plusButton.selected = YES;
            self.plusView.hidden = NO;
            [self endEditing:YES];
            _expandHeight = self.plusView.xy_height;
        }
            break;
        default:
            break;
    }
    [UIView animateWithDuration:duration animations:^{
        [self adjustFrame];
    }];
}

@end
