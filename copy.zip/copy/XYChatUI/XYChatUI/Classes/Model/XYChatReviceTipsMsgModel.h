//
//  XYChatReviceTipsMsgModel.h
//  FMDB
//
//  Created by henry on 2018/11/20.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XYChatReviceTipsMsgModel : NSObject
@property (nonatomic,copy) NSString *to_mid;
@property (nonatomic,copy) NSString *message;
@property (nonatomic,assign) NSInteger code;
@property (nonatomic,copy) NSString *message_id;
@end

NS_ASSUME_NONNULL_END
