//
//  XYWebViewController.h
//  Pods-XYWebViewController_Example
//
//  Created by henry on 2017/11/3.
//

#import <RxWebViewController/RxWebViewController.h>

@interface XYWebViewController : RxWebViewController


@end
