//
//  XYRouteHandle.h
//  XYRoutes_Example
//
//  Created by henry on 2018/4/8.
//  Copyright © 2018年 henry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYRouteHandle : NSObject

+ (id)sendMsgWithInstance:(id)instance withSelector:(SEL)selector withParams:(NSDictionary *)params;

@end
