//
//  XYChatReviceMsgBaseModel.h
//  Pods
//
//  Created by henry on 2018/9/28.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,XYChatMsgCode) {
    ///加入
    XYChatMsgCode_Join = 1,
    ///向用户发送消息
    XYChatMsgCode_Send = 2,
    ///接收用户消息
    XYChatMsgCode_Receive = 3,
    ///确认包
    XYChatMsgCode_Confirm = 4,
    ///未读数
    XYChatMsgCode_Unread = 5,
    ///联系人
    XYChatMsgCode_Contact = 6,
    ///历史记录
    XYChatMsgCode_History = 7,
    ///标记已读
    XYChatMsgCode_FlagRead = 8,
    ///登录超时
    XYChatMsgCode_LoginOutTime = 9,
    ///提示
    XYChatMsgCode_Tips = 10
};

@interface XYChatReviceMsgBaseModel : NSObject

/**
 类型
 */
@property (nonatomic,assign) XYChatMsgCode code;

/**
 消息id
 */
@property (nonatomic,copy) NSString *message_id;

/**
 创建时间
 */
@property (nonatomic,assign) NSTimeInterval create_time;

/**
 发送时间
 */
@property (nonatomic,assign) NSInteger timestamp;

/**
 发送方id
 */
@property (nonatomic,copy) NSString *from_mid;

/**
 未读私信总数
 */
@property (nonatomic,copy) NSString *unread_count;

/**
 状态 -1 发送失败拒绝接受
 */
@property (nonatomic,assign) NSInteger status;

/**
 数据
 */
@property (nonatomic,strong) id data;
@end
