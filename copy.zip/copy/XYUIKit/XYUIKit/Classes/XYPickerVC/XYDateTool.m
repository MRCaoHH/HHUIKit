//
//  HHDateTool.m
//  LYLawyerPlatform
//
//  Created by caohuihui on 16/8/29.
//  Copyright © 2016年 华海乐盈. All rights reserved.
//

#import "XYDateTool.h"

//rfc3339 https://www.ietf.org/rfc/rfc3339
int dayOfWeek(int day, int month, int year)
{
    int cent;
    int dayofweek[] = {
        7, 1, 2, 3,
        4, 5, 6
    };
    
    /* adjust months so February is the last one */
    month -= 2;
    if (month < 1) {
        month += 12;
        --year;
    }
    /* split by century */
    cent = year / 100;
    year %= 100;
    return (dayofweek[((26 * month - 2) / 10 + day + year
                       + year / 4 + cent / 4 + 5 * cent) % 7]);
}



int monthDayCount(int year, int month){
    //01            January              31
    //02            February, normal     28
    //03            March                31
    //04            April                30
    //05            May                  31
    //06            June                 30
    //07            July                 31
    //08            August               31
    //09            September            30
    //10            October              31
    //11            November             30
    //12            December             31
    //02            February, leap year  29
    ///验证月份，在1～12之间
    if (month < 1 || month > 12) {
        return 0;
    }
    int arr[] = {31,28,31,30,31,30,31,31,30,31,30,31,29};
    int index = month - 1;
    if ( leapYear(year) && month == 2) {
        index = 12;
    }
    
    return arr[index];
}


int leapYear(int year){
    return (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
}
