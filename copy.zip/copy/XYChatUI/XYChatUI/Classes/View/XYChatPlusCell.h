//
//  XYChatPlusCell.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/17.
//

#import <UIKit/UIKit.h>
@class XYChatPlusItem;
@interface XYChatPlusCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *imgView;
@property (nonatomic,strong) UILabel *nameLabel;
@property (nonatomic,weak) XYChatPlusItem *item;
@end
