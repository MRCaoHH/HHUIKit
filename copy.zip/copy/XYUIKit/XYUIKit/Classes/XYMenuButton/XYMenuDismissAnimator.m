//
//  XYMenuDismissAnimator.m
//  XYMenuButton
//
//  Created by henry on 2017/10/20.
//

#import "XYMenuDismissAnimator.h"
#import "XYMBViewController.h"
#import "XYMenuButton.h"
@interface XYMenuDismissAnimator()
@property (nonatomic,weak) XYMenuButton *menuBtn;
@end
@implementation XYMenuDismissAnimator
- (CGFloat)timeInterval{
    if (_timeInterval == 0) {
        _timeInterval = 0.2;
    }
    return _timeInterval;
}

- (NSTimeInterval)transitionDuration:(nullable id <UIViewControllerContextTransitioning>)transitionContext{
    return self.timeInterval;
}

- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext{
    UIViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    toVC.view.tintAdjustmentMode = UIViewTintAdjustmentModeNormal;
    //    toVC.view.userInteractionEnabled = YES;
    
    __block UIView *dimmingView;
    [transitionContext.containerView.subviews enumerateObjectsUsingBlock:^(UIView *view, NSUInteger idx, BOOL *stop) {
        if (view.layer.opacity < 1.f) {
            dimmingView = view;
            *stop = YES;
        }
    }];
    
    XYMBViewController *fromVC = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey];
    self.menuBtn = fromVC.menuButton;
    
    
    CABasicAnimation *opacityAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    opacityAnimation.fromValue = @1;
    opacityAnimation.toValue = @(0.01);
    opacityAnimation.fillMode=kCAFillModeForwards;
    opacityAnimation.removedOnCompletion = NO;
    [fromVC.bgView.layer addAnimation:opacityAnimation forKey:@"opacityAnimation"];
    
    [fromVC hiddenAnimated];
    
    if ([fromVC.menuButton.delegate respondsToSelector:@selector(menuButtonDidHide:)]) {
        [fromVC.menuButton.delegate menuButtonDidHide:fromVC.menuButton];
    }
    
    [self performSelector:@selector(completeAnimation:) withObject:transitionContext afterDelay:self.timeInterval];
    
}

- (void)completeAnimation:(nullable id <UIViewControllerContextTransitioning>)transitionContext{
    self.menuBtn.frame = self.menuBtn.orgFrame;
    [self.menuBtn.orgSuperView addSubview:self.menuBtn];
    [self.menuBtn clearRecord];
    [transitionContext completeTransition:YES];
    
}

@end
