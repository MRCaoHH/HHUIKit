//
//  XYChatSendMsgParams.h
//  Pods
//
//  Created by henry on 2018/9/28.
//

#import "XYChatReviceMsgBaseModel.h"

@interface XYChatSendMsgParams : XYChatReviceMsgBaseModel

/**
 是否发送完成
 */
@property (nonatomic,assign) BOOL isFinsh;

/*****************************************************
 *                      文本消息                      *
 *****************************************************/

/**
用户
*/
@property (nonatomic,copy) NSString *to_mid;

/**
 消息内容
 */
@property (nonatomic,copy) NSString  *message;

/**
 会话id
 */
@property (nonatomic,copy) NSString *session_id;


/*****************************************************
 *                      聊天记录                      *
 *****************************************************/

/***
 * 最后一条消息id
 ***/
@property (nonatomic,copy) NSString *page_id;

/**
 每页数据
 */
@property (nonatomic,copy) NSString *page_size;

/**
 对方用户id
 */
@property (nonatomic,copy) NSString *mid;
@end
