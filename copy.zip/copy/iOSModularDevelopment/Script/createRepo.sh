#! /bin/bash

# git 账号
gitName=""
# git 密码
gitPwd=""
# 身份令牌
token="" 
# 项目名称
name=""
# 本地的项目路径
projectPath=""
# 项目描述
desc="项目描述"
while  getopts  " t:n:r:d:u:p: "  arg #选项后面的冒号表示该选项需要参数
do
         case  $arg  in
             t)
                token=$OPTARG #用户名
                ;;
             n)
                name=$OPTARG #仓库名
                ;;
             r)
                projectPath=$OPTARG #根目录
                ;;
             d)
				desc=$OPTARG # 项目描述
				;;
             u)
				gitName=$OPTARG # git用户名
				;;
             p)
				gitPwd=$OPTARG # git用户名
				;;
              ? )  #当有不认识的选项的时候arg为 ?
                echo  " unkonw argument "
                exit  1
        ;;
        esac
done

set -e

commond="./createGit.py -t ${token} -n ${name} -d ${desc}"
res=`${commond}`
if [[ $res != "201" && $res != "200" ]]; then
	echo "创建git仓库有失败。\n状态码:${res}"
	exit
fi

gitPath="http://${gitName}:${gitPwd}@pods.xy.com:3000/iOSModule/${name}.git"
cd ${projectPath}

#创建模板
#http://pods.xy.com:3000/iOSModule/pod-template.git
pod lib create $name --template-url=http://pods.xy.com:3000/iOSModule/pod-template.git
cd ${name}
git init
git add .
git commit -m "初始化模块"
git remote add origin ${gitPath}
git push --set-upstream origin master
git checkout master



