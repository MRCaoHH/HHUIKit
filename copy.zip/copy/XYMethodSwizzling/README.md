# XYMethodSwizzling

[![CI Status](http://img.shields.io/travis/henry/XYMethodSwizzling.svg?style=flat)](https://travis-ci.org/henry/XYMethodSwizzling)
[![Version](https://img.shields.io/cocoapods/v/XYMethodSwizzling.svg?style=flat)](http://cocoapods.org/pods/XYMethodSwizzling)
[![License](https://img.shields.io/cocoapods/l/XYMethodSwizzling.svg?style=flat)](http://cocoapods.org/pods/XYMethodSwizzling)
[![Platform](https://img.shields.io/cocoapods/p/XYMethodSwizzling.svg?style=flat)](http://cocoapods.org/pods/XYMethodSwizzling)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYMethodSwizzling is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYMethodSwizzling'
```

## Author

henry, henry@xy.com

## License

XYMethodSwizzling is available under the MIT license. See the LICENSE file for more info.
