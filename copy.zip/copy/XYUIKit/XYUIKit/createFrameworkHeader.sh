#!/bin/bash

set -e

directory=`pwd`
projectName=`basename $directory`
headerFile="#ifndef ${projectName}_h\n"
headerFile=$headerFile"#define ${projectName}_h\n"
scanfDirctory(){
	for file in `ls $1`
		do  
			newPath=$1/$file
			if [[ -d "$newPath" ]] ; then
				scanfDirctory $newPath
			elif [[ -f "$newPath" ]]; then
				if [[ "${newPath##*.}" = "h"  ]]; then
					if [[ $file != ${projectName}.h ]]; then
						headerFile=$headerFile"#import <$projectName/$file>\n"
					fi
		  		fi  
			fi  
	done 
}

scanfDirctory $directory

headerFile=$headerFile"#endif /* ${projectName}_h */"
echo -e  "$headerFile" > ${directory}/Classes/${projectName}.h


