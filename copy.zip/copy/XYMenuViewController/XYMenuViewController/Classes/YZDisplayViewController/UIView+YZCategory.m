//
//  UIView+YZCategory.m
//  Pods
//
//  Created by caohuihui on 2017/6/9.
//
//

#import "UIView+YZCategory.h"

@implementation UIView (YZCategory)

#pragma mark - origin 坐标点
-(CGPoint)yz_origin
{
    return self.frame.origin;
}

-(void)setYz_origin:(CGPoint)origin
{
    CGRect frame   = self.frame;
    frame.origin   = origin;
    self.frame     = frame;
}

#pragma mark - size 大小
-(CGSize)yz_size
{
    return self.frame.size;
}

-(void)setYz_size:(CGSize)size
{
    CGRect frame   = self.frame;
    frame.size     = size;
    self.frame     = frame;
}

#pragma mark - width 宽度
-(CGFloat)yz_width
{
    return self.yz_size.width;
}

-(void)setYz_width:(CGFloat)width
{
    CGSize size    = self.yz_size;
    size.width     = width;
    self.yz_size      = size;
}

#pragma mark - height 高度
-(CGFloat)yz_height
{
    return self.yz_size.height;
}

-(void)setYz_height:(CGFloat)height
{
    CGSize size    = self.yz_size;
    size.height    = height;
    self.yz_size      = size;
}

#pragma mark - x 横坐标
-(CGFloat)yz_x
{
    return self.yz_origin.x;
}

-(void)setYz_x:(CGFloat)x
{
    CGPoint origin = self.yz_origin;
    origin.x       = x;
    self.yz_origin    = origin;
}

#pragma mark - y 纵坐标
-(CGFloat)yz_y
{
    return self.yz_origin.y;
}

-(void)setYz_y:(CGFloat)y
{
    CGPoint origin = self.yz_origin;
    origin.y       = y;
    self.yz_origin    = origin;
}

- (void)setYz_centerX:(CGFloat)centerX
{
    CGPoint center = self.center;
    center.x = centerX;
    self.center = center;
}

- (CGFloat)yz_centerX
{
    return self.center.x;
}

- (CGFloat)yz_left {
    return self.frame.origin.x;
}

- (void)setYz_left:(CGFloat)x {
    CGRect frame = self.frame;
    frame.origin.x = x;
    self.frame = frame;
}

- (void)setYz_centerY:(CGFloat)centerY
{
    CGPoint center = self.center;
    center.y = centerY;
    self.center = center;
}

- (CGFloat)yz_centerY
{
    return self.center.y;
}

- (void)setYz_top:(CGFloat)y {
    CGRect frame = self.frame;
    frame.origin.y = y;
    self.frame = frame;
}

- (CGFloat)yz_top {
    return self.frame.origin.y;
}

- (void)setYz_bottom:(CGFloat)bottom {
    CGRect frame = self.frame;
    frame.origin.y = bottom - frame.size.height;
    self.frame = frame;
}

- (CGFloat)yz_bottom {
    return self.frame.origin.y + self.frame.size.height;
}

- (CGFloat)yz_right {
    return self.frame.origin.x + self.frame.size.width;
}

- (void)setYz_right:(CGFloat)right {
    CGRect frame = self.frame;
    frame.origin.x = right - frame.size.width;
    self.frame = frame;
}

@end
