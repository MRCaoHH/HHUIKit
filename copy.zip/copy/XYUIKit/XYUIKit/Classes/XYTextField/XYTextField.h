//
//  XYTextField.h
//  XYUIKit
//
//  Created by henry on 2017/11/3.
//

#import <UIKit/UIKit.h>

@interface XYTextField : UITextField

/**
 左边视图
 */
@property (nonatomic,strong) UIImage *leftImage;

@property (nonatomic,strong) UIColor *bottomLineColor;
@end
