//
//  XYChatContactVC.m
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import "XYChatContactVC.h"
#import "XYChatContactProtocol.h"
#import "XYChatContactDefaultProtocol.h"
#import "XYChatContactCell.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import "XYChatContactModel.h"
#import <XYRefresh/XYRefresh.h>

@interface XYChatContactVC ()<UIViewControllerTransitioningDelegate>
@property (nonatomic,strong) id<XYChatContactProtocol> protocol;
@end

@implementation XYChatContactVC
static NSString *kReuseIdentifier = @"cell";
- (instancetype)initWithProtocol:(id<XYChatContactProtocol>)protocol{
    self = [super initWithStyle:UITableViewStyleGrouped];
    if (self) {
        _protocol = protocol;
        _protocol.contactVC = self;
    }
    return self;
}

- (instancetype)init{
    self = [self initWithProtocol:[XYChatContactDefaultProtocol new]];
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"私信";
    [self.tableView registerClass:[XYChatContactCell class] forCellReuseIdentifier:kReuseIdentifier];
    self.tableView.tableHeaderView = ({
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0,0, 0.01)];
        view;
    });
    self.tableView.tableFooterView = ({
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0,0, 0.01)];
        view;
    });
    
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 74, 0, 0);
    [XYRefresh addHeaderRefresh:self.tableView target:self action:@selector(downPullRefresh)];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    //静默刷新
    [self downPullRefresh];
}

#pragma mark - 数据刷新 -
- (void)downPullRefresh{
    if ([self.protocol respondsToSelector:@selector(downPullReloadData:)]) {
        [self.protocol downPullReloadData:^(BOOL succ) {
            [XYRefresh endHeaderRefresh:self.tableView];
            [self.tableView reloadData];
        }];
    }
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
     return [self.protocol.contactArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    XYChatContactCell *cell = [tableView dequeueReusableCellWithIdentifier:kReuseIdentifier forIndexPath:indexPath];
    XYChatContactModel *contactModel = self.protocol.contactArray[indexPath.row];
    [cell.iconImgView sd_setImageWithURL:[NSURL URLWithString:contactModel.iconUrl]];
    cell.nameLabel.text = contactModel.name;
    cell.msgLabel.text = contactModel.msg;
    cell.timeLabel.text = contactModel.displayTime;
    [cell.unreadBtn setTitle:[NSString stringWithFormat:@"%li",contactModel.unreadCount] forState:UIControlStateNormal];
    cell.unreadBtn.hidden = (contactModel.unreadCount <= 0);
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 66;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if ([self.protocol respondsToSelector:@selector(didSelectWithContact:)]) {
        XYChatContactModel *contactModel = self.protocol.contactArray[indexPath.row];
        [self.protocol didSelectWithContact:contactModel];
    }
}

@end
