//
//  XYViewController.m
//  XYUIKit
//
//  Created by blackman on 11/03/2017.
//  Copyright (c) 2017 blackman. All rights reserved.
//

#import "XYViewController.h"
#import <XYUIKit/XYTextField.h>
#import <XYUIKit/XYMenuButton.h>
#import <XYUIKit/XYBaseTableVC.h>
#import <XYUIKit/XYBTCellConfig.h>
#import <XYExtension/XYExtension.h>
#import <XYUIKit/XYPickerVC.h>
#import <XYUIKit/XYDatePickerVC.h>
#import "XYTableProtocol.h"
#import <XYUIKit/XYMenuCollectionVC.h>
#import <XYUIKit/XYMenuCollectionItem.h>
#import <XYUIKit/XYUIKit.h>
#import <XYUIKit/XYScrollTitleMenuView.h>
#import <XYCategory/XYCategory.h>
#import <XYUIKit/XYUIKit.h>
#import <XYUIKit/XYLineChartView.h>
#import <XYUIKit/XYTextPickerVC.h>
#import <XYUIKit/XYHorseRaceLampView.h>

@interface XYViewController ()<XYMenuButtonDelegate,XYDatePickerVCDelegate,XYPickerVCDelegate,XYLineChartViewDataSource,XYTextPickerVCDelegate,XYHorseRaceLampViewDelegate>
@property (nonatomic,strong) XYTextField *textField;
@property (nonatomic,strong) XYMenuButton *moreBtn;
@property (nonatomic,strong) UIButton *pickerBtn;
@property (nonatomic,strong) UIButton *datePickerBtn;
@property (nonatomic,strong) UIButton *menuBtn;
@property (nonatomic,strong) NSMutableArray *numbers1;
@property (nonatomic,strong) NSMutableArray *numbers2;
@property (nonatomic,strong) NSMutableArray *numbers3;
@end

@implementation XYViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    _moreBtn = [[XYMenuButton alloc] initWithFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - 50, [UIScreen mainScreen].bounds.size.height - 60, 50, 50)];
    _moreBtn.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    _moreBtn.layer.cornerRadius = 25;
    _moreBtn.itemSpacing = 10;
    _moreBtn.layer.masksToBounds = YES;
    _moreBtn.delegate = self;
    [_moreBtn setImage:[UIImage imageNamed:@"more"] forState:UIControlStateNormal];
    [_moreBtn setImage:[UIImage imageNamed:@"more"] forState:UIControlStateSelected];
    
    UIButton *item = [UIButton new];
    [item setImage:[UIImage imageNamed:@"beauty_face"] forState:UIControlStateNormal];
    [item setImage:[UIImage imageNamed:@"beauty_face"] forState:UIControlStateSelected];
    item.frame = CGRectMake(0, 0, 50, 50);
    item.layer.cornerRadius = 25;
    item.layer.masksToBounds = YES;
    item.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    
    UIButton *item2 = [UIButton new];
    [item2 setImage:[UIImage imageNamed:@"share"] forState:UIControlStateNormal];
    [item2 setImage:[UIImage imageNamed:@"share"] forState:UIControlStateSelected];
    item2.frame = CGRectMake(0, 0, 50, 50);
    item2.layer.cornerRadius = 25;
    item2.layer.masksToBounds = YES;
    item2.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    
    UIButton *item3 = [UIButton new];
    [item3 setImage:[UIImage imageNamed:@"reverse"] forState:UIControlStateNormal];
    [item3 setImage:[UIImage imageNamed:@"reverse"] forState:UIControlStateSelected];
    item3.frame = CGRectMake(0, 0, 50, 50);
    item3.layer.cornerRadius = 25;
    item3.layer.masksToBounds = YES;
    item3.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
    _moreBtn.items = @[item,item2,item3];
    
    [self.view addSubview:_moreBtn];
    _textField = [[XYTextField alloc]initWithFrame:CGRectMake(60, 20, 175, 40)];
    _textField.leftImage = [UIImage imageNamed:@"account"];
//    _textField.backgroundColor = [UIColor redColor];
    _textField.bottomLineColor = [UIColor blackColor];
    [self.view addSubview:_textField];

//    _textField.rightViewMode = UITextFieldViewModeWhileEditing;
//    _textField.rightView = ({
//        UIButton *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 40, 40)];
//        imageView.image = [UIImage imageNamed:@"account"];
//        [imageView sizeToFit];
//        imageView;
//    })
//    [self.view addSubview:_textField];
    
    _pickerBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(self.navigationController.navigationBar.frame), self.view.frame.size.width, 60)];
    [_pickerBtn setTitle:@"picker" forState:UIControlStateNormal];
    [_pickerBtn setBackgroundColor:[UIColor magentaColor]];
    [_pickerBtn addTarget:self action:@selector(clickPickerBtn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_pickerBtn];
    
    _datePickerBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_pickerBtn.frame), self.view.frame.size.width, 60)];
    [_datePickerBtn setTitle:@"datePicker" forState:UIControlStateNormal];
    [_datePickerBtn setBackgroundColor:[UIColor cyanColor]];
    [_datePickerBtn addTarget:self action:@selector(clickDatePickerBtn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_datePickerBtn];
    
    _menuBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_datePickerBtn.frame), self.view.frame.size.width, 60)];
    [_menuBtn setTitle:@"menu collection view controller" forState:UIControlStateNormal];
    [_menuBtn setBackgroundColor:[UIColor brownColor]];
    [_menuBtn addTarget:self action:@selector(clickMenuVCBtn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_menuBtn];
    
    XYTitleMenuView *menuView = [[XYTitleMenuView alloc]initWithTitles:@[@"标题1",@"标题2",@"标题3"] bgColor:[UIColor blackColor] textColor:[UIColor whiteColor]];
    menuView.frame = CGRectMake(0, CGRectGetMaxY(_menuBtn.frame), [UIScreen mainScreen].bounds.size.width, 44);
    [self.view addSubview:menuView];
    
    XYScrollTitleMenuView *scrollMenuView = [[XYScrollTitleMenuView alloc]initWithTitles:@[@"标题1标题1",@"标题2"] frame:CGRectMake(0, CGRectGetMaxY(menuView.frame), [UIScreen mainScreen].bounds.size.width - 100, 44)];
//    scrollMenuView.fixItemWidth = 60;
    scrollMenuView.blockAutoSize = YES;
    scrollMenuView.bgColor = [UIColor greenColor];
    scrollMenuView.clipsToBounds = YES;
    [scrollMenuView setSelectWithIndex:0];
    [self.view addSubview:scrollMenuView];
    
    UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(scrollMenuView.frame), 375, 150)];
    [self.view addSubview:scrollView];
    
    NSMutableArray *recordArr = ({
        NSMutableArray *mutableArr = @[].mutableCopy;
        for (int i = 0; i< 50; i++) {
            XYTrendChartRecord *record = [XYTrendChartRecord new];
            record.version = @"201809181313";
            record.numberArr = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7"].mutableCopy;
            record.winning = random()%7;
            [mutableArr addObject:record];
        }
        mutableArr;
    });
    
    scrollView.contentSize = CGSizeMake(375, 30.f * recordArr.count);
    XYTrendChartView *view  = [[XYTrendChartView alloc]initWithFrame:CGRectMake(0, 0, scrollView.contentSize.width, scrollView.contentSize.height)];
    view.type = XYTrendChartViewType_None;
    view.recordArr = recordArr;
    view.backgroundColor = [UIColor whiteColor];
    [scrollView addSubview:view];
    
    
    XYProgressView *progressView = [[XYProgressView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(scrollView.frame) + 20, 355, 20)];
    progressView.layer.masksToBounds = NO;
    progressView.displayerProgress = @"进度";
    progressView.progress = 0;
    progressView.bgColor = [UIColor xy_colorWithHexString:@"#800000"];
    progressView.progressColor = [UIColor xy_colorWithHexString:@"#ffb901"];
    progressView.displayerProgress = @"300";
    progressView.displayerFont = [UIFont boldSystemFontOfSize:16];
    progressView.displayerFontColor = [UIColor yellowColor];
    progressView.displayerMaxProgress = @"10000";
    progressView.displayerMaxFontColor = [UIColor yellowColor];
//    progressView.isTouch = NO;
    [self.view addSubview:progressView];
    
    XYHorseRaceLampView *lampView = [[XYHorseRaceLampView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(progressView.frame) + 20, 355, 20) withTitles:@[@"相思 红豆生南国，春来发几枝。愿君多采撷，此物最相思。",@"登鹳楼 白日依山尽，黄河入海流。欲穷千里目，更上一层楼。"] withTitleColor:[UIColor redColor] withTitleFont:[UIFont systemFontOfSize:20]];
    lampView.backgroundColor = [UIColor greenColor];
    lampView.delegate = self;
    [self.view addSubview:lampView];
//
//    XYLineChartView *chartView  = [[XYLineChartView alloc]initWithFrame:CGRectMake(0, 84, 355, 375)];
//    chartView.backgroundColor = [UIColor whiteColor];
//    chartView.dataSource = self;
//    chartView.xAxisToBottomOffset = 40;
//    chartView.yAxisToLeftOffset = 40;
//    [self.view addSubview:chartView];
    
//    UIButton *infoCard = [[UIButton alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(scrollMenuView.frame), self.view.frame.size.width, 60)];
//    [infoCard setTitle:@"info card" forState:UIControlStateNormal];
//    [infoCard setBackgroundColor:[UIColor cyanColor]];
//    [infoCard addTarget:self action:@selector(infoCardBtnEvent) forControlEvents:UIControlEventTouchUpInside];
//    [self.view addSubview:infoCard];
}
//- (void)infoCardBtnEvent{
//    XYLRInfoCardModel *infoModel = [XYLRInfoCardModel new];
//    infoModel.coverUrl = @"https://gw.alicdn.com/tfs/TB1hJ2KX6ihSKJjy0FlXXadEXXa-254-318.png";
//    infoModel.noteAttributedString = [self attributedString];
//    XYLRInfoCardVC *infoCardVC = [[XYLRInfoCardVC alloc]initWithInfoModel:infoModel];
//    [self presentViewController:infoCardVC animated:YES completion:^{
//
//    }];
//}
//
//- (NSMutableAttributedString *)attributedString{
//    NSMutableAttributedString *mutableAttributeString = [NSMutableAttributedString new];
//
//    NSAttributedString *sysString = [[NSAttributedString alloc]initWithString:@"昵称:张三" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:kXYLRChatMsgFontSize],NSForegroundColorAttributeName:[UIColor xy_colorWithHexString:@"#FF0000"]}];
//    [mutableAttributeString appendAttributedString:sysString];
//
//    NSAttributedString *userString = [[NSAttributedString alloc]initWithString:@"\n" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:kXYLRChatMsgFontSize],NSForegroundColorAttributeName:[UIColor xy_colorWithHexString:@"#00FFFF"]}];
//    [mutableAttributeString appendAttributedString:userString];
//
//    NSAttributedString *inString = [[NSAttributedString alloc]initWithString:@"ID:1010" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:kXYLRChatMsgFontSize],NSForegroundColorAttributeName:[UIColor xy_colorWithHexString:@"#FFFFFF"]}];
//    [mutableAttributeString appendAttributedString:inString];
//
//    NSAttributedString *gameNameString = [[NSAttributedString alloc]initWithString:@"\n" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:kXYLRChatMsgFontSize],NSForegroundColorAttributeName:[UIColor xy_colorWithHexString:@"#FF0000"]}];
//    [mutableAttributeString appendAttributedString:gameNameString];
//
//    NSAttributedString *periodString = [[NSAttributedString alloc]initWithString:@"金粟轴的古筝发出优美的声音，那素手拨筝的美人坐在玉房前。\n想尽了办法为博取周郎的青睐，你看她故意地时时拨错了琴弦。" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:12],NSForegroundColorAttributeName:[UIColor xy_colorWithHexString:@"#666666"]}];
//    [mutableAttributeString appendAttributedString:periodString];
//
//    return mutableAttributeString;
//}

- (void)clickPickerBtn{
//    NSMutableArray *itemArr = @[].mutableCopy;
//    for (int i = 0; i< 10; i++) {
//        XYPickerItemModel *pickerModel = [XYPickerItemModel new];
//        pickerModel.title = [NSString stringWithFormat:@"%i",i];
//        NSMutableArray *subArr1 = @[].mutableCopy;
//        for (int j = 0; j< 10; j++) {
//            XYPickerItemModel *pickerModel2 = [XYPickerItemModel new];
//            pickerModel2.title = [NSString stringWithFormat:@"%i-%i",i,j];
//            NSMutableArray *subArr2 = @[].mutableCopy;
//            for (int z = 0; z< 10; z++) {
//                XYPickerItemModel *pickerModel3 = [XYPickerItemModel new];
//                pickerModel3.title = [NSString stringWithFormat:@"%i-%i-%i",i,j,z];
//                [subArr2 addObject:pickerModel3];
//            }
//            pickerModel2.subTitle = subArr2;
//            [subArr1 addObject:pickerModel2];
//        }
//        pickerModel.subTitle = subArr1;
//        [itemArr addObject:pickerModel];
//    }
    
//    XYPickerVC *vc = [[XYPickerVC alloc]initWithTitleArr:itemArr];
//    vc.delegate = self;
//    [vc setSelectRow:2 component:0];
//    [vc setSelectRow:3 component:1];
//    [vc setSelectRow:4 component:2];
//    [vc setSelectRow:4 component:3];
//    [self presentViewController:vc animated:YES completion:^{
//
//    }];
    
    XYTextPickerVC *pickerVC = [[XYTextPickerVC alloc]initWithDelegate:self];
    [self presentViewController:pickerVC animated:YES completion:^{
        [pickerVC setSelectIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] ];
        [pickerVC setSelectIndexPath:[NSIndexPath indexPathForRow:1 inSection:1] ];
        [pickerVC setSelectIndexPath:[NSIndexPath indexPathForRow:2 inSection:2] ];
    }];

}

- (void)clickDatePickerBtn{
    XYDatePickerVC *picker = [[XYDatePickerVC alloc]init1900ToTodayPicker:XYDatePickerType_YYYYMMDD];;
    [picker selectDate:({
        XYDateStruct date ;
        date.month = 12;
        date.year = 1991;
        date.day = 31;
        date;
    })];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:^{
    }];
}

- (void)clickMenuVCBtn{
    XYMenuCollectionVC *vc = [XYMenuCollectionVC new];
    NSMutableArray *items = @[].mutableCopy;
    for (int i = 0; i< 10; i++) {
        XYMenuCollectionItem *item = [XYMenuCollectionItem new];
        item.name = [NSString stringWithFormat:@"%i",i];
        item.iconUrl = @"https://img.alicdn.com/bao/uploaded/i4/2455523730/TB2f84Jewn.PuJjSZFkXXc_lpXa_!!2455523730.jpg_400x400q90.jpg";
        [items addObject:item];
    }
    vc.items = items;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)menuButton:(XYMenuButton *)menuButton clickIndex:(NSInteger)index{
    XYTableProtocol *protocol = [XYTableProtocol new];
    XYBaseTableVC *baseVC  = [[XYBaseTableVC alloc]initWithConfigArr:protocol.configArr actionProtocol:protocol];
    [self.navigationController pushViewController:baseVC animated:YES];
}

#pragma mark - XYDatePickerVCDelegate
- (void)datePickerVC:(XYDatePickerVC *)datePickerVC year:(NSString *)year month:(NSString *)month day:(NSString *)day hour:(NSString *)hour min:(NSString *)min second:(NSString *)second{
    NSLog(@"1111");
}

#pragma mark - XYPickerVCDelegate
- (void)pickerVC:(XYPickerVC *)pickerVC didClickOkBtn:(NSArray *)selItemArr{
    for (id<XYPickerItem> item in selItemArr) {
        NSLog(@"%@",item.title);
    }
}

#pragma mark - XYLineChartViewDataSource -
- (NSInteger)lineChartViewLineCount:(XYLineChartView *)liveChartView{
    return 1;
}

- (NSInteger)lineChartView:(XYLineChartView *)liveChartView lineIndex:(NSInteger)lineIndex{
    return 20;
}


- (NSString *)lineChartView:(XYLineChartView *)liveChartView xAxisTitlewithIndexPath:(NSIndexPath *)indexPath{
    return [NSString stringWithFormat:@"%li",indexPath.row];
}

- (CGFloat)lineChartView:(XYLineChartView *)liveChartView xAxisNumWithIndexPath:(NSIndexPath *)indexPath{
    return indexPath.row;
}


- (NSString *)lineChartView:(XYLineChartView *)liveChartView yAxisTitlewithIndexPath:(NSIndexPath *)indexPath{
    return [NSString stringWithFormat:@"%li-%li",indexPath.section,indexPath.row];
}


- (CGFloat)lineChartView:(XYLineChartView *)liveChartView yAxisNumWithIndexPath:(NSIndexPath *)indexPath{
    return indexPath.row*100;
}

#pragma mark - XYTextPickerVCDelegate
- (NSInteger)numberOfComponentTextPickerVC:(XYTextPickerVC *)vc{
    return 3;
}


- (NSInteger)textPickerVC:(XYTextPickerVC *)vc numberOfRowsInComponent:(NSInteger)component{
    return 27;
}


- (NSString *)textPickerVC:(XYTextPickerVC *)vc titleWithIndex:(NSIndexPath *)indexPath{
    return [NSString stringWithFormat:@"%li",indexPath.row];
}


- (void)textPickerVC:(XYTextPickerVC *)vc clickOkWithTitles:(NSArray *)titles{
    NSLog(@"%@",titles);
}

- (void)clickCancelTextPickerVC:(XYTextPickerVC *)vc{
    NSLog(@"11111");
}

- (BOOL)textPickerVC:(XYTextPickerVC *)vc canCommitWithTitles:(NSArray *)title{
    return YES;
}


#pragma mark - XYHorseRaceLampViewDelegate
- (void)tapHorseRaceLampView:(XYHorseRaceLampView *)lampView title:(NSString *)title index:(NSInteger)index{
    NSLog(@"%@,%li",title,index);
}

@end
