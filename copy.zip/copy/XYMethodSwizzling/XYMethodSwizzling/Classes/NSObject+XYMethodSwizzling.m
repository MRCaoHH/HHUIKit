//
//  NSObject+XYMethodSwizzling.m
//  XYMethodSwizzling
//
//  Created by henry on 2017/12/1.
//

#import "NSObject+XYMethodSwizzling.h"
#import <objc/runtime.h>

@implementation NSObject (XYMethodSwizzling)
+ (void)xy_swizzleClassMethod:(Class)class originSelector:(SEL)originSelector otherSelector:(SEL)otherSelector
{
    Method otherMehtod = class_getClassMethod(class, otherSelector);
    Method originMehtod = class_getClassMethod(class, originSelector);
    // 交换2个方法的实现
    method_exchangeImplementations(otherMehtod, originMehtod);
}

+ (void)xy_swizzleInstanceMethod:(Class)class originSelector:(SEL)originSelector otherSelector:(SEL)otherSelector
{
    Method otherMehtod = class_getInstanceMethod(class, otherSelector);
    Method originMehtod = class_getInstanceMethod(class, originSelector);
    // 交换2个方法的实现
    method_exchangeImplementations(otherMehtod, originMehtod);
}

#ifndef __OPTIMIZE__
#else
- (void)objectForKeyedSubscript:(id)obj{
    NSLog(@"类型不对:%@",obj);
}
#endif
@end

#ifndef __OPTIMIZE__
#else
@implementation NSArray(LYMethodSwizzling)
+ (void)load{
    [self xy_swizzleInstanceMethod:objc_getClass("__NSArrayM") originSelector:@selector(objectAtIndex:) otherSelector:@selector(ly_objectAtIndexM:)];
    [self xy_swizzleInstanceMethod:objc_getClass("__NSSingleObjectArrayI") originSelector:@selector(objectAtIndex:) otherSelector:@selector(ly_objectAtIndexI:)];
    
}

- (id)ly_objectAtIndexI:(NSUInteger)index{
    if(self.count > index){
        return  [self ly_objectAtIndexI:index];
    }
    return nil;
    
}

- (id)ly_objectAtIndexM:(NSUInteger)index{
    if(self.count > index){
        return  [self ly_objectAtIndexM:index];
    }
    return nil;
    
}
@end
#endif
