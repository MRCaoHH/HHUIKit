//
//  XYChatContactCell.h
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import <UIKit/UIKit.h>

@interface XYChatContactCell : UITableViewCell

/**
 头像
 */
@property (nonatomic,strong) UIImageView *iconImgView;

/**
 名字标签
 */
@property (nonatomic,strong) UILabel *nameLabel;

/**
 消息标签
 */
@property (nonatomic,strong) UILabel *msgLabel;

/**
 时间标签
 */
@property (nonatomic,strong) UILabel *timeLabel;

/**
 未读数
 */
@property (nonatomic,strong) UIButton *unreadBtn;

@end
