//
//  XYBTTextViewCell.m
//  MJExtension
//
//  Created by henry on 2017/11/22.
//

#import "XYBTTextViewCell.h"
#import <XYCategory/XYCategory.h>
@interface XYBTTextViewCell()<UITextViewDelegate>
@end

@implementation XYBTTextViewCell
- (void)layoutSubviews{
    [super layoutSubviews];
    
    self.titleLabel.font = [UIFont systemFontOfSize:self.titleFontSize];
    self.titleLabel.textColor = [UIColor xy_colorWithHexString:self.titleTextColor];
    
    self.textView.font = [UIFont systemFontOfSize:self.textViewFontSize];
    self.textView.textColor = [UIColor xy_colorWithHexString:self.textViewTextColor];
    self.textView.backgroundColor = [UIColor xy_colorWithHexString:self.textViewBgColor];
    
    [self.titleLabel sizeToFit];
    self.titleLabel.xy_top = self.contentView.xy_top + self.edgeDistance;
    self.titleLabel.xy_x = self.edgeDistance;
    
    self.textView.xy_x = self.titleLabel.xy_x ;
    self.textView.xy_y = self.titleLabel.xy_bottom + self.titleToTextView;
    self.textView.xy_width = self.contentView.xy_width - self.edgeDistance * 2;
    self.textView.xy_height = self.contentView.xy_height - self.titleLabel.xy_bottom - self.titleToTextView - self.edgeDistance;
    
    
}

#pragma mark - 协议 -
#pragma mark - UITextViewDelegate
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if ([text isEqualToString:@"\n"]) {
        [_textView resignFirstResponder];
        return NO;
    }
    return YES;
}

- (void)textViewDidBeginEditing:(UITextView *)textView{
    [self.textView willChangeValueForKey:@"text"];
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    [self.textView didChangeValueForKey:@"text"];
}

#pragma mark - 属性方法 -
- (UILabel *)titleLabel{
    if(_titleLabel == nil){
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.font = [UIFont systemFontOfSize:self.titleFontSize];
        _titleLabel.textColor = [UIColor xy_colorWithHexString:self.titleTextColor];
        [self.contentView addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (UITextView *)textView{
    if (_textView == nil) {
        _textView = [[UITextView alloc]init];
        _textView.returnKeyType = UIReturnKeyDone;
        _textView.delegate = self;
        _textView.font = [UIFont systemFontOfSize:self.textViewFontSize];
        _textView.textColor = [UIColor xy_colorWithHexString:self.textViewTextColor];
        _textView.backgroundColor = [UIColor xy_colorWithHexString:self.textViewBgColor];
        [self.contentView addSubview:_textView];
    }
    return _textView;
    
}

- (void)setPlaceholder:(NSString *)placeholder{
    _placeholder = placeholder;
    self.textView.xy_placeholder = self.placeholder;
}

- (void)setText:(NSString *)text{
    self.textView.text = text;
}

- (NSString *)text{
    return self.textView.text;
}

- (void)setTitle:(NSString *)title{
    _title = title;
    self.titleLabel.text = _title;
}

- (CGFloat)edgeDistance{
    if (_edgeDistance == 0) {
        _edgeDistance = 12;
    }
    return _edgeDistance;
}

- (CGFloat)titleToTextView{
    if (_titleToTextView == 0) {
        _titleToTextView = 5;
    }
    return _titleToTextView;
}

- (NSString *)textViewBgColor{
    if (_textViewBgColor == nil) {
        _textViewBgColor = @"#F5F5F5";
    }
    return _textViewBgColor;
}

- (NSString *)textViewTextColor{
    if (_textViewTextColor == nil) {
        _textViewTextColor = @"#000000";
    }
    return _textViewTextColor;
}

- (CGFloat)titleFontSize{
    if (_titleFontSize == 0) {
        _titleFontSize = 13;
    }
    return _titleFontSize;
}

- (NSString *)titleTextColor{
    if (_titleTextColor == nil) {
        _titleTextColor = @"#000000";
    }
    return _titleTextColor;
}

- (CGFloat)textViewFontSize{
    if (_textViewFontSize == 0) {
        _textViewFontSize = 13;
    }
    return _textViewFontSize;
}
@end
