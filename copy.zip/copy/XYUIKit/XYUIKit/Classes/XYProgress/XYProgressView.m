//
//  XYProgressView.m
//  Masonry
//
//  Created by henry on 2018/8/26.
//

#import "XYProgressView.h"

@implementation XYProgressView
@synthesize bgColor = _bgColor, progress = _progress,displayerFontColor = _displayerFontColor,displayerProgress = _displayerProgress,progressColor = _progressColor,displayerFont = _displayerFont,displayerMaxFontColor = _displayerMaxFontColor;

- (instancetype)init{
    self = [super init];
    if (self) {
        self.layer.masksToBounds = YES;
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.masksToBounds = YES;
    }
    return self;
    
}

- (void)drawRect:(CGRect)rect{
    if (self.layer.masksToBounds) {
        self.layer.cornerRadius = rect.size.height/2;
    }
    
    [super drawRect:rect];
    ///得到上下文
     CGContextRef context = UIGraphicsGetCurrentContext();
    
    ///绘制底部
    [self.bgColor set];
    CGContextAddRect(context, rect);
    CGContextFillPath(context);
    
    ///绘制进度
    CGFloat progressWidth = rect.size.width * self.progress;
    CGRect progressRect = {rect.origin,progressWidth,rect.size.height};
    [self.progressColor set];
    CGContextAddRect(context, progressRect);
    CGContextFillPath(context);
    
    //绘制当前进度文字
    if (self.displayerProgress.length) {
        NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
        paragraphStyle.alignment = NSTextAlignmentCenter;
        paragraphStyle.lineBreakMode = NSLineBreakByClipping;
        NSDictionary *attDic = @{NSFontAttributeName:self.displayerFont,NSForegroundColorAttributeName:self.displayerFontColor,NSParagraphStyleAttributeName:paragraphStyle};
        
        CGSize size = [self.displayerProgress boundingRectWithSize:progressRect.size options:NSStringDrawingUsesLineFragmentOrigin attributes:attDic context:nil].size;
        
        //当绘制空间太小的时候不绘制
        if (!(size.width > progressRect.size.width || size.height > progressRect.size.height)) {
            CGFloat x = progressRect.origin.x + (progressRect.size.width - size.width)/2;
            CGFloat y = progressRect.origin.y + (progressRect.size.height - size.height)/2;
            x = x < 0?0:x;
            y = y < 0?0:y;
            CGRect stringRect = {x,y,size};
            
            [self.displayerProgress drawInRect:stringRect withAttributes:attDic];
            
            CGContextFillPath(context);
        }
    }
    
    //绘制最大进度文字
    if (self.displayerMaxProgress.length) {
        NSMutableParagraphStyle *paragraphStyle = [NSMutableParagraphStyle new];
        paragraphStyle.alignment = NSTextAlignmentCenter;
        paragraphStyle.lineBreakMode = NSLineBreakByClipping;
        NSDictionary *attDic = @{NSFontAttributeName:self.displayerFont,NSForegroundColorAttributeName:self.displayerMaxFontColor,NSParagraphStyleAttributeName:paragraphStyle};
        
        CGRect maxProgressRect = {CGRectGetMaxX(progressRect),progressRect.origin.y,rect.size.width - CGRectGetMaxX(progressRect),progressRect.size.height};
        CGSize size = [self.displayerMaxProgress boundingRectWithSize:maxProgressRect.size options:NSStringDrawingUsesLineFragmentOrigin attributes:attDic context:nil].size;
        
        //当绘制空间太小的时候不绘制
        if (!(size.width > maxProgressRect.size.width || size.height > maxProgressRect.size.height)) {
            CGFloat x = maxProgressRect.origin.x + (maxProgressRect.size.width - size.width)/2;
            CGFloat y = maxProgressRect.origin.y + (maxProgressRect.size.height - size.height)/2;
            x = x < 0?0:x;
            y = y < 0?0:y;
            CGRect stringRect = {x,y,size};
            NSLog(@">>>>>>>>>%@",NSStringFromCGRect(stringRect));
            [self.displayerMaxProgress drawInRect:stringRect withAttributes:attDic];
            
            CGContextFillPath(context);
        }
    }
}

#pragma mark - touche -
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self updateProgress:touches];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self updateProgress:touches];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [self updateProgress:touches];
}

- (void)updateProgress:(NSSet<UITouch *> *)touches{
    UITouch *touch =  [touches anyObject];
    CGPoint point = [touch locationInView:self];
    CGFloat progress = point.x /  self.frame.size.width;
    progress = progress > 1 ?1:progress;
    progress = progress < 0 ?0:progress;
    self.progress = progress;
    if ([self.delegate respondsToSelector:@selector(dragProgressEvent:progress:)]) {
        [self.delegate dragProgressEvent:self progress:progress];
    }
}

#pragma mark - 属性 -
- (UIColor *)bgColor{
    if (_bgColor == nil) {
        _bgColor = [UIColor redColor];
    }
    return _bgColor;
}

- (void)setBgColor:(UIColor *)bgColor{
    _bgColor = bgColor;
    [self setNeedsDisplay];
}

- (UIColor *)progressColor{
    if (_progressColor == nil) {
        _progressColor = [UIColor blueColor];
    }
    return _progressColor;
}

- (void)setProgressColor:(UIColor *)progressColor{
    _progressColor = progressColor;
    [self setNeedsDisplay];
}


-(UIColor *)displayerFontColor{
    if (_displayerFontColor == nil) {
        _displayerFontColor = [UIColor whiteColor];
    }
    return _displayerFontColor;
}

- (void)setDisplayerFontColor:(UIColor *)displayerFontColor{
    _displayerFontColor = displayerFontColor;
    [self setNeedsDisplay];
}

- (UIFont *)displayerFont{
    if (_displayerFont == nil) {
        _displayerFont = [UIFont systemFontOfSize:12];
    }
    return _displayerFont;
}

- (void)setDisplayerFont:(UIFont *)displayerFont{
    _displayerFont = displayerFont;
    [self setNeedsDisplay];
}

- (void)setProgress:(CGFloat)progress{
    progress = progress > 1 ?1:progress;
    progress = progress < 0 ?0:progress;
    _progress = progress;
    [self setNeedsDisplay];
}

- (void)setDisplayerProgress:(NSString *)displayerProgress{
    _displayerProgress = displayerProgress;
    [self setNeedsDisplay];
}

- (void)setIsTouch:(BOOL)isTouch{
    self.userInteractionEnabled = isTouch;
}

- (void)setDisplayerMaxProgress:(NSString *)displayerMaxProgress{
    _displayerMaxProgress = displayerMaxProgress;
    [self setNeedsDisplay];
}

- (UIColor *)displayerMaxFontColor{
    if (_displayerMaxFontColor == nil) {
        _displayerMaxFontColor = [UIColor blackColor];
    }
    return _displayerMaxFontColor;
}

- (void)setDisplayerMaxFontColor:(UIColor *)displayerMaxFontColor{
    _displayerMaxFontColor = displayerMaxFontColor;
    [self setNeedsDisplay];
}

- (BOOL)isTouch{
    return self.userInteractionEnabled;
}
@end
