//
//  XYChatReviceTipsMsgModel.m
//  FMDB
//
//  Created by henry on 2018/11/20.
//

#import "XYChatReviceTipsMsgModel.h"

@implementation XYChatReviceTipsMsgModel

@end
