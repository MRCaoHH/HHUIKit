//
//  XYWebViewController.m
//  Pods-XYWebViewController_Example
//
//  Created by henry on 2017/11/3.
//

#import "XYWebViewController.h"

@interface XYWebViewController ()<UIWebViewDelegate>
@end

@implementation XYWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
