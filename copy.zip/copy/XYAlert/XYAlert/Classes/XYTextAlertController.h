//
//  XYTextAlertController.h
//  XYAlert
//
//  Created by henry on 2017/12/29.
//

#import <XYAlert/XYAlert.h>

@interface XYTextAlertController : XYAlertController
@property (nonatomic,strong) UILabel *messageLabel;
- (instancetype)initWithTitle:(NSString *)title message:(NSString *)message cancelTitle:(NSString *)cancelTitle okTitle:(NSString *)okTitle;

@end
