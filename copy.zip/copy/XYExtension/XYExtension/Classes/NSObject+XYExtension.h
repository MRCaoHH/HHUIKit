//
//  NSObject+XYExtension.h
//  XYExtension
//
//  Created by henry on 2017/10/26.
//

#import <Foundation/Foundation.h>

@interface NSObject (XYExtension)

/**
 *  @brief  JSON字符串转模型
 *
 *  @param values JSON字符
 *
 *  @return id
 */
+(id)xy_objectWithKeyValues:(id)values;

/**
 *  @brief  Core Data JSON字符串转模型
 *
 *  @param values  JSON字符
 *  @param context 上下文
 *
 *  @return 模型
 */
+(id)xy_objectWithKeyValues:(id)values context:(NSManagedObjectContext *)context;

/**
 *  @brief  JSON array -> model array【将一个字典数组转成模型数组】
 *
 *  @param valuesArr json 数组
 *
 *  @return NSMutableArray 模型数组
 */
+(NSMutableArray *)xy_objectArrayWithKeyValuesArray:(id)valuesArr;

/**
 *  @brief  Model array -> JSON array【将一个模型数组转成字典数组】
 *
 *  @param objectArr 模型数组
 *
 *  @return 字典数组
 */
+(NSMutableArray *)xy_keyValuesArrayWithObjectArray:(NSArray *)objectArr;

/**
 *  @brief  设置对象数组当中包含的对象
 *
 *  @param objectClassInArray key:数组的属性名,value:包含对象的类名
 */
+(void)xy_setupObjectClassInArray:(NSDictionary *(^)(void))objectClassInArray;

/**
 *  @brief  Model name - JSON key mapping【模型中的属性名和字典中的key不相同(或者需要多级映射)】
 *
 *  @param replacedKeyFromPropertyName 替换的键值和属性名
 */
+(void)xy_setupReplacedKeyFromPropertyName:(NSDictionary * (^)(void))replacedKeyFromPropertyName;

/**
 *  @brief  coding
 *
 *  @param ignoredCodingPropertyNames 忽略不归档的属性名
 */
+(void)xy_setupIgnoredCodingPropertyNames:(NSArray *(^)(void))ignoredCodingPropertyNames;


/**
 *  @brief 转换属性
 *
 *  @param ignoredPropertyNames 忽略属性
 */
+(void)xy_setupIgnoredPropertyNames:(NSArray *(^)(void))ignoredPropertyNames;

/**
 替换属性名

 @param propertyName 属性名
 @return 键值
 */
+ (id)xy_replacedKeyFromPropertyName121:(NSString *)propertyName;

/**
 *  @brief   Model -> JSON【将一个模型转成字典】
 *
 *  @return  字典
 */
-(NSMutableDictionary *)xy_keyValues;

/**
 *  得到json字符串
 *
 *  @return json字符串
 */
- (NSString *)xy_JSONString;

/**
 *  将属性名换为其他key去字典中取值
 *
 *  @return 从字典中取值用的key
 */
- (id)xy_JSONObject;

/**
 根据键值转化为属性值

 @param objc 字典
 @return 实例
 */
- (instancetype)xy_setKeyValues:(id)objc;
@end

@interface NSString (XYExtension)
- (NSString *)xy_underlineFromCamel;
@end
