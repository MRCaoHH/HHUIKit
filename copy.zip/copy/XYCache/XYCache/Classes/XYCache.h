//
//  XYCache.h
//  XYLawyerPlatform
//
//  Created by caohuihui on 2017/10/27.
//  Copyright © 2016年 华海乐盈. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <XYCache/XYArchiverModel.h>
@interface XYCache : NSObject


/**
 添加缓存

 @param key 键值
 @param object 对象
 */
+ (void)addCacheWithKey:(NSString *)key object:(id <NSCoding>)object;


/**
 移除缓存

 @param key 键值
 */
+ (void)removeCacaheWithKey:(NSString *)key;


/**
 获取缓存

 @param key 键值
 @return 缓存的对象
 */
+ (id)cacheWithKey:(NSString *)key;


/**
 保存缓存对象，并获得键值

 @param object 缓存对象
 @return 键值
 */
+ (NSString *)saveCacheWithObject:(id <NSCoding>)object;
@end
