//
//  XYEmojiKeyboardImgCell.h
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/16.
//

#import <UIKit/UIKit.h>

@interface XYEmojiKeyboardImgCell : UICollectionViewCell
@property (nonatomic,strong) UIImageView *imgView;
@end
