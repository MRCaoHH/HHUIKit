//
//  XYChatDateConvertTool.m
//  MJExtension
//
//  Created by henry on 2018/9/29.
//

#import "XYChatDateConvertTool.h"

@implementation XYChatDateConvertTool
+ (NSString *)getTimeWithDate:(NSDate *)date{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    dateFormatter.dateFormat = @"HH:mm";
    NSString *string = @"";
    NSDate *currentDate = [NSDate date];
    NSDate *weekDate = [calendar dateByAddingUnit:NSCalendarUnitDay value:-7 toDate:currentDate options:NSCalendarWrapComponents];
    if ([calendar isDateInToday:date]) {//今天
        string =  [dateFormatter stringFromDate:date];
    }else if ([calendar isDateInYesterday:date]){//昨天
        string =  [NSString stringWithFormat:@"%@ %@",@"昨日",[dateFormatter stringFromDate:date]];
    }else if (weekDate.timeIntervalSince1970 < date.timeIntervalSince1970){//本周
        NSInteger week = [calendar component:NSCalendarUnitWeekday fromDate:date] - 1;
        NSArray *weekArr = @[@"星期日",@"星期一",@"星期二",@"星期三",@"星期四",@"星期五",@"星期六"];
        string =  [NSString stringWithFormat:@"%@ %@",weekArr[week],[dateFormatter stringFromDate:date]];
        
    }else{
        dateFormatter.dateFormat = @"yy/M/d HH:mm";
        string = [dateFormatter stringFromDate:date];
    }
    return string;
}

+ (NSString *)getTimeWithTimeStamp:(NSTimeInterval)timeStamp{
    return [self getTimeWithDate:[NSDate dateWithTimeIntervalSince1970:timeStamp/1000]];
}
@end
