//
//  XYViewController.m
//  XYHUD
//
//  Created by henry on 11/13/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

#import "XYViewController.h"
#import <XYHUD/XYHUD.h>

@interface XYViewController ()

@end

@implementation XYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor  blackColor];
    
    NSString *path = [[NSBundle mainBundle]pathForResource:@"lr_load_progress" ofType:@"gif"];
    dispatch_after(2, dispatch_get_main_queue(), ^{
        [XYHUD showImage:[[UIImage alloc]initWithContentsOfFile:path] status:@"正在加载"];
    });
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
