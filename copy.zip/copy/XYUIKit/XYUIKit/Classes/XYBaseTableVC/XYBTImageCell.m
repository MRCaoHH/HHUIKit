//
//  XYBTImageCell.m
//  Pods-XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//

#import "XYBTImageCell.h"
#import <XYCategory/XYCategory.h>
#import <SDWebImage/UIImageView+WebCache.h>

@implementation XYBTImageCell

- (void)layoutSubviews{
    [super layoutSubviews];
    
    self.titleLabel.font = [UIFont systemFontOfSize:self.titleFontSize];
    self.titleLabel.textColor = [UIColor xy_colorWithHexString:self.titleTextColor];
    
    [self.titleLabel sizeToFit];
    self.titleLabel.xy_centerY = self.contentView.xy_centerY;
    self.titleLabel.xy_x = self.edgeDistance;
    self.imgView.xy_right = self.contentView.xy_right;
    self.imgView.xy_centerY = self.contentView.xy_centerY;
}

#pragma mark - 属性方法 -
- (UILabel *)titleLabel{
    if(_titleLabel == nil){
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.font = [UIFont systemFontOfSize:self.titleFontSize];
        _titleLabel.textColor = [UIColor xy_colorWithHexString:self.titleTextColor];
        [self.contentView addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (UIImageView *)imgView{
    if(_imgView == nil){
        _imgView = [UIImageView new];
        [self.contentView addSubview:_imgView];
    }
    return _imgView;
}

- (void)setTitle:(NSString *)title{
    _title = title;
    self.titleLabel.text = _title;
}

- (void)setImgUrl:(NSString *)imgUrl{
    _imgUrl = imgUrl;
    [self.imgView sd_setImageWithURL:[NSURL URLWithString:imgUrl]];
}

- (void)setImgWidth:(CGFloat)imgWidth{
    _imgWidth = imgWidth;
    self.imgView.xy_width = imgWidth;
}

- (void)setImgHeight:(CGFloat)imgHeight{
    _imgHeight = imgHeight;
    self.imgView.xy_height = imgHeight;
}

- (CGFloat)edgeDistance{
    if (_edgeDistance == 0) {
        _edgeDistance = 12;
    }
    return _edgeDistance;
}

- (CGFloat)titleFontSize{
    if (_titleFontSize == 0) {
        _titleFontSize = 13;
    }
    return _titleFontSize;
}

- (NSString *)titleTextColor{
    if (_titleTextColor == nil) {
        _titleTextColor = @"#000000";
    }
    return _titleTextColor;
}
@end
