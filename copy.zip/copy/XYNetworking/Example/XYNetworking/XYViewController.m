//
//  XYViewController.m
//  XYNetworking
//
//  Created by Henry on 10/26/2017.
//  Copyright (c) 2017 Henry. All rights reserved.
//

#import "XYViewController.h"
#import <XYNetworking/XYNetworking.h>

@interface XYViewController ()

@end

@implementation XYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
