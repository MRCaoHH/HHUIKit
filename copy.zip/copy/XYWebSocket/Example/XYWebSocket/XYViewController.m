//
//  XYViewController.m
//  XYWebSocket
//
//  Created by henry on 11/28/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

#import "XYViewController.h"
#import <XYWebSocket/XYWebSocket.h>
#import "XYWebSocketMsgModel.h"

@interface XYViewController ()<UITextFieldDelegate,XYWebSocketDelegate>
@property (weak, nonatomic) IBOutlet UITextField *addressTextField;
@property (weak, nonatomic) IBOutlet UITextField *msgTextField;
@property (weak, nonatomic) IBOutlet UIButton *connectBtn;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (nonatomic) XYWebSocket *socket;
@end

@implementation XYViewController

- (XYWebSocket *)socket{
    return [XYWebSocket shareInstance];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.textView.editable = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc{
    NSLog(@"释放");
}


- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.socket addDelegate:self];
}

- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.socket removeDelegate:self];
}

- (IBAction)clickConnnectBtn:(id)sender {
    if((self.socket.state == XYWebSocketState_Connect || self.socket.state == XYWebSocketState_Connecting) && self.socket != nil){
        [_connectBtn setTitle:@"连接" forState:UIControlStateNormal];
        [_socket disconnect];
        return;
    }
    self.socket.url = _addressTextField.text;
    _textView.text = @"";
    [self addTip:[NSString stringWithFormat:@"准备连接：%@",_addressTextField.text]];
    [_socket connect];
    [_connectBtn setTitle:@"断开" forState:UIControlStateNormal];
}

- (IBAction)clickSendBtn:(id)sender {
    XYWebSocketMsgModel *msg = [XYWebSocketMsgModel new];
    msg.code = @"chat";
    msg.message = _msgTextField.text;
    [self.socket sendMsg:msg];
    _msgTextField.text = @"";
}


- (void)addTip:(NSString *)tip{
    NSMutableString *txt = _textView.text.mutableCopy;
    [txt appendString:@"\n"];
    [txt appendString:tip];
    _textView.text = txt;
}

- (IBAction)dismissEvent:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - 协议 -
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - XYWebSocketDelegate
- (void)webSocket:(XYWebSocket *)webSocket didReceiveMessage:(id)message{
    [self addTip:message];
}

- (void)webSocketDidConnect:(XYWebSocket *)webSocket{
    [self addTip:@"连接成功"];
    XYWebSocketMsgModel *msg = [XYWebSocketMsgModel new];
    msg.code = @"join";
    msg.message = @"";
    [self.socket sendMsg:msg];
}

- (void)webSocketDidDisconnect:(XYWebSocket *)webSocket{
    [self addTip:@"断开成功"];
}

- (void)webSocket:(XYWebSocket *)webSocket connectFail:(NSError *)err{
    [self addTip:err.description];
}
@end
