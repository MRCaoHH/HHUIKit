//
//  XYHttpCookieManage.m
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import "XYHttpCookieManage.h"

static NSString *XYHttpCookieKey = @"XYHttpCookieKey";

@implementation XYHttpCookieManage
#pragma mark - 设置http请求的cookie
+ (void)saveCookieWithHost:(NSString *)host{
    NSArray *cookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookiesForURL: [NSURL URLWithString:host]];
    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:cookies];
    [self setCookie:data host:host];
}


+ (void)setCookieWithHost:(NSString *)host{
    NSData *cookiesdata = [self cookie:host];
    if([cookiesdata length]) {
        NSArray *cookies = [NSKeyedUnarchiver unarchiveObjectWithData:cookiesdata];
        NSHTTPCookie *cookie;
        for (cookie in cookies) {
            [[NSHTTPCookieStorage sharedHTTPCookieStorage] setCookie:cookie];
        }
    }
}


+ (void)removeCookieWithHost:(NSString *)host{
    NSData *cookiesdata = [self cookie:host];
    if([cookiesdata length]) {
        NSArray *cookies = [NSKeyedUnarchiver unarchiveObjectWithData:cookiesdata];
        NSHTTPCookie *cookie;
        for (cookie in cookies) {
            [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
        }
    }
}

#pragma mark - cookie 保存
+ (void)setCookie:(NSData *)data host:(NSString *)host{
    NSUserDefaults *ud =  [NSUserDefaults standardUserDefaults];
    [ud setObject:data forKey:[NSString stringWithFormat:@"%@:%@",XYHttpCookieKey,host]];
    [ud synchronize];
}


+ (NSData *)cookie:(NSString *)host{
    NSUserDefaults *ud =  [NSUserDefaults standardUserDefaults];
    return [ud objectForKey:[self userDefaultKey:host]];
}

+ (NSString *)userDefaultKey:(NSString *)host{
    return [NSString stringWithFormat:@"%@:%@",XYHttpCookieKey,host];
}
@end
