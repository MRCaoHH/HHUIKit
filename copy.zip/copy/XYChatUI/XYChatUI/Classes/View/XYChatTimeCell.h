//
//  XYChatTimeCell.h
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import <UIKit/UIKit.h>

@interface XYChatTimeCell : UITableViewCell
@property (nonatomic,strong) UILabel *timeLabel;
- (void)setTime:(NSString *)time;
@end
