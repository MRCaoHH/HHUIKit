//
//  XYBaseTableVC.h
//  Pods-XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//

#import <UIKit/UIKit.h>
#import <XYUIKit/XYBTActionProtocol.h>
@class XYBTCellConfig;
@interface XYBaseTableVC : UITableViewController
@property (nonatomic,strong) NSArray *configArr;
@property (nonatomic,strong) id<XYBTActionProtocol> protocol;

/**
 根据cell的配置数组和对应actionProtocol 初始化
 
 @param configiArr cell的配置数组
 @param actionProtocol 活动协议
 @return 实例
 */
- (instancetype)initWithConfigArr:(NSArray *)configiArr actionProtocol:(id<XYBTActionProtocol>)actionProtocol;

/**
 根据cell的配置数组

 @param configiArr cell的配置数组
 @return 实例
 */
- (instancetype)initWithConfigArr:(NSArray *)configiArr;


/**
 根据唯一标识查找Cell配置

 @param arr 配置数组
 @param identifier 唯一标识
 @return cell配置
 */
+ (XYBTCellConfig *)cellConfigWithArr:(NSArray *)configArr Identifier:(NSString *)identifier;

/**
 根据identifier得到cell配置的值

 @param identifier 唯一标识
 @return 值
 */
- (id)getValueWithIdentifier:(NSString *)identifier;

/**
 根据identifier得到cell配置

 @param identifier 唯一标识
 @return cell配置
 */
- (XYBTCellConfig *)cellConfigWithIdentifier:(NSString *)identifier;
@end
