//
//  UIView+YZCategory.h
//  Pods
//
//  Created by caohuihui on 2017/6/9.
//
//

#import <UIKit/UIKit.h>

@interface UIView (YZCategory)

@property (nonatomic,assign) CGPoint yz_origin;
@property (nonatomic,assign) CGSize  yz_size;
@property (nonatomic,assign) CGFloat yz_width;
@property (nonatomic,assign) CGFloat yz_height;
@property (nonatomic,assign) CGFloat yz_y;
@property (nonatomic,assign) CGFloat yz_x;
@property (nonatomic, assign) CGFloat yz_centerX;
@property (nonatomic, assign) CGFloat yz_centerY;

@property (nonatomic,assign) CGFloat yz_bottom;
@property (nonatomic,assign) CGFloat yz_top;
@property (nonatomic,assign) CGFloat yz_left;
@property (nonatomic,assign) CGFloat yz_right;

@end
