//
//  XYExtensionTests.m
//  XYExtensionTests
//
//  Created by henry on 10/26/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

@import XCTest;
@import XYExtension;
#import "XYStudentModel.h"
#import "XYMacBookModel.h"

@interface Tests : XCTestCase

@end

@implementation Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testJsonStringToModel
{
    NSString *jsonString = @"{\
    \"name\":\"henry\",\
    \"intro\":\"my name is henry .\",\
    \"age\":33,\
    \"sex\":{\
        \"value\":1,\
        \"name\":\"man\"\
    }\
    }";
    XYStudentModel *student = [XYStudentModel xy_objectWithKeyValues:jsonString];
    XCTAssertTrue([student.name isEqualToString: @"henry"]);
    XCTAssertTrue([student.intro isEqualToString:@"my name is henry ."]);
    XCTAssertTrue(student.age==33);
    XCTAssertTrue(student.sex.value== 1);
    XCTAssertTrue([student.sex.name isEqualToString:@"man"]);
}

- (void)testModelToJson{
    XYStudentModel *student = [[XYStudentModel alloc]init];
    student.name = @"henry";
    student.intro = @"my name is henry .";
    student.age = 33;
    
    XYSexModel *sex = [XYSexModel new];
    sex.value = 1;
    sex.name = @"man";
    student.sex = sex;
    
    NSMutableDictionary *stuDic =  [student xy_keyValues];
    XCTAssertTrue([stuDic[@"name"] isEqualToString:@"henry"]);
    XCTAssertTrue([stuDic[@"intro"] isEqualToString:@"my name is henry ."]);
    XCTAssertTrue([[stuDic[@"age"] description] isEqualToString:@"33"]);
    NSDictionary *sexDic = stuDic[@"sex"];
    XCTAssertTrue([[sexDic[@"value"] description] isEqualToString:@"1"]);
    XCTAssertTrue([sexDic[@"name"] isEqualToString:@"man"]);
    
    NSString *str = [student xy_JSONString];
    XCTAssertTrue([str length]);

}

- (void)testModelListToDicList{
    NSMutableArray *modelList = @[].mutableCopy;
    for (int i = 0; i < 10; i++) {
        XYStudentModel *student = [[XYStudentModel alloc]init];
        student.name = [NSString stringWithFormat:@"henry %i",i];
        student.intro = [NSString stringWithFormat:@"my name is henry %i .",i];
        student.age = 33 + i;
        
        XYSexModel *sex = [XYSexModel new];
        sex.value = i%2;
        sex.name = i%2?@"female":@"man";
        student.sex = sex;
        
        [modelList addObject:student];
    }
    
    
    NSArray *dicList = [XYStudentModel xy_keyValuesArrayWithObjectArray:modelList];
    for (int i = 0; i < 10; i++) {
        NSDictionary *stuDic = dicList[i];
        NSString *name = [NSString stringWithFormat:@"henry %i",i];
        XCTAssertTrue([stuDic[@"name"] isEqualToString:name]);
        NSString *intro = [NSString stringWithFormat:@"my name is henry %i .",i];
        XCTAssertTrue([stuDic[@"intro"] isEqualToString:intro]);
        NSString *age = [NSString stringWithFormat:@"%i",i+33];
        XCTAssertTrue([[stuDic[@"age"] description] isEqualToString:age]);
        NSDictionary *sexDic = stuDic[@"sex"];

        XCTAssertTrue([[sexDic[@"value"] description] isEqualToString:i%2?@"1":@"0"]);
        XCTAssertTrue([sexDic[@"name"] isEqualToString:i%2?@"female":@"man"]);
        
    }
    
}

- (void)testJsonListToModelList{
    NSString *jsonString = @"[{\"age\":33,\"sex\":{\"value\":0,\"name\":\"female\"},\"name\":\"henry1\",\"intro\":\"my name is henry1 .\"},{\"age\":34,\"sex\":{\"value\":1,\"name\":\"man\"},\"name\":\"henry2\",\"intro\":\"my name is henry2 .\"},{\"age\":35,\"sex\":{\"value\":0,\"name\":\"female\"},\"name\":\"henry3\",\"intro\":\"my name is henry3 .\"}]";
    NSArray *arr = [XYStudentModel xy_objectArrayWithKeyValuesArray:jsonString];
    for (int i  = 0; i < [arr count]; i++) {
        XYStudentModel *student = arr[i];
        NSString *name = [NSString stringWithFormat:@"henry%i",i+1];
        XCTAssertTrue([student.name isEqualToString:name]);
        NSString *intro = [NSString stringWithFormat:@"my name is henry%i .",i+1];
        XCTAssertTrue([student.intro isEqualToString:intro]);
        XCTAssertTrue(student.age==33+i);
        XCTAssertTrue(student.sex.value== i%2);
        XCTAssertTrue([student.sex.name isEqualToString:i%2?@"man":@"female"]);
    }
}

- (void)testModelContainOtheModelList{
    [XYMacBookModel xy_setupObjectClassInArray:^NSDictionary *{
        return @{@"colors":[XYColorModel class]};
    }];
    
    XYMacBookModel *model = [XYMacBookModel new];
    model.price = @"HK$9,988";
    model.size = @"Height: 0.35–1.31 cm (0.14–0.52 inch)"
    "Width: 28.05 cm (11.04 inches)"
    "Depth: 19.65 cm (7.74 inches)"
    "Weight: 0.92 kg (2.03 pounds)2";
    model.display = @"Retina display";
    model.processor = @"1.2GHz"
    "1.2GHz dual-core Intel Core m3, Turbo Boost up to 3.0GHz, with 4MB L3 cache";
    model.memory = @"8GB of 1866MHz LPDDR3 onboard memory";
    model.storage = @"256GB PCIe-based onboard SSD1";
    
    XYColorModel *roseGold = [XYColorModel new];
    roseGold.en_name = @"Rose Gold";
    roseGold.ch_name = @"玫瑰金";
    
    XYColorModel *spaceGray = [XYColorModel new];
    spaceGray.en_name = @"Space Gray";
    spaceGray.ch_name = @"太空灰";
    
    XYColorModel *silver = [XYColorModel new];
    silver.en_name = @"Silver";
    silver.ch_name = @"银";
    
    XYColorModel *gold = [XYColorModel new];
    gold.en_name = @"Gold";
    gold.ch_name = @"金";
    
    model.colors = @[roseGold,spaceGray,silver,gold];
    
    
    NSString *jsonString = [model xy_JSONString];
    XYMacBookModel *model2 = [XYMacBookModel xy_objectWithKeyValues:jsonString];
    
    XCTAssertTrue([model.price isEqualToString:model2.price]);
    XCTAssertTrue([model.size isEqualToString:model2.size]);
    XCTAssertTrue([model.display isEqualToString:model2.display]);
    XCTAssertTrue([model.processor isEqualToString:model2.processor]);
    XCTAssertTrue([model.storage isEqualToString:model2.storage]);
    
    for (int i = 0; i < model.colors.count; i++) {
        XYColorModel *color = model.colors[i];
        XYColorModel *color2 = model2.colors[i];
        XCTAssertTrue([color.ch_name isEqualToString:color2.ch_name]);
        XCTAssertTrue([color.en_name isEqualToString:color2.en_name]);
    }
}

@end

