//
//  XYRouteRegularly.m
//  Pods
//
//  Created by henry on 2017/10/27.
//

#import "XYRouteRegularly.h"

@implementation XYRouteRegularly

+ (BOOL)matchRouteWithPath:(NSString *)path routePattern:(NSString *)pattern{
    NSString *newPattern = [NSString stringWithFormat:@"^%@",pattern];
    NSError *err;
    NSRegularExpression *regex = [NSRegularExpression regularExpressionWithPattern:newPattern options:NSRegularExpressionCaseInsensitive error:&err];
    NSUInteger integer = [regex  numberOfMatchesInString:path options:NSMatchingReportProgress range:NSMakeRange(0, path.length)];
    return integer;
}

@end
