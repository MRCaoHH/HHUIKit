//
//  XYRoutes.m
//  Pods
//
//  Created by henry on 2017/10/27.
//

#import "XYRoutes.h"
#import <XYRoutes/XYRouteRegularly.h>

static NSString *XYRouteDefaultScheme = @"XYRouteDefaultScheme";

@implementation XYRoutes
@synthesize routeMap = _routeMap;

#pragma mark - public method
+ (NSMutableDictionary *)routesMap{
    static dispatch_once_t onceToken;
    static NSMutableDictionary *routesMap = nil;
    dispatch_once(&onceToken, ^{
        routesMap = [NSMutableDictionary new];
    });
    return routesMap;
}

+ (instancetype)defaultRoutes{
    static dispatch_once_t onceToken;
    static XYRoutes *route = nil;
    dispatch_once(&onceToken, ^{
        route = [[XYRoutes alloc]initWithScheme:XYRouteDefaultScheme];
    });
    return route;
}

+ (instancetype)routesForScheme:(NSString *)scheme{
    XYRoutes *routes = [[self routesMap] objectForKey:scheme];
    if (!routes) {
        routes = [[self alloc]initWithScheme:scheme];
        [[self routesMap] setObject:routes forKey:scheme];
    }
    return routes;
}

+ (void)unregisterScheme:(NSString *)scheme{
    [[self routesMap] removeObjectForKey:scheme];
}

- (void)addRoute:(NSString *)routePattern handelEvent:(void (^)(NSString *, NSDictionary *))handelEvent{
    NSAssert(routePattern, @"routePattern is nil");
    NSAssert(handelEvent, @"handelEvent is nil");
    XYRouteResponse *response = [XYRouteResponse new];
    response.routePattern = routePattern;
    [response setRouteHandelEvent:handelEvent];
    [self.routeMap setObject:response forKey:routePattern];
}

- (void)removeRoute:(NSString *)routePattern{
    [self.routeMap removeObjectForKey:routePattern];
}

- (BOOL)routeURL:(NSURL *)url{
    
    BOOL receiveRoute = [self checkScheme:url];
    if (receiveRoute) {
        XYRouteRequest *request = [[XYRouteRequest alloc]initWithUrl:url];
        for (NSString *pattern in self.routeMap.allKeys) {
            if ([XYRouteRegularly  matchRouteWithPath:request.path routePattern:pattern]) {
                XYRouteResponse *response = self.routeMap[pattern];
                response.url = url;
                response.params = request.params;
                [response actionRoute];
            }
        }
    }
    return receiveRoute;
}

#pragma mark - private method
- (instancetype)initWithScheme:(NSString *)scheme{
    self = [super init];
    if (self) {
        _scheme = scheme;
    }
    return self;
}


- (BOOL)checkScheme:(NSURL *)url{
    //默认的Routes接收所有的route
    if ([self.scheme isEqualToString:XYRouteDefaultScheme]) {
        return YES;
    }
    
    if ([self.scheme isEqualToString:url.host]) {
        return YES;
    }
    return NO;
}

#pragma mark - Custom Accessors
- (NSMutableDictionary *)routeMap{
    if (_routeMap == nil) {
        _routeMap = [NSMutableDictionary new];
    }
    return _routeMap;
}


@end
