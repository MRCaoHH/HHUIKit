//
//  XYTextField.m
//  XYUIKit
//
//  Created by henry on 2017/11/3.
//

#import "XYTextField.h"
@interface XYTextField ()
@end

@implementation XYTextField

- (instancetype)init{
    self = [super init];
    if (self) {
        [self initConfig];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initConfig];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initConfig];
    }
    return self;
}

- (void)initConfig{
    self.clearButtonMode = UITextFieldViewModeWhileEditing;
}


- (void)layoutSubviews{
    [super layoutSubviews];
    self.leftView.frame = CGRectMake(0, 0, self.frame.size.height,  self.frame.size.height);
}

- (void)drawRect:(CGRect)rect {
    // Drawing code
    [super drawRect:rect];
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    ///绘制底线
    CGContextSetFillColorWithColor(context,self.bottomLineColor.CGColor);
    CGFloat lineHeight = 1.0/[UIScreen mainScreen].scale;
    ///绘制线条
    CGContextFillRect(context, CGRectMake(0, CGRectGetHeight(self.frame) - lineHeight, CGRectGetWidth(self.frame), lineHeight));
    
}


- (void)setLeftImage:(UIImage *)leftImage{
    self.leftViewMode = UITextFieldViewModeAlways;
    self.leftView = ({
        UIImageView *imageView = [UIImageView new];
        imageView.image = leftImage;
        imageView.contentMode = UIViewContentModeCenter;
        imageView;
    });
}

- (UIColor *)bottomLineColor{
    if (_bottomLineColor == nil) {
        return [UIColor blackColor];
    }
    return _bottomLineColor;
}
@end
