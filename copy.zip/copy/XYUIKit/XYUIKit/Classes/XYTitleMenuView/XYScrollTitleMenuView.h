//
//  XYScrollTitleMenuView.h
//  XYLPersonHomePage
//
//  Created by henry on 2017/11/27.
//

#import <UIKit/UIKit.h>
static CGFloat kXYScrollTitleMenuViewHeight = 55;
@interface XYScrollTitleMenuView : UIView

/**
 标题
 */
@property (nonatomic,strong) NSArray *titles;

/**
 选中标题
 */
@property (nonatomic,copy) void(^didSelectTitle) (NSInteger index);

/**
 字体
 */
@property (nonatomic,strong) UIFont *font;

/**
 标题颜色
 */
@property (nonatomic,strong) UIColor *titleColor;

/**
 滑块颜色
 */
@property (nonatomic,strong) UIColor *blockBgColor;

/**
 选中标题颜色
 */
@property (nonatomic,strong) UIColor *selTitleColor;

/**
 滑块自动大小
 */
@property (nonatomic,assign) BOOL blockAutoSize;

/**
 item固定宽度
 */
@property (nonatomic,assign) CGFloat fixItemWidth;

/**
 背景颜色
 */
@property (nonatomic,assign) UIColor *bgColor;
/**
 根据标题初始化实例

 @param titles 标题数组
 @return 实例
 */
- (instancetype)initWithTitles:(NSArray *)titles;

/**
 根据标题初始化实例

 @param titles 标题数组
 @param frame 大小位置
 @return 实例
 */
- (instancetype)initWithTitles:(NSArray *)titles frame:(CGRect)frame;

/**
 设置选中下标

 @param index 下x标
 */
- (void)setSelectWithIndex:(int)index;
@end
