//
//  XYRouteRequest.h
//  Pods
//
//  Created by henry on 2017/10/27.
//

#import <Foundation/Foundation.h>

@interface XYRouteRequest : NSObject
/**
 地址
 */
@property (nonatomic, readonly) NSURL *url;


/**
 路径组成
 例如 URL=XYRoute://Post/Jump
 pathComponents=['Post','Jump']
 */
@property (nonatomic, readonly) NSArray *pathComponents;


/**
 路径
 例如 URL=XYRoute://Post/Jump
 path=Post/Jump
 */
@property (nonatomic, readonly) NSString *path;


/**
 参数
 例如 URL=XYRoute://Post/Jump?param=1&param2=2
 params={"param":"1","param2":"2"}
 */
@property (nonatomic, readonly) NSMutableDictionary *params;

/**
 初始化请求
 
 @param url URL
 @return XYRouteRequest
 */
- (instancetype)initWithUrl:(NSURL *)url;

@end
