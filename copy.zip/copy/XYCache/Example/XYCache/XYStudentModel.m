//
//  XYStudentModel.m
//  XYCache
//
//  Created by henry on 2017/10/27.
//  Copyright © 2017年 henry. All rights reserved.
//

#import "XYStudentModel.h"

@implementation XYStudentModel

@end
