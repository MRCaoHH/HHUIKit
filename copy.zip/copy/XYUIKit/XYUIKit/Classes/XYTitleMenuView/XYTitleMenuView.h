//
//  XYTitleMenuView.h
//  XY
//
//  Created by henry on 2018/1/2.
//

#import <UIKit/UIKit.h>

@interface XYTitleMenuView : UIView
@property (nonatomic,strong,readonly) NSArray *titles;
- (instancetype)initWithTitles:(NSArray *)titles;
- (instancetype)initWithTitles:(NSArray *)titles bgColor:(UIColor *)bgColor textColor:(UIColor *)textColor;
- (instancetype)initWithTitles:(NSArray *)titles fixWidths:(NSDictionary *)fixWidths bgColor:(UIColor *)bgColor textColor:(UIColor *)textColor;

/**
 标题高度
 */
@property (nonatomic,assign) CGFloat titleHeight;

/**
 文字大小
 */
@property (nonatomic,assign) CGFloat titleFontSize;
@end
