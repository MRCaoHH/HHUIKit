//
//  NavigationController.h
//  Pods
//
//  Created by caohuihui on 2017/10/29.
//
//

#import <UIKit/UIKit.h>

@interface XYNavigationController : UINavigationController

@end
