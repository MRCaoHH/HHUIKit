//
//  XYEmojiSourceProtocol.h
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/16.
//

#import <UIKit/UIKit.h>

@interface XYEmojiSourceProtocol : NSObject

/**
 注册的类
 */
@property (nonatomic, class, readonly) Class regisclass;

/**
 注册协议对象
 
 @param aclass 对象类
 */
+ (BOOL)registerClass:(Class)aclass;


/**
 取消注册协议对象
 
 @param aclass 对象类
 */
+ (void)unregisterClass:(Class)aclass;

/**
 资源库
 
 @return 资源所在的bundle
 */
+ (NSBundle *)sourceBundle;

/**
 根据名字获取图片
 
 @param imageName 图片名字
 @return 图片
 */
+ (UIImage *)imageWithName:(NSString *)imageName;


/**
 获取路径

 @param name 文件名
 @param type 文件类型
 @return 文件路径
 */
+ (NSString *)pathWithName:(NSString *)name withType:(NSString *)type;
@end
