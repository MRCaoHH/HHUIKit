# XYMacro

[![CI Status](http://img.shields.io/travis/henry/XYMacro.svg?style=flat)](https://travis-ci.org/henry/XYMacro)
[![Version](https://img.shields.io/cocoapods/v/XYMacro.svg?style=flat)](http://cocoapods.org/pods/XYMacro)
[![License](https://img.shields.io/cocoapods/l/XYMacro.svg?style=flat)](http://cocoapods.org/pods/XYMacro)
[![Platform](https://img.shields.io/cocoapods/p/XYMacro.svg?style=flat)](http://cocoapods.org/pods/XYMacro)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYMacro is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYMacro'
```

## Author

henry, henry@xy.com

## License

XYMacro is available under the MIT license. See the LICENSE file for more info.
