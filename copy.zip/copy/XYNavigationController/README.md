# XYNavigationController

[![CI Status](http://img.shields.io/travis/henry/XYNavigationController.svg?style=flat)](https://travis-ci.org/henry/XYNavigationController)
[![Version](https://img.shields.io/cocoapods/v/XYNavigationController.svg?style=flat)](http://cocoapods.org/pods/XYNavigationController)
[![License](https://img.shields.io/cocoapods/l/XYNavigationController.svg?style=flat)](http://cocoapods.org/pods/XYNavigationController)
[![Platform](https://img.shields.io/cocoapods/p/XYNavigationController.svg?style=flat)](http://cocoapods.org/pods/XYNavigationController)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYNavigationController is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYNavigationController'
```

## Author

henry, henry@xy.com

## License

XYNavigationController is available under the MIT license. See the LICENSE file for more info.
