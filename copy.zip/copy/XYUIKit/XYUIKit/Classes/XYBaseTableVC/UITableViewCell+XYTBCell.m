//
//  UITableViewCell+XYTBCell.m
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import "UITableViewCell+XYTBCell.h"
#import <objc/runtime.h>

@implementation UITableViewCell (XYTBCell)

- (void)setXy_disposable:(RACDisposable *)xy_disposable{
    objc_setAssociatedObject(self, @selector(xy_disposable), xy_disposable, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

- (RACDisposable *)xy_disposable{
    return objc_getAssociatedObject(self, @selector(xy_disposable));
}

@end
