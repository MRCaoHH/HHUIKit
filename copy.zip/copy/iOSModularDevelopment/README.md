# iOS模块化开发

## 1.下载脚本

```
git clone http://pods.xy.com:3000/iOS/iOSModularDevelopment.git
```
## 2.创建仓库并初始化模板

在此之前先设置本地git用户名和邮箱

```
git config --global user.name "userName"

git config --global user.email "Email"
```

进入Script目录执行命令

```
# userName 用户名，用于登录gitlab的用户名
# password 密码，用户登录gitlab的密码
# token gitlab的Private token
# rootPath 将仓库克隆到本地的目录路径
# projectName 仓库名字，工程名字
# desc 项目、工程描述简介
./createRepo.sh -u userName -p password -t token -n projectName -d desc -r rootPath
```

## 3.发布podspec
代码编写完成后执行仓库目录下的`UpdatePodScript.sh`脚本

```
# userName 用户名，用于登录gitlab的用户名
# password 密码，用户登录gitlab的密码
# deleteOldTag 是否删除原有的tag，例如之前发布一次v1.0.0的版本，下一次发布的时候需要删除原来的版本  1 删除 0 不删除 默认值0
# commitFlag 是否将代码提交到服务器，如果本地代码修改则必须上传服务器 1 上传 0 不上传 默认值 1
./UpdatePodScript.sh -u userName -p password -d deleteOldTag -m commitFlag
```

如果不想每次都设置用户名密码这么麻烦的话可以设置环境变量

```
vim ~/.bash_profile
```

添加用户名密码

```
//userName 用户名，用于登录gitlab的用户名
//password 密码，用户登录gitlab的密码
export GITLABUSERNME=userName
export GITLABPASSWORD=password
```

保存并退出执行命令

```
source ~/.bash_profile
```
## 4.模块化问题

1.搜索不到私有库
执行命令:`rm ~/Library/Caches/CocoaPods/search_index.json`
之后再搜索

## 5.模块前缀缩写

|前缀|意义|
|---|---|
|XY|公司前缀|
|XYL|L live 直播项目组件|


