//
//  main.m
//  XYCache
//
//  Created by henry on 10/27/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

@import UIKit;
#import "XYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XYAppDelegate class]));
    }
}
