//
//  XYChatPictureBubbleCell.m
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import "XYChatPictureBubbleCell.h"
#import "XYChatMsgPictureModel.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <XYCategory/XYCategory.h>

@implementation XYChatPictureBubbleCell
static CGFloat kPictureMaxWidth = 160;
static CGFloat kPictureMaxHeight = 160;
static CGFloat kPictureMinWidth = 80;
static CGFloat kPictureMinHeight = 80;
- (void)initSubview{
    [super initSubview];
    _imgView = [UIImageView new];
    [self.bubbleImgView addSubview:_imgView];
    
    _coverView = [UIView new];
    _coverView.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.5];
    _coverView.hidden = YES;
    [self.bubbleImgView addSubview:_coverView];
    
    _progressLabel = [UILabel new];
    _progressLabel.font = [UIFont systemFontOfSize:17];
    _progressLabel.textColor = [UIColor whiteColor];
    _progressLabel.textAlignment = NSTextAlignmentCenter;
    _progressLabel.hidden = YES;
    [self.bubbleImgView addSubview:_progressLabel];
}

+ (void)calFrameWithPictModel:(XYChatMsgPictureModel **)picModel{
    XYChatMsgPictureModel *model = *picModel;
    CGFloat imgX = model.isSend ? kChatContentOtheEdge:kChatContentArrowEdge;
    CGFloat imgY = kChatContentOtheEdge;
    CGFloat imgW = model.width;
    CGFloat imgH = model.height;
    CGFloat scaleW = 1;
    if (imgW > kPictureMaxWidth) {
        scaleW = kPictureMaxWidth/imgW;
    }
    if (imgW < kPictureMinWidth) {
        scaleW = kPictureMinWidth/imgW;
    }
    
    CGFloat scaleH = 1;
    if (imgH > kPictureMaxHeight) {
        scaleH = kPictureMaxHeight/imgH;
    }
    if (imgH < kPictureMinHeight) {
        scaleH = kPictureMinHeight/imgH;
    }
    
    CGFloat scale = scaleW > scaleH ? scaleH : scaleW;
    imgH *=scale;
    imgW *=scale;
    CGRect picFrame = CGRectMake(imgX, imgY, imgW, imgH);
    CGRect bubbleFrame = [self calBubbleFrameWithContentSize:picFrame.size isSend:model.isSend];
    CGFloat cellHeight = [self calCellHeightWithBubbleFrame:bubbleFrame];
    
    model.imgFrame = picFrame;
    model.bubbleFrame = bubbleFrame;
    model.cellHeight = cellHeight;
}

#pragma mark - 属性方法 -
- (void)setModel:(XYChatMsgBaseModel *)model{
    XYChatMsgPictureModel *picModel = (XYChatMsgPictureModel *)model;
    [super setModel:model];
    self.imgView.frame = picModel.imgFrame;
    self.coverView.frame = picModel.imgFrame;
    self.progressLabel.frame = picModel.imgFrame;
    self.progressLabel.hidden = picModel.state != XYChatMsgSendState_Sending;
    self.coverView.hidden = picModel.state != XYChatMsgSendState_Sending;
    self.coverView.xy_height = picModel.imgFrame.size.height * (100 - picModel.progress)/100;
    self.progressLabel.text = [NSString stringWithFormat:@"%li%%",picModel.progress];
    __weak typeof(self) weakSelf = self;
    [picModel setUploadPicProgress:^(NSInteger progress) {
        void(^block)(void) = ^{
            weakSelf.progressLabel.text = [NSString stringWithFormat:@"%li%%",progress];
            XYChatMsgPictureModel *picModel = (XYChatMsgPictureModel *)weakSelf.model;
            weakSelf.coverView.xy_height = picModel.imgFrame.size.height * (100 - progress)/100;
            if (progress >= 100) {
                weakSelf.progressLabel.hidden = YES;
                weakSelf.coverView.hidden = YES;
            }
        };
        if ([NSThread isMainThread]) {
            block();
        } else {
            dispatch_async(dispatch_get_main_queue(),block);
        }
    }];
    
    if (picModel.localImg) {
        self.imgView.image = picModel.localImg;
    }else{
        [self.imgView sd_setImageWithURL:[NSURL URLWithString:picModel.thumbPicUrl]];
    }
}
@end
