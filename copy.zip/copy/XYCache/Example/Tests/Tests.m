//
//  XYCacheTests.m
//  XYCacheTests
//
//  Created by henry on 10/27/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

@import XCTest;
#import "XYStudentModel.h"
#import "XYSchoolModel.h"

@interface Tests : XCTestCase

@end

@implementation Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testArchiverNestedModel{
    XYStudentModel *student = [[XYStudentModel alloc]init];
    student.name = @"henry";
    student.sex = YES;
    student.height = 170;
    
    XYSchoolModel *school = [XYSchoolModel new];
    school.schoolName = @"天天";
    school.address = @"青山一路250号";
    student.school = school;
    
    [XYCache addCacheWithKey:[NSString stringWithFormat:@"%li",student.hash] object:student];

    XYStudentModel *student2 = [XYCache cacheWithKey:[NSString stringWithFormat:@"%li",student.hash]];
    
    XCTAssertTrue(student == student2);
    
}

@end

