//
//  XYMenuCollectionCell.m
//  XYUIKit
//
//  Created by henry on 2018/1/2.
//

#import "XYMenuCollectionCell.h"
#import <XYCategory/XYCategory.h>
#import <Masonry/Masonry.h>
#import <XYMacro/XYMacro_Key.h>

@implementation XYMenuCollectionCell

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubview];
        [self initConstraints];
    }
    return self;
}

- (void)setSelected:(BOOL)selected{
    self.backgroundColor = selected ?[UIColor lightGrayColor]:[UIColor whiteColor];
}

- (void)setHighlighted:(BOOL)highlighted{
    self.backgroundColor = highlighted ?[UIColor lightGrayColor]:[UIColor whiteColor];
}

#pragma mark - 初始化 -
- (void)initSubview{
    self.backgroundColor = [UIColor whiteColor];
    
    _iconImgView = [UIImageView new];
    [self.contentView addSubview:_iconImgView];
    
    _nameLabel = [UILabel new];
    _nameLabel.textColor = [UIColor xy_colorWithHexString:@"#999999"];
    _nameLabel.font = [UIFont systemFontOfSize:14];
    [self.contentView addSubview:_nameLabel];
}

- (void)initConstraints{
    [_iconImgView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.contentView.mas_centerY).offset(-10);
        make.centerX.equalTo(self.contentView.mas_centerX);
    }];
    
    [_nameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.contentView.mas_centerX);
        make.top.equalTo(_iconImgView.mas_bottom).offset(10);
    }];
}

@end
