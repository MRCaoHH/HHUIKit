//
//  XYScrollTitleMenuView.m
//  XYLPersonHomePage
//
//  Created by henry on 2017/11/27.
//

#import "XYScrollTitleMenuView.h"
#import <XYCategory/XYCategory.h>
#import <Masonry/Masonry.h>

@interface XYTitleMenuCell:UICollectionViewCell
@property (nonatomic,strong) UILabel *countLabel;
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UIColor *selTitleColor;
@property (nonatomic,strong) UIColor *titleColor;
@property (nonatomic,assign) BOOL isSel;
@end

@implementation XYTitleMenuCell
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubview];
    }
    return self;
}

- (void)initSubview{
    self.backgroundColor = [UIColor whiteColor];
    _titleLabel = [[UILabel alloc]initWithFrame:self.bounds];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.font = [UIFont systemFontOfSize:17];
    _titleLabel.numberOfLines = 2;
    [self addSubview:_titleLabel];
    
    [_titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
}

- (void)setSelected:(BOOL)selected{
    
}

- (void)setIsSel:(BOOL)isSel{
    _titleLabel.textColor = isSel?_selTitleColor:_titleColor;
}
@end

@interface XYScrollTitleMenuView ()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>{
    NSInteger _selRow;
}
@property (nonatomic,strong) UICollectionView *collectionView;
@property (nonatomic,strong) UIView *blockView;
@property (nonatomic,strong) UIView *sepLineView;
@property (nonatomic,assign) CGFloat itemWidth;
@property (nonatomic,strong) UICollectionViewFlowLayout *flowLayout;
@end

@implementation XYScrollTitleMenuView
@synthesize  bgColor = _bgColor;
static NSString *kReuserIdentifier = @"kReuserIdentifier";

- (instancetype)initWithTitles:(NSArray *)titles{
    return [self initWithTitles:titles frame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, kXYScrollTitleMenuViewHeight)];
}

- (instancetype)initWithTitles:(NSArray *)titles frame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _titles = titles;
        _blockBgColor = [UIColor redColor];
        _font = [UIFont systemFontOfSize:17];
        _titleColor = [UIColor blackColor];
        _selTitleColor = [UIColor redColor];
        _selRow = 0;
        [self initSubview];
        
    }
    return self;
}

- (void)initSubview{
    [self calItemWidth];
    CGFloat itemWidth = self.itemWidth;
    CGSize itemSize = CGSizeMake(itemWidth, self.frame.size.height);
    _flowLayout = [[UICollectionViewFlowLayout alloc]init];
    _flowLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    _flowLayout.itemSize = itemSize;
    _flowLayout.estimatedItemSize = CGSizeZero;
    _flowLayout.minimumLineSpacing = 0;
    _flowLayout.minimumInteritemSpacing = 2;
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height) collectionViewLayout:_flowLayout];
    _collectionView.delegate = self;
    _collectionView.dataSource = self;
    _collectionView.backgroundColor = [UIColor xy_colorWithHexString:@"#F0F0F4"];
    [_collectionView registerClass:[XYTitleMenuCell class] forCellWithReuseIdentifier:kReuserIdentifier];
    [_collectionView setAllowsSelection:YES];
    [_collectionView setAllowsMultipleSelection:NO];
    _collectionView.showsHorizontalScrollIndicator = NO;
    [self addSubview:_collectionView];
    
    _blockView = [[UIView alloc]initWithFrame:CGRectZero];
    _blockView.backgroundColor = self.blockBgColor;
    _blockView.xy_height = 3;
    [_collectionView addSubview:_blockView];
    
    CGFloat lineHeight = 1.0;
    _sepLineView = [[UIView alloc]initWithFrame:CGRectMake(0, self.frame.size.height - lineHeight,  self.frame.size.width, lineHeight)];
    _sepLineView.backgroundColor = [UIColor xy_colorWithHexString:@"#F0F0F4"];
    [self addSubview:_sepLineView];
    [_collectionView selectItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] animated:YES scrollPosition:UICollectionViewScrollPositionNone];
    [self collectionView:_collectionView didSelectItemAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0] ];
    
    [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
    
    if (self.titles.count > 0) {
        [self setSelectWithIndex:0];
    }
}

- (void)setTitles:(NSArray *)titles{
    _titles = titles;
    [self calItemWidth];
}

- (void)calItemWidth{
    CGFloat itemWidth = (self.frame.size.width - 2)/_titles.count;
    if (_titles.count > 4) {
        itemWidth = self.frame.size.width/4;
    }
    if (self.fixItemWidth > 0) {
        itemWidth = self.fixItemWidth;
    }
    _itemWidth = itemWidth;
    CGSize itemSize = CGSizeMake(self.itemWidth, self.frame.size.height);
    _flowLayout.itemSize = itemSize;
    _blockView.xy_width = self.itemWidth;
    [self.collectionView reloadData];
}

#pragma mark - 协议 -
#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [self.titles count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    XYTitleMenuCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kReuserIdentifier forIndexPath:indexPath];
    cell.titleLabel.text = self.titles[indexPath.row];
    cell.titleColor = self.titleColor;
    cell.selTitleColor = self.selTitleColor;
    cell.titleLabel.font = self.font;
    cell.isSel = indexPath.row == _selRow;
    cell.backgroundColor = self.bgColor;
    return cell;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    _selRow = indexPath.row;
    [self.collectionView reloadData];
    if (self.didSelectTitle) {
        self.didSelectTitle(indexPath.row);
    }
    
    [self scrollBlockWithIndex:indexPath.row];
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(self.itemWidth, self.xy_height);
}
#pragma mark - 其他方法 -
- (void)setSelectWithIndex:(int)index{
    _selRow = index;
    [_collectionView selectItemAtIndexPath:[NSIndexPath indexPathForRow:index inSection:0] animated:YES scrollPosition:UICollectionViewScrollPositionNone];
    [_collectionView reloadData];
    [self scrollBlockWithIndex:index];
}

- (void)scrollBlockWithIndex:(NSInteger)index{
    CGFloat centerX = index * self.itemWidth + self.itemWidth/2;
    CGFloat width = self.itemWidth;
    if (self.blockAutoSize) {
        NSString *title = self.titles[index];
        CGSize size = [title sizeWithAttributes:@{NSFontAttributeName:self.font}];
        width = size.width;
    }
    self.blockView.xy_bottom = self.xy_height;
    [UIView animateWithDuration:0.2 animations:^{
        self.blockView.xy_width = width;
        self.blockView.xy_centerX = centerX;
    }];
}

#pragma mark - 属性方法
- (void)setBlockBgColor:(UIColor *)blockBgColor{
    _blockBgColor = blockBgColor;
    _blockView.backgroundColor = blockBgColor;
}

- (void)setFont:(UIFont *)font{
    _font = font;
    [_collectionView reloadData];
}

- (void)setTitleColor:(UIColor *)titleColor{
    _titleColor = titleColor;
    [_collectionView reloadData];
}

- (void)setSelTitleColor:(UIColor *)selTitleColor{
    _selTitleColor = selTitleColor;
    [_collectionView reloadData];
}

- (void)setFixItemWidth:(CGFloat)fixItemWidth{
    _fixItemWidth = fixItemWidth;
    [self calItemWidth];
}

- (void)setBgColor:(UIColor *)bgColor{
    _bgColor = bgColor;
    self.collectionView.backgroundColor = bgColor;
}

- (UIColor *)bgColor{
    if (_bgColor == nil) {
        _bgColor = [UIColor whiteColor];
    }
    return _bgColor;
}

@end
