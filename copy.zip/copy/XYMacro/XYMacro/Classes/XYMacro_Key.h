//
//  XYMacro_Key.h
//  Pods
//
//  Created by henry on 2017/10/27.
//

#ifndef XYMacro_Key_h
#define XYMacro_Key_h

//设备尺寸
#define XYScreen_Bounds [UIScreen mainScreen].bounds
#define XYScreen_Height [UIScreen mainScreen].bounds.size.height
#define XYScreen_Width [UIScreen mainScreen].bounds.size.width

//状态栏高度
#define XYStatusBarHeight [UIApplication sharedApplication].statusBarFrame.size.height

#define XYDevice_Is_iPhone4s (CGSizeEqualToSize(CGSizeMake(320,480), [UIScreen mainScreen].bounds.size))
#define XYDevice_Is_iPhone5 (CGSizeEqualToSize(CGSizeMake(320, 568), [UIScreen mainScreen].bounds.size))
#define XYDevice_Is_iPhone6 (CGSizeEqualToSize(CGSizeMake(375, 667), [UIScreen mainScreen].bounds.size))
#define XYDevice_Is_iPhone6Plus (CGSizeEqualToSize(CGSizeMake(414, 736), [UIScreen mainScreen].bounds.size))

#endif /* XYMacro_Key_h */
