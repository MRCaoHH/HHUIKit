//
//  XYMenuCollectionVC.m
//  XYUIKit
//
//  Created by henry on 2018/1/2.
//

#import "XYMenuCollectionVC.h"
#import <XYMacro/XYMacro_Key.h>
#import <XYCategory/XYCategory.h>
#import "XYMenuCollectionCell.h"
#import "XYMenuCollectionItem.h"
#import <SDWebImage/UIImageView+WebCache.h>
#import <objc/message.h>

@interface XYMenuCollectionVC ()

@end

@implementation XYMenuCollectionVC
static NSString * const kReuseIdentifier = @"Cell";
static NSString * const kHeaderReuseIdentifier = @"kHeaderReuseIdentifier";
#pragma mark - 初始化 -
- (instancetype)init{
    UICollectionViewFlowLayout *flowLayout = [UICollectionViewFlowLayout new];
    
    CGFloat sepLine = 1.0 / [UIScreen mainScreen].scale;
    //左右边距各5像素，item与item的间距是5
    CGFloat itemWidth = (XYScreen_Width - sepLine*2 - 2)/3;
    NSInteger intItemWidth = itemWidth;
    if (itemWidth - intItemWidth < sepLine) {
        itemWidth = intItemWidth;
    }
    flowLayout.itemSize = CGSizeMake(itemWidth, itemWidth);
    //行距0
    flowLayout.minimumLineSpacing = sepLine;
    flowLayout.minimumInteritemSpacing = sepLine;
    flowLayout.sectionInset = UIEdgeInsetsMake(0, 1, 0, 1);
    self = [super initWithCollectionViewLayout:flowLayout];
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView.backgroundColor = [UIColor xy_colorWithHexString:@"#F0F0F0"];
    if (self.headerView) {
        [self.collectionView registerClass:[self.headerView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:kHeaderReuseIdentifier];
    }
    [self.collectionView registerClass:[XYMenuCollectionCell class] forCellWithReuseIdentifier:kReuseIdentifier];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - 协议 -
#pragma mark UICollectionViewDataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [self.items count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    XYMenuCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:kReuseIdentifier forIndexPath:indexPath];
    XYMenuCollectionItem *item = self.items[indexPath.row];
    cell.nameLabel.text = item.name;
    [cell.iconImgView sd_setImageWithURL:[NSURL URLWithString:item.iconUrl]];
    return cell;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [collectionView deselectItemAtIndexPath:indexPath animated:YES];
    XYMenuCollectionItem *item = self.items[indexPath.row];
    SEL action =  NSSelectorFromString(item.action);
    if ([self.actionTarget respondsToSelector:action]) {
        ((void (*)(id,SEL))objc_msgSend)(self.actionTarget,action);
    }
}

-(UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    //如果kind表示的是分区的头部视图
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        UICollectionReusableView *header = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:kHeaderReuseIdentifier forIndexPath:indexPath];
        if (header) {
            self.headerView = header;
        }
        return self.headerView;
    }
    //没有尾部视图，直接返回nil
    return [UICollectionReusableView new];
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return  CGSizeMake(XYScreen_Width, self.headerView.xy_height);
}

@end
