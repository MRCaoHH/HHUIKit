//
//  XYHttpRequest.h
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import <Foundation/Foundation.h>

@class XYRequestModel;
@class XYResponseModel;

typedef NS_ENUM(NSInteger,XYResponseType) {
    XYResponseType_Json = 0,//返回的文本类型是json
    XYResponseType_Data = 1,//返回的文本类型是Data
    XYResponseType_XML = 2,//返回的文本类型是XML
};

typedef NS_ENUM(NSInteger,XYRequestType) {
    XYRequestType_Normal = 0,//正常
    XYRequestType_Json = 1,//json格式
    XYRequestType_PropertyList = 2,//属性列表
};

@interface XYHttpRequest : NSObject

/**
 *  Post请求
 *
 *  @param url      请求地址
 *  @param params   参数
 *  @param success  成功回调
 *  @param failure  失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)POST:(NSString  *)url params:(id)params  success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;


/**
 *  Post请求
 *
 *  @param url      请求地址
 *  @param params   参数
 *  @param progress 进度回调
 *  @param success  成功回调
 *  @param failure  失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)POST:(NSString  *)url params:(id)params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;


/**
 *   Post请求
 *
 *  @param url          请求地址
 *  @param responseType 返回文本类型
 *  @param params       参数
 *  @param progress     进度回调
 *  @param success      成功回调
 *  @param failure      失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)POST:(NSString  *)url responseType:(XYResponseType)responseType params:(id)params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;

/**
 *   Post请求
 *
 *  @param url          请求地址
 *  @param requestType   请求类型
 *  @param responseType 返回文本类型
 *  @param params       参数
 *  @param progress     进度回调
 *  @param success      成功回调
 *  @param failure      失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)POST:(NSString  *)url requestType:(XYRequestType)requestType  responseType:(XYResponseType)responseType params:(id)params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;

/**
 *  @brief POST请求上传
 *
 *  @param url         请求地址
 *  @param params      参数
 *  @param uploadParam 上传内容
 *  @param success     成功回调
 *  @param failure     失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+ (XYRequestModel *)POST:(NSString  *)url params:(id)params uploadParam:(NSDictionary *)uploadParam    success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;


/**
 *  @brief POST请求上传
 *
 *  @param url          请求地址
 *  @param params       参数
 *  @param uploadParam  上传内容
 *  @param progress     进度回调
 *  @param success      成功回调
 *  @param failure      失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+ (XYRequestModel *)POST:(NSString  *)url params:(id)params uploadParam:(NSDictionary *)uploadParam progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;

/**
 *  @brief POST请求上传
 *
 *  @param url          请求地址
 *  @param responseType 返回类型
 *  @param params       参数
 *  @param uploadParam  上传内容
 *  @param progress     进度回调
 *  @param success      成功回调
 *  @param failure      失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)POST:(NSString  *)url responseType:(XYResponseType)responseType params:(id)params uploadParam:(NSDictionary *)uploadParam progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;

/**
 *  @brief POST请求上传

 *  @param url          请求地址
 *  @param requestType   请求类型
 *  @param responseType 返回类型
 *  @param params       参数
 *  @param uploadParam  上传内容
 *  @param progress     进度回调
 *  @param success      成功回调
 *  @param failure      失败回调
 @return 返回XYRequestModel模型
 */
+(XYRequestModel *)POST:(NSString  *)url requestType:(XYRequestType)requestType responseType:(XYResponseType)responseType params:(id)params uploadParam:(NSDictionary *)uploadParam progress:(void (^)(NSProgress * uploadProgress))progress  success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;


/**
 @brief POST请求上传

 @param url 请求地址
 @param requestType 请求类型
 @param responseType 返回类型
 @param params 参数
 @param uploadParam 上传参数
 @param fileType 文件类型
 @param fileSuffix 文件后缀
 @param progress 进度
 @param success 成功回调
 @param failure 失败回调
 @return 返回XYRequestModel模型
 */
+ (XYRequestModel *)POST:(NSString *)url requestType:(XYRequestType)requestType responseType:(XYResponseType)responseType params:(id)params uploadParam:(NSDictionary *)uploadParam fileType:(NSString *)fileType fileSuffix:(NSString *)fileSuffix progress:(void (^)(NSProgress *))progress success:(void (^)(XYResponseModel *))success failure:(void (^)(XYResponseModel *))failure;


/**
 *  Get请求
 *
 *  @param url      请求地址
 *  @param params   参数
 *  @param success  成功回调
 *  @param failure  失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)GET:(NSString  *)url params:(id)params success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;


/**
 *  Get请求
 *
 *  @param url      请求地址
 *  @param params   参数
 *  @param progress 进度回调
 *  @param success  成功回调
 *  @param failure  失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)GET:(NSString  *)url params:(id)params progress:(void (^)(NSProgress * uploadProgress))progress success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;


/**
 *  Get请求
 *
 *  @param url          请求地址
 *  @param responseType 返回文本类型
 *  @param params       参数
 *  @param progress     进度回调
 *  @param success      成功回调
 *  @param failure      失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)GET:(NSString  *)url responseType:(XYResponseType)responseType params:(id)params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;


/**
 *   Get请求
 *
 *  @param url          请求地址
 *  @param requestType   请求类型
 *  @param responseType 返回文本类型
 *  @param params       参数
 *  @param progress     进度回调
 *  @param success      成功回调
 *  @param failure      失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+ (XYRequestModel *)GET:(NSString  *)url requestType:(XYRequestType)requestType responseType:(XYResponseType)responseType params:(NSDictionary * )params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;

/**
 获取完整的请求地址

 @param url 请求地址
 @return 完整请求地址
 */
+ (NSString *)requestUrl:(NSString *)url;
@end
