//
//  XYMenuCollectionItem.m
//  XYUIKit
//
//  Created by henry on 2018/1/2.
//

#import "XYMenuCollectionItem.h"

@implementation XYMenuCollectionItem

@end
