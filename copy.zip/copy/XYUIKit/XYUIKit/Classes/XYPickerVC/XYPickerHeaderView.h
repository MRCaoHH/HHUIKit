//
//  XYPickerHeaderView.h
//  XYUIKit
//
//  Created by henry on 2017/12/23.
//

#import <UIKit/UIKit.h>
@protocol XYPickerHeaderViewDelegate<NSObject>
@optional
- (void)clickOkButtonEvent;
- (void)clickCancelButtonEvent;
@end

static CGFloat kXYPickerHeaderViewHeight = 40;
@interface XYPickerHeaderView : UIView
@property (nonatomic,strong) UIButton *cancelButton;
@property (nonatomic,strong) UILabel *titleLabel;
@property (nonatomic,strong) UIButton *okButton;
@property (nonatomic,weak) id<XYPickerHeaderViewDelegate> delegate;
@end
