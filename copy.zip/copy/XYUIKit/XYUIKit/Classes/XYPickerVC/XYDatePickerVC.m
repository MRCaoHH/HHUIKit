//
//  XYDatePickerVC.m
//  XYUIKit
//
//  Created by henry on 2017/12/26.
//

#import "XYDatePickerVC.h"
#import <XYNavigationController/XYPickerDismiss.h>
#import <XYNavigationController/XYPickerPresent.h>
#import "XYPickerHeaderView.h"
#import "XYDateTool.h"

@interface XYDatePickerVC ()<UIViewControllerTransitioningDelegate,UIPickerViewDataSource,UIPickerViewDelegate,XYPickerHeaderViewDelegate>{
    NSInteger _component;
    XYDateStruct _dateStruct;
}
@property (nonatomic,strong) XYPickerHeaderView *headerView;
@property (nonatomic,strong) UIPickerView *pickerView;
@property (nonatomic,strong) NSCalendar *calendar;
@end

@implementation XYDatePickerVC
static CGFloat kPickerViewHeight = 200;

- (instancetype)init1900ToTodayPicker:(XYDatePickerType)type{
    self = [self initWithType:type minDate:[NSDate dateWithTimeIntervalSince1970:0] maxDate:[NSDate new]];
    return self;
}

- (instancetype)initWithType:(XYDatePickerType)type minDate:(NSDate *)minDate maxDate:(NSDate *)maxDate{
    self = [super init];
    if (self) {
        _type = type;
        _minDate = minDate;
        _maxDate = maxDate;
        _dateStruct.hour = 0;
        _dateStruct.second = 0;
        _dateStruct.min = 0;
        switch (self.type) {
            case XYDatePickerType_HHmm:{
                _component = 2;
            }
                break;
            case XYDatePickerType_hhmm:{
                _component = 2;
            }
                break;
            case XYDatePickerType_MMDD:{
                _dateStruct.month = 1;
                _dateStruct.day = 1;
                _component = 2;
            }
                break;
                
                break;
            case XYDatePickerType_YYYYMMDD:{
                _dateStruct.year = [self getYearTitle:0].intValue;
                _dateStruct.month = [self getMonthTitle:0 row:0].intValue;
                _dateStruct.day = [self getDayTitle:0 monthRow:0 dayRow:0].intValue;
                _component = 3;
            }
                break;
            case XYDatePickerType_hhmmss:{
                _component = 3;
            }
                break;
            case XYDatePickerType_HHmmss:{
                _component = 3;
            }
                break;
            default:
                break;
        }
        self.modalPresentationStyle = UIModalPresentationCustom;
        self.transitioningDelegate = self;
        [self initSubview];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self selectDate:_dateStruct];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self selectDate:_dateStruct];
}

#pragma mark - 初始化 -
- (void)initSubview{
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.headerView];
    [self.view addSubview:self.pickerView];
}

#pragma mark - 其他方法 -
- (void)selectDate:(XYDateStruct)date{
    if (XYDateStructIsZone(date)) {
        [self pickerView:self.pickerView didSelectRow:0 inComponent:0 ];
        return;
    }
    _dateStruct = date;
    switch (self.type) {
        case XYDatePickerType_HHmm:{
            [self.pickerView selectRow:date.hour inComponent:0 animated:NO];
            [self.pickerView selectRow:date.min inComponent:1 animated:NO];
            self.headerView.titleLabel.text = [NSString stringWithFormat:@"%02d:%02d",date.hour,date.min];
        }
            break;
        case XYDatePickerType_hhmm:{
            [self.pickerView selectRow:date.hour inComponent:0 animated:NO];
            [self.pickerView selectRow:date.min inComponent:1 animated:NO];
            self.headerView.titleLabel.text = [NSString stringWithFormat:@"%02d:%02d",date.hour,date.min];
        }
            break;
        case XYDatePickerType_MMDD:{
            [self.pickerView selectRow:date.month - 1 inComponent:0 animated:NO];
            [self.pickerView selectRow:date.day - 1 inComponent:1 animated:NO];
            self.headerView.titleLabel.text = [NSString stringWithFormat:@"%02d-%02d",date.month,date.day];
        }
            break;
        case XYDatePickerType_YYYYMMDD:{
            NSInteger minYear = [self.calendar component:NSCalendarUnitYear fromDate:_minDate];
            [self.pickerView selectRow:date.year - minYear inComponent:0 animated:NO];
            [self.pickerView reloadComponent:1];
            [self.pickerView selectRow:date.month - 1 inComponent:1 animated:NO];
            [self.pickerView reloadComponent:2];
            [self.pickerView selectRow:date.day - 1 inComponent:2 animated:NO];
            self.headerView.titleLabel.text = [NSString stringWithFormat:@"%d-%02d-%02d",date.year,date.month,date.day];
        }
            break;
        case XYDatePickerType_hhmmss:{
            [self.pickerView selectRow:date.hour inComponent:0 animated:NO];
            [self.pickerView selectRow:date.min - 1 inComponent:1 animated:NO];
            [self.pickerView selectRow:date.second - 1 inComponent:2 animated:NO];
            self.headerView.titleLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d",date.hour,date.min,date.second];
        }
            break;
        case XYDatePickerType_HHmmss:{
            [self.pickerView selectRow:date.hour inComponent:0 animated:NO];
            [self.pickerView selectRow:date.min - 1 inComponent:1 animated:NO];
            [self.pickerView selectRow:date.second - 1 inComponent:2 animated:NO];
            self.headerView.titleLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d",date.hour,date.min,date.second];
        }
            break;
        default:
            break;
    }
    [self.pickerView reloadAllComponents];
    
}
#pragma mark - 协议 -
#pragma mark - UIViewControllerTransitioningDelegate
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return ({
        XYPickerPresent *present = [XYPickerPresent new];
        present.viewSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, kXYPickerHeaderViewHeight+kPickerViewHeight);
        present;
    });
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return ({
        XYPickerDismiss *dismiss = [XYPickerDismiss new];
        dismiss;
    });
}

#pragma mark - XYPickerHeaderViewDelegate
- (void)clickOkButtonEvent{
    if ([self.delegate respondsToSelector:@selector(datePickerVC:year:month:day:hour:min:second:)]) {
        [self.delegate datePickerVC:self year:[NSString stringWithFormat:@"%i",_dateStruct.year] month:[NSString stringWithFormat:@"%02i",_dateStruct.month] day:[NSString stringWithFormat:@"%02i",_dateStruct.day] hour:[NSString stringWithFormat:@"%02i",_dateStruct.hour] min:[NSString stringWithFormat:@"%02i",_dateStruct.min] second:[NSString stringWithFormat:@"%02i",_dateStruct.second]];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)clickCancelButtonEvent{
    if ([self.delegate respondsToSelector:@selector(pickerVCDidClickCancelBtn:)]) {
        [self.delegate pickerVCDidClickCancelBtn:self];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return _component;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    switch (self.type) {
        case XYDatePickerType_HHmm:{
            return !component?[self getHourCount]:[self getMinCount];
        }
            break;
        case XYDatePickerType_hhmm:{
            return !component?[self getMinCount]:[self getHourCount];
        }
            break;
        case XYDatePickerType_MMDD:{
            return component?[self getDayCount:1999 month:[pickerView selectedRowInComponent:0]]:[self getMonthCount:1999];
        }
            break;
        case XYDatePickerType_YYYYMMDD:{
            switch (component) {
                case 0:{
                    return [self getYearCount];
                }
                    break;
                case 1:{
                    return [self getMonthCount:[pickerView selectedRowInComponent:0]];
                }
                    break;
                case 2:{
                    return [self getDayCount:[pickerView selectedRowInComponent:0] month:[pickerView selectedRowInComponent:1]];
                }
                    break;
            }
        }
            break;
        case XYDatePickerType_hhmmss:
        case XYDatePickerType_HHmmss:{
            switch (component) {
                case 0:{
                    return [self getHourCount];
                }
                    break;
                case 1:{
                    return [self getMinCount];
                }
                    break;
                case 2:{
                    return [self getSecondCount];
                }
                    break;
            }
        }
            break;
        default:
            break;
    }
    return 0;
}

#pragma mark - UIPickerViewDelegate
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    return [UIScreen mainScreen].bounds.size.width/_component;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 44;
}

- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    
    if (_type == XYDatePickerType_YYYYMMDD ) {
        switch (component) {
            case 0:
                return [self getYearTitle:row];
                break;
            case 1:
                return [self getMonthTitle:[pickerView selectedRowInComponent:0] row:row];
                break;
            case 2:
                return [self getDayTitle:[pickerView selectedRowInComponent:0] monthRow:[pickerView selectedRowInComponent:0] dayRow:row];
                break;
            default:
                break;
        }
    }
    if (_type == XYDatePickerType_MMDD) {
        return [self getOtheTitle:row + 1];
    }
    return [self getOtheTitle:row];;
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    NSInteger componentDef = _component - component;
    for (int i = 1; i<componentDef; i++) {
//        NSInteger orgIndex = [pickerView selectedRowInComponent:component+i];
        [pickerView reloadComponent:component+i];
//        NSInteger curMax = [pickerView  numberOfRowsInComponent:component+i];
//        if (orgIndex >= curMax) {
//            [pickerView selectRow:curMax - 1 inComponent:component+i animated:NO];
//        }
    }
    [self updateDateStruct:pickerView didSelectRow:row inComponent:component];
//    NSString *separatorChat = @":";
//    if (self.type == XYDatePickerType_YYYYMMDD || self.type == XYDatePickerType_MMDD) {
//        separatorChat = @"-";
//    }
//
//    NSMutableString *mutableString = @"".mutableCopy;
//    for (int i = 0; i< _component; i++) {
//        NSInteger aRow = [pickerView selectedRowInComponent:i];
//        NSString *title =  [self pickerView:pickerView titleForRow:aRow forComponent:i];
//        [mutableString appendString:title];
//        if(i+1 < _component ){
//            [mutableString appendString:separatorChat];
//        }
//    }
//
//    _headerView.titleLabel.text = mutableString;
    if ([self.delegate respondsToSelector:@selector(datePickerVC:titleDidChange:)]) {
        [self.delegate datePickerVC:self titleDidChange:_headerView.titleLabel.text];
    }
}

#pragma mark - 其他方法 -
- (void)updateDateStruct:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    int value =  [[self pickerView:pickerView titleForRow:row forComponent:component] intValue];
    switch (self.type) {
        case XYDatePickerType_HHmm:
        case XYDatePickerType_hhmm:{
            if (component == 0) {
                _dateStruct.hour = value;
            }else{
                _dateStruct.min = value;
            }
            _headerView.titleLabel.text = [NSString stringWithFormat:@"%02d:%02d",_dateStruct.hour,_dateStruct.min];
        }
            break;
        case XYDatePickerType_MMDD:{
            if (component == 0) {
                _dateStruct.month = value;
                int maxDay = (int)[self pickerView:pickerView numberOfRowsInComponent:1];
                if (_dateStruct.day > maxDay) {
                    _dateStruct.day = maxDay;
                }
            }else{
                _dateStruct.day = value;
            }
            _headerView.titleLabel.text = [NSString stringWithFormat:@"%02d-%02d",_dateStruct.month,_dateStruct.day];
        }
            break;
        case XYDatePickerType_YYYYMMDD:{
            switch (component) {
                case 0:{
                    _dateStruct.year = value;
                    int maxMonth = (int)[self pickerView:pickerView numberOfRowsInComponent:1];
                    if (_dateStruct.month > maxMonth) {
                        _dateStruct.month = maxMonth;
                    }
                    
                    int maxDay = (int)[self pickerView:pickerView numberOfRowsInComponent:2];
                    if (_dateStruct.day > maxDay) {
                        _dateStruct.day = maxDay;
                    }
                }
                    break;
                case 1:{
                    _dateStruct.month = value;
                    int maxDay = (int)[self pickerView:pickerView numberOfRowsInComponent:2];
                    if (_dateStruct.day > maxDay) {
                        _dateStruct.day = maxDay;
                    }
                }
                    break;
                case 2:{
                    _dateStruct.day = value;
                }
                    break;
            }
            _headerView.titleLabel.text = [NSString stringWithFormat:@"%d-%02d-%02d",_dateStruct.year,_dateStruct.month,_dateStruct.day];
        }
            break;
        case XYDatePickerType_hhmmss:
        case XYDatePickerType_HHmmss:{
            switch (component) {
                case 0:{
                    _dateStruct.hour = value;
                }
                    break;
                case 1:{
                    _dateStruct.min = value;
                }
                    break;
                case 2:{
                    _dateStruct.second = value;
                }
                    break;
            }
            _headerView.titleLabel.text = [NSString stringWithFormat:@"%02d:%02d:%02d",_dateStruct.hour,_dateStruct.min,_dateStruct.second];
        }
            break;
        default:
            break;
    }
}
- (NSInteger)getYearCount{
    NSInteger minYear = [self.calendar component:NSCalendarUnitYear fromDate:_minDate];
    NSInteger maxYear = [self.calendar component:NSCalendarUnitYear fromDate:_maxDate];
    NSInteger count = 0;
    if (maxYear > minYear) {
        count = maxYear - minYear + 1;
    }
    return count;
}

- (NSInteger)getMonthCount:(NSInteger)year{
    NSInteger minYear = [self.calendar component:NSCalendarUnitYear fromDate:_minDate];
    NSInteger maxYear = [self.calendar component:NSCalendarUnitYear fromDate:_maxDate];
    NSInteger minMonth = [self.calendar component:NSCalendarUnitMonth fromDate:_minDate];
    NSInteger maxMonth = [self.calendar component:NSCalendarUnitMonth fromDate:_maxDate];
    NSInteger count = 12;
    if (year+minYear == minYear) {//最后一年
        count -= (minMonth-1);
    }else if (year+minYear == maxYear) {//第一年
        count = maxMonth;
    }
    return count;
}

- (NSInteger)getDayCount:(NSInteger)year month:(NSInteger)month{
    NSInteger minYear = [self.calendar component:NSCalendarUnitYear fromDate:_minDate];
    NSInteger maxYear = [self.calendar component:NSCalendarUnitYear fromDate:_maxDate];
    NSInteger minMonth = [self.calendar component:NSCalendarUnitMonth fromDate:_minDate];
    NSInteger maxMonth = [self.calendar component:NSCalendarUnitMonth fromDate:_maxDate];
    NSInteger minDay = [self.calendar component:NSCalendarUnitDay fromDate:_minDate];
    NSInteger maxDay = [self.calendar component:NSCalendarUnitDay fromDate:_maxDate];
    NSInteger day = monthDayCount((int)(year+minYear), (int)month+1);
    if (year+minYear == maxYear && month+1 == maxMonth) {
        day = maxDay;
    }else if (year+minYear == minYear && month+1 == minMonth) {
        day -= minDay;
    }
    return day;
}

- (NSInteger)getHourCount{
    switch (self.type) {
        case XYDatePickerType_hhmm:
        case XYDatePickerType_hhmmss:
            return 12;
            break;
        case XYDatePickerType_HHmmss:
        case XYDatePickerType_HHmm:
            return 24;
            break;
        case XYDatePickerType_MMDD:
        case XYDatePickerType_YYYYMMDD:
            return 0;
        default:
            break;
    }
    return 0;
}

- (NSInteger)getMinCount{
    return 60;
}

- (NSInteger)getSecondCount{
    return 60;
}

- (NSString *)getYearTitle:(NSInteger)row{
    NSInteger minYear = [self.calendar component:NSCalendarUnitYear fromDate:_minDate];
    return [NSString stringWithFormat:@"%li", minYear+row];
}

- (NSString *)getMonthTitle:(NSInteger)yearRow row:(NSInteger)row{
    if (yearRow == 0) {
        NSInteger minMonth = [self.calendar component:NSCalendarUnitMonth fromDate:_minDate];
        return [NSString stringWithFormat:@"%02li", row+minMonth];
    }
    return [NSString stringWithFormat:@"%02li", row+1];
}

- (NSString *)getDayTitle:(NSInteger)yearRow monthRow:(NSInteger)monthRow dayRow:(NSInteger)dayRow{
    if (yearRow == 0 && monthRow == 0 ) {
        NSInteger minDay = [self.calendar component:NSCalendarUnitDay fromDate:_minDate];
        return [NSString stringWithFormat:@"%02li", minDay + dayRow];
    }
    return [self getOtheTitle:dayRow+1];
}

- (NSString *)getOtheTitle:(NSInteger)row{
    return [NSString stringWithFormat:@"%02li",row];
}

#pragma mark - 其他方法

#pragma mark - 属性方法 -
- (NSCalendar *)calendar{
    if (!_calendar) {
        _calendar = [NSCalendar currentCalendar];
    }
    return _calendar;
}
- (XYPickerHeaderView *)headerView{
    if (_headerView == nil) {
        _headerView = [XYPickerHeaderView new];
        _headerView.backgroundColor = [UIColor whiteColor];
        _headerView.delegate = self;
    }
    return _headerView;
}

- (UIPickerView *)pickerView{
    if (_pickerView == nil) {
        _pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, kXYPickerHeaderViewHeight, self.view.frame.size.width, kPickerViewHeight)];
        _pickerView.delegate = self;
        _pickerView.dataSource = self;
        _pickerView.backgroundColor = [UIColor colorWithRed:0.97 green:0.97 blue:0.97 alpha:1.00];
    }
    return _pickerView;
}

@end
