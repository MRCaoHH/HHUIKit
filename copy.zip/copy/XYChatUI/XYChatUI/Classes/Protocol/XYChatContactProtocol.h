//
//  XYChatContactProtocol.h
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import <Foundation/Foundation.h>
@class XYChatContactModel;
@class XYChatContactVC;
@protocol XYChatContactProtocol <NSObject>
@required
/**
 联系人数组
 */
@property (nonatomic,strong)  NSArray *contactArray;
@property (nonatomic,weak) XYChatContactVC *contactVC;
@optional
/**
 准备选中联系人

 @param contact 联系人模型
 */
- (void)didSelectWithContact:(XYChatContactModel *)contact;

/**
 下拉刷新

 @param complete 完成回调
 */
- (void)downPullReloadData:(void(^)(BOOL succ))complete;
@end
