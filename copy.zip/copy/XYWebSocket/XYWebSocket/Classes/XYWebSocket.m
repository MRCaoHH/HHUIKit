//
//  XYWebSocket.m
//  XYWebSocket
//
//  Created by henry on 2017/11/28.
//

#import "XYWebSocket.h"
#import "SocketRocket.h"
#import <XYExtension/XYExtension.h>
#import "XYWebSocketProtocol.h"

@interface XYWebSocket()<SRWebSocketDelegate>{
    SRWebSocket *_socket;
    NSDate *_date;
}
@property (nonatomic,strong) XYWebSocketProtocol *protocol;
@property (nonatomic,strong) NSTimer *timer;
/**
 代理协议
 */
@property (nonatomic,strong) NSMutableArray *delegateArr;
@end

@implementation XYWebSocket
//static XYWebSocket *instanceSocket = nil;
//
//+(instancetype)shareInstance{
//    static dispatch_once_t onceToken;
//    dispatch_once(&onceToken, ^{
//        instanceSocket = [XYWebSocket new];
//    });
//    return instanceSocket;
//}

- (void)dealloc{
    [_timer invalidate];
}

- (instancetype)init{
    self = [super init];
    if (self) {
        __weak typeof(self) weakSlef = self;
        self.timer = [NSTimer scheduledTimerWithTimeInterval:5 target:weakSlef selector:@selector(checkConnectState) userInfo:nil repeats:YES];
    }
    return self;
}

- (void)checkConnectState{
    NSDate *date = [NSDate date];
    if (date.timeIntervalSinceNow - _date.timeIntervalSinceNow > 30) {
        for (id<XYWebSocketDelegate> delegate in self.delegateArr) {
            if ([delegate respondsToSelector:@selector(webSocketDidDisconnect:)]) {
                [delegate webSocketDidDisconnect:self];
            }
        }
    }
    [self sendMsg:@"\0"];
}

#pragma mark - 操作 -
- (void)addDelegate:(id<XYWebSocketDelegate>)delegate{
    if (delegate) {
        if ([self.delegateArr containsObject:delegate]) {
            return;
        }
        [self.delegateArr addObject:delegate];
    }
}

- (void)removeDelegate:(id<XYWebSocketDelegate>)delegate{
    if (delegate) {
        if ([self.delegateArr containsObject:delegate]) {
             [self.delegateArr removeObject:delegate];
        }
    }
}

- (void)connect{
    [_socket open];
}

- (void)disconnect{
    if (self.state == XYWebSocketState_Connect || self.state == XYWebSocketState_Connecting) {
        [_socket close];
    }
}

- (void)disconnect:(void (^)(void))complete{
    
}

- (void)sendMsg:(id)msg{
    if (self.state != XYWebSocketState_Connect) {
        return;
    }
    
    NSString *messageText = msg;
    if (![msg isKindOfClass:[NSString class]]&& ![msg isKindOfClass:[NSData class]]) {
        messageText = [msg xy_JSONString];
    }
    [_socket send:messageText];
}
#pragma mark - SRWebSocketDelegate

- (void)webSocket:(SRWebSocket *)webSocket didReceiveMessage:(id)message{
    _date = [NSDate date];
    if([message isEqualToString:@"\0"]){
        return;
    }
    
    NSLog(@"接收消息:%@",message);
    id msg = [self.protocol convertReceiveMessage:message];
    for (id<XYWebSocketDelegate> delegate in self.delegateArr) {
        if ([delegate respondsToSelector:@selector(webSocket:didReceiveMessage:)]) {
            [delegate webSocket:self didReceiveMessage:msg];
        }
    }
}

- (void)webSocketDidOpen:(SRWebSocket *)webSocket{
    NSLog(@"准备连接WebSocket");
    for (id<XYWebSocketDelegate> delegate in self.delegateArr) {
        if ([delegate respondsToSelector:@selector(webSocketDidConnect:)]) {
            [delegate webSocketDidConnect:self];
        }
    }
}

- (void)webSocket:(SRWebSocket *)webSocket didFailWithError:(NSError *)error{
    NSLog(@"%@",error);
    for (id<XYWebSocketDelegate> delegate in self.delegateArr) {
        if ([delegate respondsToSelector:@selector(webSocket:connectFail:)]) {
            [delegate webSocket:self connectFail:error];
        }
    }
}

- (void)webSocket:(SRWebSocket *)webSocket didCloseWithCode:(NSInteger)code reason:(NSString *)reason wasClean:(BOOL)wasClean{
    for (id<XYWebSocketDelegate> delegate in self.delegateArr) {
        if ([delegate respondsToSelector:@selector(webSocketDidDisconnect:)]) {
            [delegate webSocketDidDisconnect:self];
        }
    }
}

- (void)webSocket:(SRWebSocket *)webSocket didReceivePong:(NSData *)pongPayload{
    NSLog(@"接收ping");
}

#pragma mark - 属性方法 -
- (void)setUrl:(NSString *)url{
    if (_socket) {
        _socket.delegate = nil;
        [self disconnect];
    }
    _socket = [[SRWebSocket alloc]initWithURL:[NSURL URLWithString:url]];
    _socket.delegate = self;
}

- (XYWebSocketProtocol *)protocol{
    if (_protocol == nil) {
        _protocol = [[XYWebSocketProtocol regisclass]new];
    }
    return _protocol;
}

- (XYWebSocketState)state{
    if (_socket == nil) {
        return  -1;
    }
    return (NSInteger)_socket.readyState;
}

- (NSMutableArray *)delegateArr{
    if (_delegateArr == nil) {
        _delegateArr = @[].mutableCopy;
    }
    return _delegateArr;
}
@end
