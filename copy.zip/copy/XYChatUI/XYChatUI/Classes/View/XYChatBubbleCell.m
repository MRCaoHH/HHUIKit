//
//  XYChatBubbleCell.m
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import "XYChatBubbleCell.h"
#import <XYCategory/XYCategory.h>
#import "XYChatSourceProtocol.h"
#import "XYChatMsgBaseModel.h"

@interface XYChatBubbleCell ()

@end

@implementation XYChatBubbleCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSubview];
    }
    return self;
}

#pragma mark - 初始化 -
- (void)initSubview{
    _isSend = NO;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    self.contentView.backgroundColor = [UIColor xy_colorWithHexString:@"#EBEBEB"];
    _bubbleImgView = [UIImageView new];
    UIImage *image = [XYChatSourceProtocol imageWithName:kChatReceviveImageName];
    image =  [image stretchableImageWithLeftCapWidth:kChatBubbleLeftEdge topCapHeight:kChatBubbleTopEdge];
    _bubbleImgView.image = image;
    [self.contentView addSubview:_bubbleImgView];
    
    _resendButton = [UIButton new];
    _resendButton.hidden = YES;
    [_resendButton setImage:[XYChatSourceProtocol imageWithName:@"chat_resend"] forState:UIControlStateNormal];
    [_resendButton sizeToFit];
    [_resendButton addTarget:self action:@selector(clickResendEvent:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:_resendButton];
    
    _loadingView = [[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    _loadingView.hidden = YES;;
    [self addSubview:_loadingView];
    
}

- (void)clickResendEvent:(UIButton *)button{
    //重新发送事件
    if (self.resendEvent) {
        self.resendEvent(self.model);
    }
}

+ (CGRect)calBubbleFrameWithContentSize:(CGSize)size isSend:(BOOL)isSend{
    // ___________________________________________________________________________
    // |                                  |                                      |
    // |                             kChatBubbleEdgeOffset                           |
    // |                      ____________|____________                          |
    // |                      |                        |                         |
    // |                      |                        |                         |
    // |kChatBubbleEdgeOffset<                         |--  kChatLeaveBlankWidth   --| 最外层表示cell
    // |                      |         气泡            |                         |
    // |                      |                        |                         |
    // |                      |                        |                         |
    // |                      |________________________|                         |
    // |                                  |                                      |
    // |                          kChatBubbleEdgeOffset                              |
    // |__________________________________|______________________________________|
    //
    // ___________________________________________________________________________
    // |                                  |                                      |
    // |                           kChatBubbleEdgeOffset                             |
    // |                      ____________|____________                          |
    // |                      |                        |                         |
    // |                      |                        |                         |
    // |--  屏宽   减去      -- |                        | >-- kChatBubbleEdgeOffset --| 最外层表示cell
    // |kChatBubbleEdgeOffset |         气泡            |                         |
    // |    减去 bubbleWidth   |                        |                         |
    // |                      |                        |                         |
    // |                      |________________________|                         |
    // |                                  |                                      |
    // |                          kChatBubbleEdgeOffset                          |
    // |__________________________________|______________________________________|
    
    CGFloat bubbleWidth =  size.width + kChatContentArrowEdge + kChatContentOtheEdge;
    CGFloat bubbleHeight = size.height + kChatContentOtheEdge + kChatContentOtheEdge;
    CGFloat bubbleY = kChatBubbleEdgeOffset;
    CGFloat bubbleX = kChatBubbleEdgeOffset;
    
    if (isSend) {
        bubbleX = [UIScreen mainScreen].bounds.size.width - bubbleWidth - kChatBubbleEdgeOffset;
    }
    CGRect bubbleFrame = CGRectMake(bubbleX, bubbleY, bubbleWidth , bubbleHeight);
    return bubbleFrame;
}

+ (CGFloat)calCellHeightWithBubbleFrame:(CGRect)bubbleFrame{
    CGFloat cellHeight = CGRectGetMaxY(bubbleFrame) + kChatBubbleEdgeOffset;
    return cellHeight;
}

- (void)setIsSend:(BOOL)isSend{
    NSString *imgName = isSend ? kChatSendImageName : kChatReceviveImageName;
    UIImage *image = [XYChatSourceProtocol imageWithName:imgName];
    image =  [image stretchableImageWithLeftCapWidth:kChatBubbleLeftEdge topCapHeight:kChatBubbleTopEdge];
    if(isSend){
        image =  [image stretchableImageWithLeftCapWidth:kChatBubbleLeftEdge topCapHeight:kChatBubbleTopEdge];
    }else{
        image =  [image stretchableImageWithLeftCapWidth:kChatBubbleReceiveLeftEdge topCapHeight:kChatBubbleTopEdge];
    }
    self.bubbleImgView.image = image;
    _isSend = isSend;
}

#pragma mark - 属性方法 -
- (void)setModel:(XYChatMsgBaseModel *)model{
    _model = model;
    self.bubbleImgView.frame = model.bubbleFrame;
    self.resendButton.xy_x = model.isSend ? model.bubbleFrame.origin.x - self.resendButton.xy_width - 10: CGRectGetMaxX(model.bubbleFrame) + 10;
    self.resendButton.xy_centerY = self.bubbleImgView.xy_centerY;
    
    self.loadingView.xy_x = model.isSend ? model.bubbleFrame.origin.x - self.loadingView.xy_width - 10: CGRectGetMaxX(model.bubbleFrame) + 10;
    self.loadingView.xy_centerY = self.bubbleImgView.xy_centerY;
    
    self.resendButton.hidden = model.state != XYChatMsgSendState_Fail;
    self.loadingView.hidden = model.state != XYChatMsgSendState_Sending;
    model.state != XYChatMsgSendState_Sending ? [self.loadingView stopAnimating]: [self.loadingView startAnimating];
    self.isSend = model.isSend;
    
    [model setStateObserver:^(NSInteger state) {
        self.resendButton.hidden = model.state != XYChatMsgSendState_Fail;
        self.loadingView.hidden = model.state != XYChatMsgSendState_Sending;
        model.state != XYChatMsgSendState_Sending ? [self.loadingView stopAnimating]: [self.loadingView startAnimating];
    }];
}
@end
