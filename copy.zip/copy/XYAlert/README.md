# XYAlert

## 版本变更信息

|版本|文档修改时间|修改人|
|---|---|---|
|1.0.0|2018-1-31|Henry|


## Example 使用方法

终端进入`XYAlert/Example`目录运行命令：

```ruby
pod install
```

用xcode 打开 XYAlert.xcworkspace 就可以直接运行Example


## 

## 导入pod

```ruby
pod 'XYAlert'
```

## 用法

导入头文件

```Objc
    #import <XYAlert/XYAlert.h>
```

1、 文本输入框

```Objc
    XYTextFieldAlertController *vc = [[XYTextFieldAlertController alloc]initWithTitle:@"标题" cancelTitle:@"取消" okTitle:@"确定"];
    [vc setClickOkButtonCallback:^(XYAlertController *alertVC) {
        XYTextFieldAlertController *textFieldVC = (XYTextFieldAlertController *)alertVC;
        NSLog(@"%@",textFieldVC.textField.text);
    }];
    
    [self presentViewController:vc animated:YES completion:nil];
```

效果如下：

![文本输入框](Screenshot/1.png)

2、标题

```Objc
    XYAlertController *vc = [[XYAlertController alloc]initWithTitle:@"标题" cancelTitle:@"取消" okTitle:@"确定"];
    [vc setClickOkButtonCallback:^(XYAlertController *alertVC) {
        //确定按钮事件处理
    }];
    [self presentViewController:vc animated:YES completion:nil];
```

效果如下：

![标题](Screenshot/2.png)

3、 标题副标题

```Objc
    XYTextAlertController *vc = [[XYTextAlertController alloc]initWithTitle:@"和乐天春词" message:@"新妆宜面下朱楼\n深锁春光一院愁\n行到中庭数花朵\n蜻蜓飞上玉搔头" cancelTitle:@"取消" okTitle:@"确定"];
    [vc setClickOkButtonCallback:^(XYAlertController *alertVC) {
        //确定按钮事件处理
    }];
    [self presentViewController:vc animated:YES completion:nil];
```

效果如下：

![标题副标题](Screenshot/3.png)



