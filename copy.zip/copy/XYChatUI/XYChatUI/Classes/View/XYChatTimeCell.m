//
//  XYChatTimeCell.m
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import "XYChatTimeCell.h"
#import <XYCategory/XYCategory.h>

@implementation XYChatTimeCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initSubview];
    }
    return self;
}

- (void)initSubview{
    self.contentView.backgroundColor = [UIColor xy_colorWithHexString:@"#EBEBEB"];
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    _timeLabel = [UILabel new];
    _timeLabel.font = [UIFont systemFontOfSize:14];
    _timeLabel.backgroundColor = [UIColor xy_colorWithHexString:@"#CECECE"];
    _timeLabel.textColor = [UIColor xy_colorWithHexString:@"#FFFFFF"];
    _timeLabel.textAlignment = NSTextAlignmentCenter;
    _timeLabel.layer.cornerRadius = 2;
    _timeLabel.layer.masksToBounds = YES;
    [self addSubview:_timeLabel];
    _timeLabel.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, self.xy_height/2);
}

- (void)setTime:(NSString *)time{
    _timeLabel.text = time;
    [_timeLabel sizeToFit];
    _timeLabel.xy_height +=5;
    _timeLabel.xy_width +=10;
    _timeLabel.center = CGPointMake([UIScreen mainScreen].bounds.size.width/2, self.xy_height/2);
}
@end
