//
//  XYMacro_Func.h
//  Pods
//
//  Created by henry on 2017/10/27.
//

#ifndef XYMacro_Func_h
#define XYMacro_Func_h

///调用主线程同步
#define XY_Dispatch_main_sync_safe(block)\
if ([NSThread isMainThread]) {\
block();\
} else {\
dispatch_sync(dispatch_get_main_queue(), block);\
}

///调用主线程异步
#define XY_Dispatch_main_async_safe(block)\
if ([NSThread isMainThread]) {\
block();\
} else {\
dispatch_async(dispatch_get_main_queue(), block);\
}

//弱引用
#define XYWeakSelf __weak typeof(self) weakSelf = self

//字体
#define XYFont(size) [UIFont systemFontOfSize:size]
//颜色
#define XYCCOLOR_HEX(hexString) [UIColor colorWithRed:((float)((hexString & 0xFF0000) >> 16))/255.0 green:((float)((hexString & 0xFF00) >> 8))/255.0 blue:((float)(hexString & 0xFF))/255.0 alpha:1.0]


//系统版本判断宏
#define XYOSVersionLater(version) @available(iOS version, *)


/// NSLog
#ifndef __OPTIMIZE__
#define NSLog(fmt,...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#define NSLog(...) {}
#endif

//打印时间戳
#define XYTime NSLog(@"%f",[NSDate date].timeIntervalSince1970)

#endif /* XYMacro_Func_h */
