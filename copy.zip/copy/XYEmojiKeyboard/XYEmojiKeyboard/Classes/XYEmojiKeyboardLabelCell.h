//
//  XYEmojiKeyboardLabelCell.h
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/16.
//

#import <UIKit/UIKit.h>

@interface XYEmojiKeyboardLabelCell : UICollectionViewCell
@property (nonatomic,strong) UILabel *emojiLabel;
- (void)initSubview;
@end

@interface XYEmojiCategoryCell : XYEmojiKeyboardLabelCell
///分割线
@property (nonatomic,strong) UIView *sepLine;
@end
