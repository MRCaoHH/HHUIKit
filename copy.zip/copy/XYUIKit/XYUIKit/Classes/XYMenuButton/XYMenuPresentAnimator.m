//
//  XYMenuPresentAnimator.m
//  XYMenuButton
//
//  Created by henry on 2017/10/20.
//

#import "XYMenuPresentAnimator.h"
#import "XYMBViewController.h"
#import "XYMenuButton.h"

@implementation XYMenuPresentAnimator
- (CGFloat)timeInterval{
    if (_timeInterval == 0) {
        _timeInterval = 0.2;
    }
    return _timeInterval;
}

- (NSTimeInterval)transitionDuration:(nullable id <UIViewControllerContextTransitioning>)transitionContext{
    return 0.2;
}

- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext{
    UIView *fromView = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey].view;
    fromView.tintAdjustmentMode = UIViewTintAdjustmentModeDimmed;
    //    fromView.userInteractionEnabled = NO;
    
    UIView *dimmingView = [[UIView alloc] initWithFrame:fromView.bounds];
    dimmingView.backgroundColor = [UIColor clearColor];
    [transitionContext.containerView addSubview:dimmingView];
    
    XYMBViewController *toVC = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *toView = toVC.view;
    toView.frame = transitionContext.containerView.bounds;
    [transitionContext.containerView addSubview:toView];
    
    CABasicAnimation *opacityAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    opacityAnimation.fromValue = @0;
    opacityAnimation.toValue = @1;
    opacityAnimation.byValue = @1;
    opacityAnimation.fillMode=kCAFillModeForwards;
    opacityAnimation.removedOnCompletion = NO;
    [toVC.bgView.layer addAnimation:opacityAnimation forKey:@"opacityAnimation"];
    [toVC showAnimated];
    
    if ([toVC.menuButton.delegate respondsToSelector:@selector(menuButtonDidShow:)]) {
        [toVC.menuButton.delegate menuButtonDidShow:toVC.menuButton];
    }
    
    [self performSelector:@selector(completeAnimation:) withObject:transitionContext afterDelay:self.timeInterval];
}

- (void)completeAnimation:(nullable id <UIViewControllerContextTransitioning>)transitionContext{
    [transitionContext completeTransition:YES];
}
@end
