//
//  XYBTTextCell.h
//  Pods-XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//

#import <UIKit/UIKit.h>

@interface XYBTTextCell : UITableViewCell

/**
 标题标签
 */
@property (nonatomic,strong) UILabel *titleLabel;

/**
 备注标签
 */
@property (nonatomic,strong) UILabel *noteLabel;

/**
 备注默认文本
 */
@property (nonatomic,copy) NSString *noteDefaultText;

/**
 标题
 */
@property (nonatomic,copy) NSString *title;

/**
 边缘距离
 */
@property (nonatomic,assign) CGFloat edgeDistance;

/**
 字体大小
 */
@property (nonatomic,assign) CGFloat fontSize;

/**
 标题颜色
 */
@property (nonatomic,copy)  NSString *titleColor;

/**
 备注颜色
 */
@property (nonatomic,copy)  NSString *noteTitleColor;
@end
