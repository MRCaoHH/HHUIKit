//
//  XYChatDataManager.h
//  MJExtension
//
//  Created by henry on 2018/9/29.
//

#import <Foundation/Foundation.h>
@class XYChatContactModel;
@class XYChatMsgTextModel;

@interface XYChatDataManager : NSObject

@property (nonatomic,strong,readonly,class) XYChatDataManager *shareInstance;
@property (nonatomic,copy) NSString *mid;


/**
 根据用户胡连接数据库

 @param mid 用户id
 */
- (void)connectWithMid:(NSString *)mid;

/**
 断开连接
 */
- (void)disconnect;

/**
 联系人列表
 */
- (NSArray *)queryContactList;

/**
 更新联系人列表

 @param contactList 联系人列表
 */
- (void)updateContactList:(NSArray *)contactList;

/**
 更新联系人

 @param contact 联系人
 */
- (void)updateContact:(XYChatContactModel *)contact;

/**
 根据消息id得到消息模型

 @param messageId 消息id
 @return 消息模型
 */
- (XYChatMsgTextModel *)msgModelWithMessageId:(NSString *)messageId;

/**
 插入数据

 @param msgModel 数据模型
 */
- (void)insertMsg:(XYChatMsgTextModel *)msgModel;

@end
