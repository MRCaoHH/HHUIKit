//
//  XYViewController.m
//  XYRefresh
//
//  Created by henry on 11/06/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

#import "XYViewController.h"
#import <XYRefresh/XYRefresh.h>

@interface XYViewController ()

@end

@implementation XYViewController

- (void)viewDidLoad{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    [XYRefresh  addHeaderRefresh:self.tableView target:self action:@selector(downPullRefresh)];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)downPullRefresh{
    [self performSelector:@selector(endRefresh) withObject:nil afterDelay:3];
}

- (void)endRefresh{
    [XYRefresh endHeaderRefresh:self.tableView];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 0;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [UITableViewCell new];
}
@end
