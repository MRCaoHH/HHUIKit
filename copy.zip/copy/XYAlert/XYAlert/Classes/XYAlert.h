#ifndef XYAlert_h
#define XYAlert_h
#import <XYAlert/XYAlertController.h>
#import <XYAlert/XYTextAlertController.h>
#import <XYAlert/XYTextFieldAlertController.h>
#endif /* XYAlert_h */
