//
//  XYMenuButton.h
//  XYMenuButton
//
//  Created by henry on 2017/10/20.
//

#import <UIKit/UIKit.h>

@protocol XYMenuButtonDelegate;

@interface XYMenuButton : UIButton
@property (nonatomic,weak,readonly) UIView *orgSuperView;
@property (nonatomic,assign,readonly) CGRect orgFrame;
@property (nonatomic,strong) NSArray *items;;
@property (nonatomic,weak) UIViewController *orgViewController;
@property (nonatomic,weak) id<XYMenuButtonDelegate> delegate;
@property (nonatomic,assign) CGFloat itemSpacing;
/**
 記錄，位置和所在視圖
 */
- (void)record;

/**
 清除记录
 */
- (void)clearRecord;

@end

@protocol XYMenuButtonDelegate <NSObject>
@optional
- (void)menuButton:(XYMenuButton *)menuButton clickIndex:(NSInteger)index;
- (void)menuButtonDidShow:(XYMenuButton *)menuButton;
- (void)menuButtonDidHide:(XYMenuButton *)menuButton;
@end
