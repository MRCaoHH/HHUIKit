//
//  XYViewController.h
//  XYMenuViewController
//
//  Created by henry on 11/03/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

#import <XYMenuViewController/XYMenuViewController.h>

@interface XYViewController : XYMenuViewController

@end
