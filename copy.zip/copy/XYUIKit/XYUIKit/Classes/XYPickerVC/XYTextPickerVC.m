//
//  XYTextPickerVC.m
//  Masonry
//
//  Created by henry on 2018/11/20.
//

#import "XYTextPickerVC.h"
#import <XYNavigationController/XYPickerDismiss.h>
#import <XYNavigationController/XYPickerPresent.h>
#import "XYPickerHeaderView.h"

@interface XYTextPickerVC ()<UIViewControllerTransitioningDelegate,UIPickerViewDataSource,UIPickerViewDelegate,XYPickerHeaderViewDelegate>
@property (nonatomic,strong) XYPickerHeaderView *headerView;
@property (nonatomic,strong) UIPickerView *pickerView;
@end

@implementation XYTextPickerVC
static CGFloat kPickerViewHeight = 200;

- (instancetype)initWithDelegate:(id<XYTextPickerVCDelegate>)delegate{
    self = [super init];
    if (self) {
        self.delegate = delegate;
        self.modalPresentationStyle = UIModalPresentationCustom;
        self.transitioningDelegate = self;
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initSubview];
    NSArray *titles = [self getTitles];
    self.headerView.titleLabel.text = [titles componentsJoinedByString:@","];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

- (void)setSelectIndexPath:(NSIndexPath *)indexPath{
    [self.pickerView selectRow:indexPath.row inComponent:indexPath.section animated:NO];
    NSArray *titles = [self getTitles];
    self.headerView.titleLabel.text = [titles componentsJoinedByString:@","];
}

#pragma mark - 初始化 -
- (void)initSubview{
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.headerView];
    [self.view addSubview:self.pickerView];
}

#pragma mark - 协议 -
#pragma mark - UIViewControllerTransitioningDelegate
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return ({
        XYPickerPresent *present = [XYPickerPresent new];
        present.viewSize = CGSizeMake([UIScreen mainScreen].bounds.size.width, kXYPickerHeaderViewHeight+kPickerViewHeight);
        present;
    });
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return ({
        XYPickerDismiss *dismiss = [XYPickerDismiss new];
        dismiss;
    });
}

#pragma mark - XYPickerHeaderViewDelegate
- (void)clickOkButtonEvent{
    NSArray *titles = [self getTitles];
    if (![self.delegate textPickerVC:self canCommitWithTitles:titles]) {
        return;
    }
    
    if ([self.delegate respondsToSelector:@selector(textPickerVC:clickOkWithTitles:)]) {
        
        [self.delegate textPickerVC:self clickOkWithTitles:titles];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)clickCancelButtonEvent{
    if ([self.delegate respondsToSelector:@selector(clickCancelTextPickerVC:)]) {
        [self.delegate clickCancelTextPickerVC:self];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return [self.delegate numberOfComponentTextPickerVC:self];
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [self.delegate textPickerVC:self numberOfRowsInComponent:component];
}

#pragma mark - UIPickerViewDelegate
- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component{
    return [UIScreen mainScreen].bounds.size.width/[self.delegate numberOfComponentTextPickerVC:self];
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 44;
}

- (nullable NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    return [self.delegate textPickerVC:self titleWithIndex:[NSIndexPath indexPathForRow:row inSection:component]];
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if ([self.delegate respondsToSelector:@selector(textPickerVC:didSelectRow:inComponent:)]) {
        [self.delegate textPickerVC:self didSelectRow:row inComponent:component];
        [pickerView reloadAllComponents];
    }
    NSArray *titles = [self getTitles];
    self.headerView.titleLabel.text = [titles componentsJoinedByString:@","];
}

- (NSArray *)getTitles{
    NSInteger component =  [self.delegate numberOfComponentTextPickerVC:self];
    NSMutableArray *titles = [NSMutableArray new];
    for (int i = 0; i<component; i++) {
        NSInteger row = [self.pickerView selectedRowInComponent:i];
        NSString *title = [self.delegate textPickerVC:self titleWithIndex:[NSIndexPath indexPathForRow:row inSection:component]];
        if (title) {
            [titles addObject:title];
        }
    }
    return titles;
}
#pragma mark - 其他方法
#pragma mark - 属性方法 -
- (XYPickerHeaderView *)headerView{
    if (_headerView == nil) {
        _headerView = [XYPickerHeaderView new];
        _headerView.backgroundColor = [UIColor whiteColor];
        _headerView.delegate = self;
    }
    return _headerView;
}

- (UIPickerView *)pickerView{
    if (_pickerView == nil) {
        _pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, kXYPickerHeaderViewHeight, self.view.frame.size.width, kPickerViewHeight)];
        _pickerView.delegate = self;
        _pickerView.dataSource = self;
        _pickerView.backgroundColor = [UIColor colorWithRed:0.97 green:0.97 blue:0.97 alpha:1.00];
    }
    return _pickerView;
}



@end
