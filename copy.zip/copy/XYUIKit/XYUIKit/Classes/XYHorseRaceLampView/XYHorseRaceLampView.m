//
//  XYHorseRaceLampView.m
//  Masonry
//
//  Created by henry on 2019/2/13.
//

#import "XYHorseRaceLampView.h"
#import <XYCategory/XYCategory.h>

@interface XYHorseRaceLampView()<CAAnimationDelegate>
@end

@implementation XYHorseRaceLampView{
    NSTimeInterval _timeStamp;
    NSInteger _curIndex;
}
static NSInteger kItemViewTag = 878;

- (instancetype)initWithFrame:(CGRect)frame withTitles:(NSArray *)titles{
    self = [super initWithFrame:frame];
    if (self) {
        self.titles = titles;
        self.clipsToBounds = YES;
        [self addGestureRecognizer];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame withTitles:(NSArray *)titles withTitleColor:(UIColor *)titleColor withTitleFont:(UIFont *)titleFont{
    self = [super initWithFrame:frame];
    if (self) {
        _titleColor = titleColor;
        _titleFont = titleFont;
        self.titles = titles;
        self.clipsToBounds = YES;
        [self addGestureRecognizer];
    }
    return self;
}

- (void)addGestureRecognizer{
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapEvent)];
    [self addGestureRecognizer:tap];
}

- (void)tapEvent{
    if ([self.delegate respondsToSelector:@selector(tapHorseRaceLampView:title:index:)]) {
        [self.delegate tapHorseRaceLampView:self title:self.titles[_curIndex] index:_curIndex];
    }
}

- (void)playItemView:(UIView *)itemView{
    
    itemView.tag = kItemViewTag;
    [self addSubview:itemView];
//    itemView.xy_x = (self.xy_width - itemView.xy_width)/2;
//    if(itemView.xy_width > self.xy_width){
//        itemView.xy_x = 0;
//    }
    itemView.xy_x = self.xy_width;
    itemView.xy_centerY = self.xy_height/2;
    
//    CGFloat positionX =  self.xy_width/2;
//    if(itemView.xy_width > self.xy_width){
//        positionX = self.xy_width - itemView.xy_width/2;
//    }
    CGFloat positionX =  - itemView.xy_width/2;
    CGFloat positionY = self.xy_height/2;

    CABasicAnimation *position = [CABasicAnimation animation];
    position.duration = 10;
    position.fillMode=kCAFillModeRemoved;
    position.removedOnCompletion = NO;
//    position.repeatCount = 999;
//    position.autoreverses = YES;
    position.keyPath = @"position";
    position.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    __weak typeof(self) weakSelf = self;
    position.delegate = weakSelf;
    position.toValue = [NSValue valueWithCGPoint:CGPointMake(positionX,positionY)];
    [itemView.layer addAnimation:position forKey:@"position"];

//    CAAnimationGroup *group = [CAAnimationGroup animation];
//    group.animations = @[position];
//    group.duration  = 5.4;
//    [itemView.layer addAnimation:group forKey:nil];
    
}

- (void)playNextItemView{
    _curIndex += 1;
    if (self.titles.count == 0) {
        return;
    }
    
    if (_curIndex >= self.titles.count) {
        _curIndex = 0;
    }
    
    NSString *title = self.titles[_curIndex];
    UILabel *label = [[UILabel alloc]init];
    label.text = title;
    label.font = self.titleFont;
    label.textColor = self.titleColor;
    [label sizeToFit];
    [self playItemView:label];
}

- (void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag{
    if (flag) {
        UIView *view = [self viewWithTag:kItemViewTag];
        [view removeFromSuperview];
        [self playNextItemView];
    }
}


- (void)setTitles:(NSArray *)titles{
    _titles = titles;
    _curIndex = -1;
    [self playNextItemView];
}

- (UIColor *)titleColor{
    if (_titleColor == nil) {
        _titleColor = [UIColor blackColor];
    }
    return _titleColor;
}

- (UIFont *)titleFont{
    if (_titleFont == nil) {
        _titleFont = [UIFont systemFontOfSize:14];
    }
    return _titleFont;
}

@end
