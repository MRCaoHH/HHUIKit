//
//  XYChatFooterView.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import <UIKit/UIKit.h>
#import "XYChatFooterProtocol.h"

@interface XYChatFooterView : UIView<XYChatFooterProtocol>
/**
 输入框
 */
@property (nonatomic,strong) UITextView *textView;

/**
 emoji表情和键盘的切换按钮
 */
@property (nonatomic,strong) UIButton *emojiButton;

/**
 加号
 */
@property (nonatomic,strong) UIButton *plusButton;

@end
