//
//  XYAlertPresent.m
//  XYNavigationController
//
//  Created by caohuihui on 2017/12/07.
//  Copyright © 2017年 Xin YI. All rights reserved.
//

#import "XYAlertPresent.h"
#import <POP/POP.h>
@interface XYAlertPresent()
@property (nonatomic,weak) UIViewController *vc;
@end

@implementation XYAlertPresent
- (instancetype)init{
    self = [super init];
    if (self) {
        self.duration = 0.2;
        self.bgColor =  [[UIColor blackColor] colorWithAlphaComponent:0.2];
    }
    return self;
}

- (NSTimeInterval)transitionDuration:(id <UIViewControllerContextTransitioning>)transitionContext{
    return self.duration;
}

- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext{
    UIView *fromView = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey].view;
    fromView.tintAdjustmentMode = UIViewTintAdjustmentModeNormal;
    
    UIView *dimmingView = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    dimmingView.backgroundColor = self.bgColor;
    dimmingView.layer.opacity = 0.0;
    [self addTapDismissGuesture:dimmingView toViewController:[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey]];
    self.vc = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey];
    
    UIView *toView = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey].view;
    toView.frame = CGRectMake(0,
                              0,
                              self.viewSize.width,
                              self.viewSize.height);
    toView.center = CGPointMake(transitionContext.containerView.center.x, -transitionContext.containerView.center.y);
    
    [transitionContext.containerView addSubview:dimmingView];
    [transitionContext.containerView addSubview:toView];
    POPSpringAnimation *positionAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerPositionY];
    positionAnimation.toValue = @(transitionContext.containerView.center.y);
    positionAnimation.springBounciness = 10;
    [positionAnimation setCompletionBlock:^(POPAnimation *anim, BOOL finished) {
        [transitionContext completeTransition:YES];
    }];

    POPSpringAnimation *scaleAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerScaleXY];
    scaleAnimation.springBounciness = 20;
    scaleAnimation.fromValue = [NSValue valueWithCGPoint:CGPointMake(1.2, 1.4)];
    
    POPBasicAnimation *opacityAnimation = [POPBasicAnimation animationWithPropertyNamed:kPOPLayerOpacity];
    opacityAnimation.toValue = @(1.0);
    
    [toView.layer pop_addAnimation:positionAnimation forKey:@"positionAnimation"];
    [toView.layer pop_addAnimation:scaleAnimation forKey:@"scaleAnimation"];
    [dimmingView.layer pop_addAnimation:opacityAnimation forKey:@"opacityAnimation"];
}

- (void)addTapDismissGuesture:(UIView *)view toViewController:(UIViewController *)viewController{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wundeclared-selector"
    if ([viewController respondsToSelector:@selector(xy_dismissVC)]) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:viewController action:@selector(xy_dismissVC)];
        [view addGestureRecognizer:tap];
    }
#pragma clang diagnostic pop
}


@end
