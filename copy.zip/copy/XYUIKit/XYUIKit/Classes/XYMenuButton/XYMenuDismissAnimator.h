//
//  XYMenuDismissAnimator.h
//  XYMenuButton
//
//  Created by henry on 2017/10/20.
//

#import <Foundation/Foundation.h>

@interface XYMenuDismissAnimator : NSObject<UIViewControllerAnimatedTransitioning>
@property (nonatomic,assign) CGFloat timeInterval;
@end
