# XYNetworking


## 版本变更信息

|版本|文档修改时间|修改人|
|---|---|---|
|1.0.0|2018-1-31|Henry|

## Example 使用方法

终端进入`XYNetworking/Example`目录运行命令：

```ruby
pod install
```

用xcode 打开 XYNetworking.xcworkspace 就可以直接运行Example


## 用法

导入头文件

```objc
    #import <XYNetworking/XYNetworking.h>
```

修改请求host

继承XYHttpRequestProtocol重写host方法


```objc

+ (void)load{
    //必须要注册本身不然的话不会调用
    [self registerClass:[self class]];
}

//重写host方法修改请求的地址
+ (NSString *)host{
    return @"http://pods.xy.com:3000/api/v3/";
}

```

修改返回的数据类型

```objc
#pragma mark - 默认的返回数据类型
+ (NSInteger)defaultResponseType{
    return XYResponseType_Json;
}
```

添加公共输入参数，每个请求都会带上这里的参数，通常用来处理token之类的数据

```objc
+ (NSDictionary *)publicInputParams{
    return nil;
}


```

添加公共输出参数,处理一些公共数据，例如登录失效之类的。

```
+ (NSDictionary *)inputParamsHander:(NSDictionary *)param{
    return param;
}
```


配置http header 例如User-Agent、Content-Type，SessionId之类的

```objc
+ (NSDictionary <NSString *,NSString*>*)httpHeaderConfig{
    return nil;
}
```

GET请求


```objc
/**
 *  Get请求
 *
 *  @param url      请求地址
 *  @param params   参数
 *  @param progress 进度回调
 *  @param success  成功回调
 *  @param failure  失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)GET:(NSString  *)url params:(NSDictionary *)params progress:(void (^)(NSProgress * uploadProgress))progress success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;
```

POST请求

```objc
/**
 *  Post请求
 *
 *  @param url      请求地址
 *  @param params   参数
 *  @param success  成功回调
 *  @param failure  失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+(XYRequestModel *)POST:(NSString  *)url params:(NSDictionary *)params  success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;
```

上传POST请求

```
/**
 *  @brief POST请求上传
 *
 *  @param url         请求地址
 *  @param params      参数
 *  @param uploadParam 上传内容
 *  @param success     成功回调
 *  @param failure     失败回调
 *
 *  @return 返回XYRequestModel模型
 */
+ (XYRequestModel *)POST:(NSString  *)url params:(NSDictionary *)params uploadParam:(NSDictionary *)uploadParam    success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure;
```



