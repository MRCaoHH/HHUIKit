//
//  XYBTImageCell.h
//  Pods-XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//

#import <UIKit/UIKit.h>

@interface XYBTImageCell : UITableViewCell

/**
 图像视图
 */
@property (nonatomic,strong) UIImageView *imgView;

/**
 标题标签
 */
@property (nonatomic,strong) UILabel *titleLabel;

/**
 标题
 */
@property (nonatomic,copy) NSString *title;

/**
 图像
 */
@property (nonatomic,copy) NSString *imgUrl;

/**
 imgView高度
 */
@property (nonatomic,assign) CGFloat imgHeight;

/**
 imgView宽度
 */
@property (nonatomic,assign) CGFloat imgWidth;

/**
 边缘距离
 */
@property (nonatomic,assign) CGFloat edgeDistance;

/**
 标题字体颜色
 */
@property (nonatomic,copy) NSString *titleTextColor;

/**
 输入框字体大小
 */
@property (nonatomic,assign) CGFloat titleFontSize;
@end
