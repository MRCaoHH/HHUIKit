//
//  XYEmojiKeyboard.m
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/15.
//

#import "XYEmojiKeyboard.h"
#import "XYEmojiCollectionViewLayout.h"
#import "XYEmojiSourceProtocol.h"
#import "XYEmojiKeyboardLabelCell.h"
#import "XYEmojiKeyboardImgCell.h"

@interface XYEmojiKeyboard()<UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

/**
 emoji的CollectionView
 */
@property (nonatomic,strong) UICollectionView *emojiCollectionView;

/**
 分类的CollectionView
 */
@property (nonatomic,strong) UICollectionView *categoryCollectionView;

/**
 删除按钮
 */
@property (nonatomic,strong) UIButton *sendButton;


/**
 emoji字典
 */
@property (nonatomic,strong) NSArray *emojiCategoryList;

/**
 emoji列表
 */
@property (nonatomic,strong) NSArray *emojiList;

/**
 分割线
 */
@property (nonatomic,strong) UIView *sepLine;

/**
 选中分组
 */
@property (nonatomic,assign) NSInteger selectCategory;

@end

@implementation XYEmojiKeyboard
static NSString *kKeyboardCellReuseIdentifier = @"kCellReuseIdentifier";
static NSString *kKeyboardImgCellReuseIdentifier = @"kKeyboardImgCellReuseIdentifier";
static NSString *kCategoryCellReuseIdentifier = @"kCategoryCellReuseIdentifier";
static CGFloat kButtonWidth = 52;
static CGFloat kButtonHeight = 35;
static CGFloat kCategoryCellHeight = 35;
static CGFloat kCategoryCellWidth = 45;

- (instancetype)init{
    self = [super init];
    if (self) {
        [self initSubview];
        [self adjustLayout];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self initSubview];
        [self adjustLayout];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self initSubview];
        [self adjustLayout];
    }
    return self;
}

- (void)initSubview{
    _selectCategory = 0;
    
    XYEmojiCollectionViewLayout *emojiLayout = [XYEmojiCollectionViewLayout new];
    emojiLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    emojiLayout.sectionInset = UIEdgeInsetsZero;
    _emojiCollectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:emojiLayout];
    _emojiCollectionView.dataSource = self;
    _emojiCollectionView.delegate = self;
    _emojiCollectionView.pagingEnabled = YES;
    _emojiCollectionView.showsHorizontalScrollIndicator = NO;
    _emojiCollectionView.showsVerticalScrollIndicator = NO;
    [_emojiCollectionView registerClass:[XYEmojiKeyboardLabelCell class] forCellWithReuseIdentifier:kKeyboardCellReuseIdentifier];
    [_emojiCollectionView registerClass:[XYEmojiKeyboardImgCell class] forCellWithReuseIdentifier:kKeyboardImgCellReuseIdentifier];
    [self addSubview:_emojiCollectionView];
    
    UICollectionViewFlowLayout *categoryLayout = [UICollectionViewFlowLayout new];
    categoryLayout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    categoryLayout.sectionInset = UIEdgeInsetsZero;
    _categoryCollectionView = [[UICollectionView alloc]initWithFrame:CGRectZero collectionViewLayout:categoryLayout];
    _categoryCollectionView.dataSource = self;
    _categoryCollectionView.delegate  = self;
    _categoryCollectionView.showsHorizontalScrollIndicator = NO;
    _categoryCollectionView.showsVerticalScrollIndicator = NO;
    [_categoryCollectionView registerClass:[XYEmojiCategoryCell class] forCellWithReuseIdentifier:kCategoryCellReuseIdentifier];
    [self addSubview:_categoryCollectionView];
    
    _sendButton = [[UIButton alloc]init];
    [_sendButton setTitle:@"发送" forState:UIControlStateNormal];
    _sendButton.titleLabel.font = [UIFont boldSystemFontOfSize:15];
    [_sendButton setTitleColor:[UIColor colorWithRed:0.56 green:0.56 blue:0.56 alpha:1.00] forState:UIControlStateNormal];
    [_sendButton addTarget:self action:@selector(clickSendButtonEvent) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_sendButton];
    
    _sepLine = [[UIView alloc]init];
    _sepLine.backgroundColor = [UIColor colorWithRed:0.87 green:0.87 blue:0.87 alpha:1.00];
    _sepLine.layer.shadowColor = [UIColor colorWithRed:0.87 green:0.87 blue:0.87 alpha:1.00].CGColor;
    _sepLine.layer.shadowOffset = CGSizeMake(-1, 0);
    _sepLine.layer.shadowOpacity = 0.3;
    _sepLine.layer.shadowRadius = 1;
    [self addSubview:_sepLine];
    
    _emojiCollectionView.backgroundColor = [UIColor colorWithRed:0.96 green:0.96 blue:0.96 alpha:1.00];
    _categoryCollectionView.backgroundColor = [UIColor colorWithRed:1.00 green:1.00 blue:1.00 alpha:1.00];
    _sendButton.backgroundColor = [UIColor colorWithRed:0.98 green:0.98 blue:0.98 alpha:1.00];
}

- (void)adjustLayout{
    CGFloat length = [UIScreen mainScreen].bounds.size.width / kEmojiColumnCount;
    CGRect emojiFrame = CGRectMake(0,0,[UIScreen mainScreen].bounds.size.width, length * kEmojiRowCount + 1);
    
    CGRect categoryFrame = CGRectMake(0, CGRectGetMaxY(emojiFrame), [UIScreen mainScreen].bounds.size.width - kButtonWidth, kButtonHeight);
    CGRect buttonFrame = CGRectMake(CGRectGetMaxX(categoryFrame), CGRectGetMaxY(emojiFrame), kButtonWidth, kButtonHeight);
    
    _emojiCollectionView.frame = emojiFrame;
    _categoryCollectionView.frame = categoryFrame;
    _sendButton.frame = buttonFrame;
    
    CGFloat sepLineWidth = 1.0 / [UIScreen mainScreen].scale;
    CGRect sepLineFrame = CGRectMake(CGRectGetMaxX(categoryFrame) - sepLineWidth , CGRectGetMaxY(emojiFrame), sepLineWidth, kButtonHeight);
    _sepLine.frame = sepLineFrame;
    
    CGRect rect = self.frame;
    rect.size = CGSizeMake([UIScreen mainScreen].bounds.size.width, CGRectGetMaxY(buttonFrame));
    self.frame = rect;
    
}

#pragma mark - 交互 -
- (void)clickSendButtonEvent{
    if ([self.delegate respondsToSelector:@selector(emojiKeyboardClickSendEvent:)]) {
        [self.delegate emojiKeyboardClickSendEvent:self];
    }
}

#pragma mark - 协议 -
#pragma mark - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    if ([collectionView isEqual:_emojiCollectionView]) {
        return self.emojiList.count;
    }
    if ([collectionView isEqual:_categoryCollectionView]) {
        return 1;
    }
    return 0;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if ([collectionView isEqual:_emojiCollectionView]) {
        return kEmojiColumnCount * kEmojiRowCount;
    }
    return [self.emojiCategoryList count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([collectionView isEqual:_emojiCollectionView]) {
        return [self getEmojiCollectionViewCell:indexPath];
    }
    
    if ([collectionView isEqual:_categoryCollectionView]) {
        return [self getCategoryCollectionViewCell:indexPath];
    }
    
    return nil;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    if ([collectionView isEqual:_emojiCollectionView]) {//选中表情
        if (indexPath.row == kEmojiRowCount * kEmojiColumnCount - 1) {//删除
            if ([self.delegate respondsToSelector:@selector(emojiKeyboardClickDeleteEvent:)]) {
                [self.delegate emojiKeyboardClickDeleteEvent:self];
            }
            return;
        }
        NSArray *emojiArr = self.emojiList[indexPath.section];
        if (indexPath.row < [emojiArr count]) {
            NSString *emoji = emojiArr[indexPath.row];
            if (emoji.length) {//标签
                if ([self.delegate respondsToSelector:@selector(emojiKeyboard:sendEmoji:)]) {
                    [self.delegate emojiKeyboard:self sendEmoji:emoji];
                }
                return;
            }
        }
    }
    
    if ([collectionView isEqual:_categoryCollectionView]) {//选择分类
        NSArray *emojiArr = [self getEmojiListWithSection:indexPath.row];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self contains %@",emojiArr.firstObject];
        NSArray *arr =  [self.emojiList filteredArrayUsingPredicate:predicate].firstObject;
        NSInteger page = [self.emojiList indexOfObject:arr];
        _selectCategory = indexPath.row;
        [_emojiCollectionView setContentOffset:CGPointMake(page * _emojiCollectionView.frame.size.width, 0)];
        [_categoryCollectionView reloadData];
    }
}

#pragma mark - UICollectionViewDelegateFlowLayout
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if([collectionView isEqual:_emojiCollectionView]){
        CGFloat length = [UIScreen mainScreen].bounds.size.width / kEmojiColumnCount;
        return CGSizeMake(length, length);
    }
    if ([collectionView isEqual:_categoryCollectionView]) {
        return CGSizeMake(kCategoryCellWidth,kCategoryCellHeight);
    }
    return CGSizeZero;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsZero;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return CGSizeZero;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section{
    return CGSizeZero;
}

#pragma mark - UIScrollViewdelegate
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if ([scrollView isEqual:_emojiCollectionView]) {
        NSInteger page = _emojiCollectionView.contentOffset.x /  _emojiCollectionView.frame.size.width;
        if (page>= _emojiList.count) {
            return;
        }
        NSString *firstEmoji =  [_emojiList[page]  firstObject];
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"self contains %@",firstEmoji];
        NSArray *arr =  [self.emojiCategoryList filteredArrayUsingPredicate:predicate].firstObject;
        _selectCategory = [self.emojiCategoryList indexOfObject:arr];
        [self.categoryCollectionView reloadData];
    }
}

#pragma mark - 得到cell -
- (UICollectionViewCell *)getEmojiCollectionViewCell:(NSIndexPath *)indexPath{
    if (indexPath.row == kEmojiRowCount * kEmojiColumnCount - 1) {
        XYEmojiKeyboardImgCell *cell = [_emojiCollectionView dequeueReusableCellWithReuseIdentifier:kKeyboardImgCellReuseIdentifier forIndexPath:indexPath];
        return cell;
    }
    
    XYEmojiKeyboardLabelCell *cell = [_emojiCollectionView dequeueReusableCellWithReuseIdentifier:kKeyboardCellReuseIdentifier forIndexPath:indexPath];
    NSArray *emojiArr = self.emojiList[indexPath.section];
    if (indexPath.row < [emojiArr count]) {
        NSString *emoji = emojiArr[indexPath.row];
        cell.emojiLabel.text = emoji;
    }
    return cell;
}

- (UICollectionViewCell *)getCategoryCollectionViewCell:(NSIndexPath *)indexPath{
    XYEmojiKeyboardLabelCell *cell = [_categoryCollectionView dequeueReusableCellWithReuseIdentifier:kCategoryCellReuseIdentifier forIndexPath:indexPath];
    NSArray *emojiArr = [self getEmojiListWithSection:indexPath.row];
    cell.emojiLabel.text = emojiArr.firstObject;
    cell.backgroundColor = (indexPath.row == _selectCategory)?[UIColor colorWithRed:0.96 green:0.96 blue:0.96 alpha:1.00]:[UIColor colorWithRed:1.00 green:1.00 blue:1.00 alpha:1.00];
    return cell;
}

#pragma mark - 其他方法 -
- (NSArray *)getEmojiListWithSection:(NSInteger)section{

    return self.emojiCategoryList[section];
}

#pragma mark - 分页
- (NSArray *)pagingFunc{
    NSMutableArray *arr = @[].mutableCopy;
    
    for (int i = 0; i< self.emojiCategoryList.count; i++) {
        NSArray *emojiArr = self.emojiCategoryList[i];
        
        for (int j = 0; j < emojiArr.count; j+=kEmojiRowCount*kEmojiColumnCount -1) {
            NSUInteger local = j;
            NSUInteger length =  kEmojiRowCount*kEmojiColumnCount - 1;
            if(local + length < emojiArr.count){
                NSArray * pageEmojiArr = [emojiArr subarrayWithRange:NSMakeRange(local, length)];
                [arr addObject:pageEmojiArr];
            }else{
                NSMutableArray * pageEmojiArr = [emojiArr subarrayWithRange:NSMakeRange(local, emojiArr.count - local - 1)].mutableCopy;
                for (NSInteger i = pageEmojiArr.count; i < kEmojiRowCount*kEmojiColumnCount - 1; i++) {
                    [pageEmojiArr addObject:@""];
                }
                [arr addObject:pageEmojiArr];
            }
        }
        
    }
    return arr;
}

#pragma mark - 属性方法 -
- (NSArray *)emojiCategoryList{
    if (_emojiCategoryList == nil) {
        _emojiCategoryList = [NSArray arrayWithContentsOfFile:[XYEmojiSourceProtocol pathWithName:@"EmojisList" withType:@"plist"]];
    }
    return _emojiCategoryList;
}

- (NSArray *)emojiList{
    if (_emojiList == nil) {
        _emojiList = [self pagingFunc];
    }
    return _emojiList;
}
@end
