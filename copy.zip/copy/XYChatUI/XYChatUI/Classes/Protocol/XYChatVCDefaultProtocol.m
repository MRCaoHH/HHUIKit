//
//  XYChatVCDefaultProtocol.m
//  XYChatUI
//
//  Created by henry on 2017/11/15.
//

#import "XYChatVCDefaultProtocol.h"
#import "XYChatHeaderView.h"
#import "XYChatFooterView.h"
#import "XYChatPlusItem.h"
#import "XYChatMsgTextModel.h"
#import "XYChatTextBubbleCell.h"
#import "XYChatVC.h"
#import "XYChatTimeCell.h"
#import "XYChatPictureBubbleCell.h"
#import "XYChatMsgPictureModel.h"
#import "XYChatModalityController.h"
#import "XYChatServiceManager.h"
#import "XYChatContactModel.h"
#import <XYMacro/XYMacro_Func.h>
#import "XYChatDateConvertTool.h"

@interface XYChatVCDefaultProtocol()<UINavigationControllerDelegate,UIImagePickerControllerDelegate,XYChatServiceManagerDelegate>
@property (nonatomic,weak) XYChatServiceManager *manager;
@end

@implementation XYChatVCDefaultProtocol
@synthesize msgArr = _msgArr,chatVC = _chatVC,contactModel = _contactModel;
static NSString *kTextReceviceCellReuseIdentifier = @"kTextReceviceCellReuseIdentifier";
static NSString *kTextSendCellReuseIdentifier = @"kTextSendCellReuseIdentifier";
static NSString *kPictureReceviceCellReuseIdentifier = @"kPictureReceviceCellReuseIdentifier";
static NSString *kPictureSendCellReuseIdentifier = @"kPictureSendCellReuseIdentifier";
static NSString *kTimeCellReuseIdentifier = @"kTimeCellReuseIdentifier";

static CGFloat kTimeSpa = 300;

- (instancetype)init{
    self = [super init];
    if (self) {
        _msgArr = @[].mutableCopy;
    }
    return self;
}

- (void)dealloc{
    [self.manager removeDelegate:self];
}

#pragma mark - 视图 -
- (UIView <XYChatFooterProtocol>*)footerView{
    return [XYChatFooterView new];
}

- (UIView <XYChatHeaderProtocol>*)headerView{
    return nil;
}

- (void)enterRoom{
    [self.manager flagReadStataWithMid:self.contactModel.toUserId];
}

- (void)leaveRoom{
    [self.manager removeDelegate:self];
}

- (void)selectPlusItem:(XYChatPlusItem *)item{
    if ([item.title isEqualToString:@"相机"]) {
        UIImagePickerController *imgPickerController = [[UIImagePickerController alloc]init];
        imgPickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        imgPickerController.delegate = self;
        [self.chatVC presentViewController:imgPickerController animated:YES completion:^{
            if ([self.chatVC.navigationController isKindOfClass:[XYChatModalityController class]]) {
                XYChatModalityController *vc = (XYChatModalityController *)self.chatVC.navigationController;
                [vc hiddenLayout];
            }
        }];
        return;
    }
    if ([item.title isEqualToString:@"相册"]) {
        UIImagePickerController *imgPickerController = [[UIImagePickerController alloc]init];
        imgPickerController.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
        imgPickerController.delegate = self;
        [self.chatVC presentViewController:imgPickerController animated:YES completion:^{
            if ([self.chatVC.navigationController isKindOfClass:[XYChatModalityController class]]) {
                XYChatModalityController *vc = (XYChatModalityController *)self.chatVC.navigationController;
                [vc hiddenLayout];
            }
        }];
        return;
    }
}

#pragma mark - tableView -
- (NSInteger)getCellCountWithTableView:(UITableView *)tableView{
    return self.msgArr.count;
}

- (UITableViewCell *)getCellWithTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    id obj = self.msgArr[indexPath.row];
    if ([obj isKindOfClass:[NSString class]]) {
        return [self getTimeCellWithTableView:tableView indexPath:indexPath];
    }
    if ([obj isKindOfClass:[XYChatMsgTextModel class]]) {
        return  [self getTextCellWithTableView:tableView indexPath:indexPath];
    }
    if ([obj isKindOfClass:[XYChatMsgPictureModel class]]) {
        return [self getPictureCellWithTableView:tableView indexPath:indexPath];
    }
    return [UITableViewCell new];
}

- (UITableViewCell *)getTimeCellWithTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    XYChatTimeCell *timeCell = [tableView dequeueReusableCellWithIdentifier:kTimeCellReuseIdentifier];
    if (timeCell == nil) {
        timeCell = [[XYChatTimeCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kTimeCellReuseIdentifier];
    }
    NSString *msg = self.msgArr[indexPath.row];
    [timeCell setTime:msg];
    return timeCell;
}

- (UITableViewCell *)getTextCellWithTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    XYChatMsgTextModel *msg = self.msgArr[indexPath.row];
    NSString *reuserIdentifier = kTextReceviceCellReuseIdentifier;
    if (msg.isSend) {
        reuserIdentifier = kTextSendCellReuseIdentifier;
    }
    XYChatTextBubbleCell *cell = [tableView dequeueReusableCellWithIdentifier:reuserIdentifier];
    if (cell == nil) {
        cell = [[XYChatTextBubbleCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuserIdentifier];
        __weak typeof(self) weakSelf = self;
        [cell setResendEvent:^(XYChatMsgBaseModel *model) {
            [weakSelf resendMsg:model];
        }];
    }
    if (msg.cellHeight == 0) {
        [XYChatTextBubbleCell calFrameWithTextModel:&msg];
    }
    cell.model = msg;
    
    return cell;
}

- (UITableViewCell *)getPictureCellWithTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    XYChatMsgPictureModel *msg = self.msgArr[indexPath.row];
    NSString *reuserIdentifier = kPictureReceviceCellReuseIdentifier;
    if (msg.isSend) {
        reuserIdentifier = kPictureSendCellReuseIdentifier;
    }
    XYChatPictureBubbleCell *cell = [tableView dequeueReusableCellWithIdentifier:reuserIdentifier];
    if (cell == nil) {
        cell = [[XYChatPictureBubbleCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuserIdentifier];
        __weak typeof(self) weakSelf = self;
        [cell setResendEvent:^(XYChatMsgBaseModel *model) {
            [weakSelf resendMsg:model];
        }];
    }
    if (msg.cellHeight == 0) {
        [XYChatPictureBubbleCell calFrameWithPictModel:&msg];
    }
    cell.model = msg;
    return cell;
}

- (CGFloat)getCellHeightWithTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath{
    id obj = self.msgArr[indexPath.row];
    if ([obj isKindOfClass:[XYChatMsgTextModel class]]) {
        XYChatMsgTextModel *msg =(XYChatMsgTextModel *)obj;
        if (msg.cellHeight == 0) {
            [XYChatTextBubbleCell calFrameWithTextModel:&msg];
        }
        return msg.cellHeight;
    }
    if ([obj isKindOfClass:[XYChatMsgPictureModel class]]) {
        XYChatMsgPictureModel *msg =(XYChatMsgPictureModel *)obj;
        if (msg.cellHeight == 0) {
            [XYChatPictureBubbleCell calFrameWithPictModel:&msg];
        }
        return msg.cellHeight;
    }
    
    if ([obj isKindOfClass:[NSString class]]) {
        return 40;
    }
    return 0;
    
}

#pragma mark - 消息管理 -
- (void)resendMsg:(XYChatMsgBaseModel *)model{
    if ([model isKindOfClass:[XYChatMsgTextModel class]]) {
        XYChatMsgTextModel *textModel = (XYChatMsgTextModel *)model;
        [self.msgArr removeObject:model];
        [self sendMsg:textModel.content];
        
    }
    
}

- (void)sendMsg:(id)msg{
    if ([msg isKindOfClass:[NSString class]]) {
        NSString *text = msg;
        if (!text.length) {
            return;
        }
        XYChatMsgTextModel *item = [XYChatMsgTextModel new];
        item.content = msg;
        item.isSend = YES;
        item.state =XYChatMsgSendState_Sending;
        item.createTime = [NSDate date].timeIntervalSince1970;
        item.toUid = self.contactModel.toUserId;
        [self addMsg:item];
        [self.chatVC.tableView reloadData];
        [self.chatVC scrollToBottom:YES];
        [self.manager sendTextMsg:item];
        
    }
    
    if ([msg isKindOfClass:[UIImage class]]) {
        UIImage *img = (UIImage *)msg;
        XYChatMsgPictureModel *item = [XYChatMsgPictureModel new];
        item.localImg = img;
        item.width = img.size.width;
        item.height = img.size.height;
        item.createTime = [NSDate date].timeIntervalSince1970;
        item.isSend = YES;
        item.state =XYChatMsgSendState_Sending;
        [self addMsg:item];
        [self.chatVC.tableView reloadData];
        [self.chatVC scrollToBottom:YES];
    }

}

- (void)receiveMsg:(id)msg{
    [self.manager flagReadStataWithMid:self.contactModel.toUserId];
    BOOL scrollBottom = NO;
    if (self.chatVC.tableView.contentSize.height -  self.chatVC.tableView.contentOffset.y <= self.chatVC.tableView.frame.size.height + 200) {
        scrollBottom = YES;
    }
    
    if ([msg isKindOfClass:[NSString class]]) {
        [_msgArr addObject:msg];
    }
    
    if ([msg isKindOfClass:[XYChatMsgTextModel class]]) {
        [self addMsg:msg];
    }
    
    [self.chatVC.tableView reloadData];
    if (scrollBottom) {
        [self.chatVC scrollToBottom:YES];
    }
}

- (void)addMsg:(XYChatMsgBaseModel *)msg{
    //cal time 计算时间，消息间隔5min
    XYChatMsgBaseModel *baseModel = [self lastMsgWithMsgArr:_msgArr];
    if ( msg.createTime - baseModel.createTime > kTimeSpa) {
        NSString *dateString = [XYChatDateConvertTool getTimeWithTimeStamp:msg.createTime];
        [_msgArr addObject:dateString];
    }
    [_msgArr addObject:msg];
}

- (void)insertMsgList:(NSArray *)msgList{
    NSMutableArray *msgArr = @[].mutableCopy;
    for (XYChatMsgBaseModel *msg in msgList) {
        XYChatMsgBaseModel *baseModel = [self lastMsgWithMsgArr:msgArr];
        if ( msg.createTime - baseModel.createTime > kTimeSpa) {
            NSString *dateString = [XYChatDateConvertTool getTimeWithTimeStamp:msg.createTime];
            [msgArr addObject:dateString];
        }
        [msgArr addObject:msg];
    }
    [_msgArr insertObjects:msgArr atIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, msgArr.count)]];
}

- (XYChatMsgBaseModel *)lastMsgWithMsgArr:(NSArray *)msgList{
    for (NSInteger i = [msgList count] - 1; i >= 0; i--) {
        if (i>= [msgList count]) { break; }
        
        XYChatMsgBaseModel *lastMsg = msgList[i];
        if ([lastMsg isKindOfClass:[XYChatMsgBaseModel class]]) {
            return lastMsg;
        }
    }
    return nil;
}


- (void)loadMore:(void(^)(void))complete{
    XYChatMsgBaseModel *obj = [self getFirstMsg];
    
    XYWeakSelf;
    
    [self.manager queryMsgListWithMid:self.contactModel.toUserId messageId:obj.id callback:^(BOOL succ, NSArray *msgs) {
        
        if (!succ) {
            if (complete) {
                complete();
            }
        }
        [weakSelf insertMsgList:msgs];
        if (complete) {
            complete();
        }
        NSInteger index = [weakSelf.msgArr indexOfObject:obj];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index inSection:0];
        [weakSelf.chatVC.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }];
    
}


- (XYChatMsgBaseModel *)getFirstMsg{
    XYChatMsgBaseModel *msg = nil;
    for (int i = 0; i < self.msgArr.count; i++) {
        id obj = self.msgArr[i];
        if ([obj isKindOfClass:[XYChatMsgBaseModel class]]) {
            msg = obj;
            break;
        }
    }
    return msg;
}

#pragma mark - 协议 -
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage *img = info[@"UIImagePickerControllerOriginalImage"];
    [self sendMsg:img];
    [picker dismissViewControllerAnimated:YES completion:^{
        if ([self.chatVC.navigationController isKindOfClass:[XYChatModalityController class]]) {
            XYChatModalityController *vc = (XYChatModalityController *)self.chatVC.navigationController;
            [vc recoveryLayout];
        }
    }];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:^{
        if ([self.chatVC.navigationController isKindOfClass:[XYChatModalityController class]]) {
            XYChatModalityController *vc = (XYChatModalityController *)self.chatVC.navigationController;
            [vc recoveryLayout];
        }
    }];
}

#pragma mark - XYChatServiceManagerDelegate
- (void)chatServiceManager:(XYChatServiceManager *)manager receiveMsg:(id)msg{
    [self receiveMsg:msg];
}
#pragma mark - 属性
- (XYChatServiceManager *)manager{
    if (_manager == nil) {
        _manager = [XYChatServiceManager shareInstance];
    }
    return _manager;
}

- (void)setContactModel:(XYChatContactModel *)contactModel{
    _contactModel = contactModel;
    XYWeakSelf;
    [self.manager addDelegate:weakSelf subscribeWithMid:contactModel.toUserId];
}
@end
