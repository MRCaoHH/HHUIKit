# XYWebSocket

[![CI Status](http://img.shields.io/travis/henry/XYWebSocket.svg?style=flat)](https://travis-ci.org/henry/XYWebSocket)
[![Version](https://img.shields.io/cocoapods/v/XYWebSocket.svg?style=flat)](http://cocoapods.org/pods/XYWebSocket)
[![License](https://img.shields.io/cocoapods/l/XYWebSocket.svg?style=flat)](http://cocoapods.org/pods/XYWebSocket)
[![Platform](https://img.shields.io/cocoapods/p/XYWebSocket.svg?style=flat)](http://cocoapods.org/pods/XYWebSocket)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYWebSocket is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYWebSocket'
```

## Author

henry, henry@xy.com

## License

XYWebSocket is available under the MIT license. See the LICENSE file for more info.
