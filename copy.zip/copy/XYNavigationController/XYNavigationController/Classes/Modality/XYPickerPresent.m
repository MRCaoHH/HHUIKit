//
//  XYPickerPresent.m
//  XYNavigationController
//
//  Created by henry on 2017/12/23.
//

#import "XYPickerPresent.h"
#import <POP/POP.h>

@implementation XYPickerPresent
- (instancetype)init{
    self = [super init];
    if (self) {
        self.duration = 0.2;
        self.bgColor = [[UIColor blackColor] colorWithAlphaComponent:0.2];
    }
    return self;
}

- (NSTimeInterval)transitionDuration:(id <UIViewControllerContextTransitioning>)transitionContext{
    return self.duration;
}

- (void)animateTransition:(id <UIViewControllerContextTransitioning>)transitionContext{
    UIView *fromView = [transitionContext viewControllerForKey:UITransitionContextFromViewControllerKey].view;
    fromView.tintAdjustmentMode = UIViewTintAdjustmentModeNormal;
    
    UIView *dimmingView = [[UIView alloc] initWithFrame:fromView.bounds];
    dimmingView.backgroundColor = self.bgColor;
    dimmingView.layer.opacity = 0.0;
    [self addTapDismissGuesture:dimmingView toViewController:[transitionContext viewControllerForKey:UITransitionContextToViewControllerKey]];
    
    UIView *toView = [transitionContext viewControllerForKey:UITransitionContextToViewControllerKey].view;
    toView.frame = CGRectMake(0,
                              fromView.frame.size.height,
                              self.viewSize.width,
                              self.viewSize.height);
    [transitionContext.containerView addSubview:dimmingView];
    [transitionContext.containerView addSubview:toView];
    
    POPSpringAnimation *positionAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerPositionY];
    positionAnimation.toValue = @(transitionContext.containerView.frame.size.height - self.viewSize.height/2);
    [positionAnimation setCompletionBlock:^(POPAnimation *anim, BOOL finished) {
        [transitionContext completeTransition:YES];
    }];
    
    POPBasicAnimation *opacityAnimation = [POPBasicAnimation animationWithPropertyNamed:kPOPLayerOpacity];
    opacityAnimation.toValue = @(1.0);
    
    [toView.layer pop_addAnimation:positionAnimation forKey:@"positionAnimation"];
    [dimmingView.layer pop_addAnimation:opacityAnimation forKey:@"opacityAnimation"];
}

- (void)addTapDismissGuesture:(UIView *)view toViewController:(UIViewController *)viewController{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wundeclared-selector"
    if ([viewController respondsToSelector:@selector(xy_dismissVC)]) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:viewController action:@selector(xy_dismissVC)];
        [view addGestureRecognizer:tap];
    }
#pragma clang diagnostic pop
}

@end
