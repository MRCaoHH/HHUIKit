//
//  XYHttpRequestProtocol.h
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import <Foundation/Foundation.h>
@class XYResponseModel;
@interface XYHttpRequestProtocol : NSObject
/**
 注册的类
 */
@property (nonatomic, class, readonly) Class regisclass;

/**
 注册协议对象
 
 @param aclass 对象类
 */
+ (BOOL)registerClass:(Class)aclass;


/**
 取消注册协议对象
 
 @param aclass 对象类
 */
+ (void)unregisterClass:(Class)aclass;


/**
 默认数据返回类型
 
 @return 数据返回类型
 */
+ (NSInteger)defaultResponseType;

/**
 默认请求数据返回类型

 @return 数据返回类型
 */
+ (NSInteger)defaultRequestType;

/**
 网络请求的host
 
 @return host
 */
+ (NSString *)host;


/**
 公共输入参数
 
 @return 参数
 */
+ (NSDictionary *)publicInputParams;


/**
 输入参数处理
 
 @param param 参数
 @return 参数
 */
+ (NSDictionary *)inputParamsHander:(NSDictionary *)param;


/**
 处理返回数据
 
 @param responseObject 返回对象
 @return 处理之后的数据，也就是LYResponseModel中的dataModel
 */
+ (id)handelResponseObject:(id)responseObject;


/**
 检查是否请求成功
 请求成功走succ回调 请求失败走fail回调
 @param responseModel 返回模型
 @return YES 请求成功 NO 请求失败
 */
+ (BOOL)checkRequestSucc:(XYResponseModel **)responseModel;

/**
 处理错误请求
 @param responseModel 返回模型
 */
+ (void)handleFail:(XYResponseModel **)responseModel;

/**
 公共输出参数
 
 @param dataModel 输出参数
 */
+ (void)publicOutParam:(id)dataModel;


/**
 http头配置
 
 @return http头配置
 */
+ (NSDictionary <NSString *,NSString*>*)httpHeaderConfig;


/**
 参数检查

 @param params 参数
 @param err 不通过提示
 @return 通过返回YES 不通过返回NO
 */
+ (BOOL)checkParams:(id)params err:(NSString **)err;


/**
 参数转换，传入参数的类型如果不是字典则需要转换成字典,默认不做转换，进来是什么出去就是什么

 @param params 参数
 @return 参数
 */
+ (NSDictionary *)transformParams:(id)params;
@end
