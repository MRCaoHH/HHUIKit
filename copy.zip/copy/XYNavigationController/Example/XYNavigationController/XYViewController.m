//
//  XYViewController.m
//  XYNavigationController
//
//  Created by henry on 10/27/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

#import "XYViewController.h"
#import <XYNavigationController/UIViewController+XYNavBar.h>
#import "XYAlertViewController.h"
#import "XYBlurViewController.h"
#import "XYPickerViewController.h"

@interface XYViewController ()
@property (nonatomic, strong) UIButton *pushButton;
@property (nonatomic,strong) UIButton *alertButton;
@property (nonatomic,strong) UIButton *blurButton;
@property (nonatomic,strong) UIButton *pickerButton;
@end

@implementation XYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typicalXY from a nib.
    [self initUI];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    
    return self.xy_hiddenNarBar?UIStatusBarStyleDefault:UIStatusBarStyleLightContent;
}

#pragma mark - 初始化
- (void)initUI{
    self.view.backgroundColor = self.xy_hiddenNarBar? [UIColor orangeColor]:[UIColor purpleColor];
    UIColor *bgColor = self.xy_hiddenNarBar ? [UIColor redColor]:[UIColor blueColor];
    _pushButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 100, 200, 60)];
    _pushButton.center = self.view.center;
    CGRect frame = _pushButton.frame;
    frame.origin.y = 100;
    _pushButton.frame = frame;
    _pushButton.backgroundColor = bgColor;
    [_pushButton setTitle:@"push" forState:UIControlStateNormal];
    [_pushButton addTarget:self action:@selector(clickPushBtnEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_pushButton];
    

    _alertButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 100, 200, 60)];
    _alertButton.center = self.view.center;
    frame = _alertButton.frame;
    frame.origin.y = CGRectGetMaxY(_pushButton.frame) + 40;
    _alertButton.frame = frame;
    _alertButton.backgroundColor = bgColor;
    [_alertButton setTitle:@"alert" forState:UIControlStateNormal];
    [_alertButton addTarget:self action:@selector(clickAlertBtnEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_alertButton];
    
    _blurButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 100, 200, 60)];
    _blurButton.center = self.view.center;
    frame = _blurButton.frame;
    frame.origin.y = CGRectGetMaxY(_alertButton.frame) + 40;
    _blurButton.frame = frame;
    _blurButton.backgroundColor = bgColor;
    [_blurButton setTitle:@"blur" forState:UIControlStateNormal];
    [_blurButton addTarget:self action:@selector(clickBlurBtnEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_blurButton];
    
    _pickerButton = [[UIButton alloc]initWithFrame:CGRectMake(0, 100, 200, 60)];
    _pickerButton.center = self.view.center;
    frame = _pickerButton.frame;
    frame.origin.y = CGRectGetMaxY(_blurButton.frame) + 40;
    _pickerButton.frame = frame;
    _pickerButton.backgroundColor = bgColor;
    [_pickerButton setTitle:@"picker" forState:UIControlStateNormal];
    [_pickerButton addTarget:self action:@selector(clickPickerBtnEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_pickerButton];
}

- (void)clickPushBtnEvent{
    XYViewController *vc = [[XYViewController alloc]init];
    vc.xy_hiddenNarBar = !self.xy_hiddenNarBar;
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)clickAlertBtnEvent{
    XYAlertViewController *alertVC = [XYAlertViewController new];
    [self presentViewController:alertVC animated:YES completion:nil];
}

- (void)clickBlurBtnEvent{
    XYBlurViewController *blurVC = [XYBlurViewController new];
    [self presentViewController:blurVC animated:YES completion:nil];
}

- (void)clickPickerBtnEvent{
    XYPickerViewController *pickerVC = [XYPickerViewController new];
    [self presentViewController:pickerVC animated:YES completion:nil];
}
@end
