//
//  NSObject+XYExtension.m
//  XYExtension
//
//  Created by henry on 2017/10/26.
//

#import "NSObject+XYExtension.h"
#import <MJExtension/MJExtension.h>

@implementation NSObject (XYExtension)

+ (id)mj_replacedKeyFromPropertyName121:(NSString *)propertyName{
    return [self xy_replacedKeyFromPropertyName121:propertyName];
}

+ (id)xy_replacedKeyFromPropertyName121:(NSString *)propertyName{
    return nil;
}

#pragma mark - JSON字符串转模型
+(id)xy_objectWithKeyValues:(id)values
{
    return  [self mj_objectWithKeyValues:values];
}

+(id)xy_objectWithKeyValues:(id)values context:(NSManagedObjectContext *)context
{
    return [self mj_objectArrayWithKeyValuesArray:values context:context];
}

#pragma mark - 将一个字典数组转成模型数组
+(NSMutableArray *)xy_objectArrayWithKeyValuesArray:(id)valuesArr
{
    return [self mj_objectArrayWithKeyValuesArray:valuesArr];
}

#pragma mark - 模型数组转字典
+(NSMutableArray *)xy_keyValuesArrayWithObjectArray:(NSArray *)objectArr
{
    return [self mj_keyValuesArrayWithObjectArray:objectArr];
}

#pragma mark - 设置对象数组当中包含的对象
+(void)xy_setupObjectClassInArray:(NSDictionary *(^)(void))objectClassInArray
{
    [self mj_setupObjectClassInArray:objectClassInArray];
}

#pragma mark - 模型中的属性名和字典中的key不相同(或者需要多级映射)
+(void)xy_setupReplacedKeyFromPropertyName:(NSDictionary * (^)(void))replacedKeyFromPropertyName
{
    [self mj_setupReplacedKeyFromPropertyName:replacedKeyFromPropertyName];
}

#pragma mark - 忽略不归档的属性名
+(void)xy_setupIgnoredCodingPropertyNames:(NSArray *(^)(void))ignoredCodingPropertyNames
{
    [self mj_setupIgnoredCodingPropertyNames:ignoredCodingPropertyNames];
}

#pragma mark - 忽略属性
+(void)xy_setupIgnoredPropertyNames:(NSArray *(^)(void))ignoredPropertyNames{
    [self mj_setupIgnoredPropertyNames:ignoredPropertyNames];
}

#pragma mark - 将一个模型转成字典
-(NSMutableDictionary *)xy_keyValues
{
    return self.mj_keyValues;
}

#pragma mark - 得到json字符串
- (NSString *)xy_JSONString{
    return [self mj_JSONString];
}

- (id)xy_JSONObject{
    return [self mj_JSONObject];
}

#pragma mark - 键值转化为属性值 -
- (instancetype)xy_setKeyValues:(id)objc{
    return [self mj_setKeyValues:objc];
}

@end

@implementation NSString (LYExtension)

- (NSString *)xy_underlineFromCamel{
    return  [self mj_underlineFromCamel];
}

@end
