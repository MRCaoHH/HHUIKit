//
//  XYAlertDismiss.h
//  XYNavigationController
//
//  Created by caohuihui on 2017/12/07.
//  Copyright © 2017年 Xin YI. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,XYAlertDismissAnimateType) {
    XYAlertDismissAnimateType_Recovery = 0,//恢复原样，往上
    XYAlertDismissAnimateType_Fall = 1,//掉下
};

@interface XYAlertDismiss : NSObject<UIViewControllerAnimatedTransitioning>

/**
 动画执行时间
 */
@property (nonatomic,assign) NSTimeInterval duration;

/**
 动画类型
 */
@property (nonatomic,assign) XYAlertDismissAnimateType type;

@end
