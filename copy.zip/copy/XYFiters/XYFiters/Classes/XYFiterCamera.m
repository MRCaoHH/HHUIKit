//
//  XYFiterCamera.m
//  XYFiters
//
//  Created by henry on 2018/11/21.
//

#import "XYFiterCamera.h"
#import <GPUImage/GPUImage.h>

@interface XYFiterCamera ()<GPUImageVideoCameraDelegate>

@property (nonatomic,strong) GPUImageVideoCamera *videoCamera;
@property (nonatomic,strong) GPUImageOutput<GPUImageInput> *filter;
@end

@implementation XYFiterCamera

- (instancetype)init{
    self = [super init];
    if (self) {
        _filterType  = XY_NONE_FILTER;
        _position = AVCaptureDevicePositionBack;
        _preset = AVCaptureSessionPresetInputPriority;
        [self initSubview];
    }
    return self;
}

- (void)initSubview{
    self.videoCamera = [[GPUImageVideoCamera alloc] initWithSessionPreset:self.preset cameraPosition:self.position];
    self.videoCamera.delegate = self;
    self.videoCamera.outputImageOrientation = UIInterfaceOrientationPortrait;
    self.filterType = XY_NORMAL_FILTER;
    [self.videoCamera startCameraCapture];
}

#pragma mark - GPUImageVideoCameraDelegate
- (void)willOutputSampleBuffer:(CMSampleBufferRef)sampleBuffer{
    if ([self.delegate respondsToSelector:@selector(willOutputPixBufferRef:ts:)]) {
        CVImageBufferRef cvBuffRef = CMSampleBufferGetImageBuffer(sampleBuffer);
        CVPixelBufferRef poxelBuffRef = cvBuffRef;
        NSTimeInterval tsTimeInterval = [NSDate date].timeIntervalSince1970;
        [self.delegate willOutputPixBufferRef:poxelBuffRef ts:tsTimeInterval];
    }
    
}

#pragma mark - 属性
- (void)setImgView:(GPUImageView *)imgView{
    if (_imgView) {
        [self.filter removeTarget:_imgView];
    }
    _imgView = imgView;
    [self.filter addTarget:_imgView];
    [self.videoCamera startCameraCapture];
}

- (void)setPreset:(AVCaptureSessionPreset)preset{
    _preset = preset;
    [self.videoCamera setCaptureSessionPreset:preset];
}

- (void)setPosition:(AVCaptureDevicePosition)position{
    _position = position;
}

- (void)setFilterType:(XYFilterType)filterType{
    if (_filterType == filterType) {
        return;
    }
    
    if (self.filter) {
        [self.videoCamera removeTarget:self.filter];
    }
    _filterType = filterType;
    
    
    
    NSString *className = self.filterMap[@(filterType)];
    
    if (className) {
        Class aclass =  NSClassFromString(className);
        self.filter = [[aclass alloc]init];
    }
}

- (void)setFilter:(GPUImageOutput<GPUImageInput> *)filter{
    if (_filter) {
        [self.videoCamera removeTarget:_filter];
    }
    _filter = filter;
    if (self.imgView) {
        [_filter addTarget:self.imgView];
    }
    [self.videoCamera addTarget:_filter];
    [self.videoCamera startCameraCapture];
}


- (NSDictionary *)filterMap{
    if (_filterMap == nil) {
        _filterMap = @{
                       @(XY_AMARO_FILTER):@"IFAmaroFilter",
                       @(XY_NORMAL_FILTER):@"IFNormalFilter",
                       @(XY_RISE_FILTER):@"IFRiseFilter",
                       @(XY_HUDSON_FILTER):@"IFHudsonFilter",
                       @(XY_XPROII_FILTER):@"IFXproIIFilter",
                       @(XY_SIERRA_FILTER):@"IFSierraFilter",
                       @(XY_LOMOFI_FILTER):@"IFLomofiFilter",
                       @(XY_EARLYBIRD_FILTER):@"IFEarlybirdFilter",
                       @(XY_SUTRO_FILTER):@"IFSutroFilter",
                       @(XY_TOASTER_FILTER):@"IFToasterFilter",
                       @(XY_BRANNAN_FILTER):@"IFBrannanFilter",
                       @(XY_INKWELL_FILTER):@"IFInkwellFilter",
                       @(XY_WALDEN_FILTER):@"IFWaldenFilter",
                       @(XY_HEFE_FILTER):@"IFHefeFilter",
                       @(XY_VALENCIA_FILTER):@"IFValenciaFilter",
                       @(XY_NASHVILLE_FILTER):@"IFNashvilleFilter",
                       @(XY_1977_FILTER):@"IF1977Filter",
                       @(XY_LORDKELVIN_FILTER):@"IFLordKelvinFilter"
                       };
    }
    return _filterMap;
}
@end
