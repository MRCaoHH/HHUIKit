//
//  XYChatHeaderView.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import <UIKit/UIKit.h>
#import "XYChatHeaderProtocol.h"

@interface XYChatHeaderView : UIView<XYChatHeaderProtocol>
/**
 提示标签
 */
@property (nonatomic,strong) UILabel *tipsLabel;

/**
 关闭按钮
 */
@property (nonatomic,strong) UIButton *closeBtn;
@end
