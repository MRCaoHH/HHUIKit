//
//  XYChatMsgTextModel.m
//  MJExtension
//
//  Created by henry on 2017/11/17.
//

#import "XYChatMsgTextModel.h"
#import <XYCache/XYArchiverTool.h>

@implementation XYChatMsgTextModel

- (id)initWithCoder:(NSCoder *)decoder {
    self = [super init];
    if (!self) {
        return nil;
    }
    [XYArchiverTool unarchiver:decoder object:self superArr:@[@"XYChatMsgBaseModel"] filter:@[@"stateObserver"] ];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder {
    [XYArchiverTool archiver:encoder object:self superArr:@[@"XYChatMsgBaseModel"] filter:@[@"stateObserver"] ];
}

@end
