//
//  XYChatMsgTextModel.h
//  MJExtension
//
//  Created by henry on 2017/11/17.
//

#import <XYChatUI/XYChatMsgBaseModel.h>

@interface XYChatMsgTextModel : XYChatMsgBaseModel

/**
 文本内容
 */
@property (nonatomic,copy) NSString *content;

/**
 消息标签的frame
 */
@property (nonatomic,assign) CGRect msgFrame;

@end
