//
//  XYChatContactCell.m
//  MJExtension
//
//  Created by henry on 2017/11/23.
//

#import "XYChatContactCell.h"
#import <XYCategory/XYCategory.h>

@implementation XYChatContactCell

- (void)layoutSubviews{
    [super layoutSubviews];
    
    [self.timeLabel sizeToFit];
    self.timeLabel.xy_right = self.contentView.xy_right - 12;
    self.timeLabel.xy_bottom = self.nameLabel.xy_bottom;
    
    self.unreadBtn.xy_top = self.iconImgView.xy_centerY;
    self.unreadBtn.xy_right = self.contentView.xy_right - 12;
}

#pragma mark - 属性方法 -
- (UIImageView *)iconImgView{
    if(_iconImgView == nil){
        _iconImgView = [[UIImageView alloc]initWithFrame:CGRectMake(12, 9, 50, 50)];
        _iconImgView.backgroundColor = [UIColor grayColor];
        _iconImgView.layer.cornerRadius = 25;
        _iconImgView.layer.masksToBounds = YES;
        [self.contentView addSubview:_iconImgView];
    }
    return _iconImgView;
}

- (UILabel *)nameLabel{
    if (_nameLabel == nil) {
        _nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(74, 15, [UIScreen mainScreen].bounds.size.width -  74 - 74, 17)];
        _nameLabel.textColor = [UIColor colorWithRed:0.00 green:0.00 blue:0.00 alpha:1.00];
        _nameLabel.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_nameLabel];
    }
    return _nameLabel;
}

- (UILabel *)msgLabel{
    if (_msgLabel == nil) {
        _msgLabel = [[UILabel alloc]initWithFrame:CGRectMake(74, 39, [UIScreen mainScreen].bounds.size.width -  74 - 74, 15)];
        _msgLabel.textColor = [UIColor colorWithRed:0.68 green:0.68 blue:0.68 alpha:1.00];
        _msgLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_msgLabel];
    }
    return _msgLabel;
}

- (UILabel *)timeLabel{
    if (_timeLabel == nil) {
        _timeLabel = [[UILabel alloc]initWithFrame:CGRectMake(74, 39, 0, 15)];
        _timeLabel.textColor = [UIColor colorWithRed:0.60 green:0.60 blue:0.60 alpha:1.00];
        _timeLabel.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_timeLabel];
    }
    return _timeLabel;
}

- (UIButton *)unreadBtn{
    if (_unreadBtn == nil) {
        _unreadBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 20, 20)];
        _unreadBtn.titleLabel.font = [UIFont systemFontOfSize:10];
        [_unreadBtn setBackgroundImage:[UIImage xy_createImageFromColor:[UIColor colorWithRed:0.97 green:0.30 blue:0.19 alpha:1.00]] forState:UIControlStateNormal];
        _unreadBtn.layer.cornerRadius = 10;
        [_unreadBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _unreadBtn.layer.masksToBounds = YES;
        [self.contentView addSubview:_unreadBtn];
    }
    return _unreadBtn;
}
@end
