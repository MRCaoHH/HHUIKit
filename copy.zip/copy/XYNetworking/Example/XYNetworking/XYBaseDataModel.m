//
//  XYBaseDataModel.m
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//  Copyright © 2017年 Henry. All rights reserved.
//

#import "XYBaseDataModel.h"

@implementation XYBaseDataModel

@end
