//
//  XYViewController.m
//  XYChatUI_Example
//
//  Created by henry on 2018/9/27.
//  Copyright © 2018年 henry. All rights reserved.
//

#import "XYViewController.h"
#import <XYChatUI/XYChatVC.h>
#import <XYChatUI/XYChatModalityController.h>
#import <XYChatUI/XYChatServiceManager.h>
//#import <XYChatUI/XYChatDelayedTaskTool.h>
#import <XYChatUI/XYChatDataManager.h>

@interface XYViewController ()

@end

@implementation XYViewController
static NSString *kHost = @"ws://47.91.230.59:9503";


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    dispatch_block_t block =  [XYChatDelayedTaskTool createDelayedTask:3 task:^{
//        NSLog(@"111111111111");
//    }];
//
////    [XYChatDelayedTaskTool cancelBlock:block];
    NSString *kSession = @"5ac8a7eb87ac1902c8922e78dd09d8c8";
    NSString *kMid = @"5";
    if ([[UIDevice currentDevice].name isEqualToString:@"深圳_iPhone7"]) {
        kSession = @"11e6f911bd3046f0d281ed913b4de0de";
        kMid = @"127";
    }
    XYChatServiceManager *manager =  [XYChatServiceManager shareInstance];
    manager.sessionId = kSession;
    manager.mid = kMid;
    manager.host = kHost;
    [manager loginWithSessionId:kSession];
    
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(20, 100, 335, 44)];
    [btn setTitle:@"联系人列表" forState:UIControlStateNormal];
    [btn setBackgroundColor:[UIColor blueColor]];
    [btn addTarget:self action:@selector(clickBtnEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

- (void)clickBtnEvent {
    XYChatModalityController *vc = [XYChatModalityController initContactVC];
    [self presentViewController:vc animated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
