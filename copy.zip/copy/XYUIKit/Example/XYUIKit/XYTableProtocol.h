//
//  XYTableProtocol.h
//  XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//  Copyright © 2017年 blackman. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <XYUIKit/XYBTActionProtocol.h>
@interface XYTableProtocol : NSObject<XYBTActionProtocol>
@property (nonatomic,strong) NSArray *configArr;
- (void)clickTextCell;
- (void)clickImgCell;
@end
