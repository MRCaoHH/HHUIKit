//
//  XYMBViewController.h
//  FBSnapshotTestCase
//
//  Created by henry on 2017/10/20.
//

#import <UIKit/UIKit.h>
@class XYMenuButton;
@interface XYMBViewController : UIViewController
@property (nonatomic,weak,readonly) XYMenuButton *menuButton;
@property (nonatomic,strong) UIView *bgView;
- (instancetype)initWithMenuButton:(XYMenuButton *)menuButtion;

- (void)showAnimated;
- (void)hiddenAnimated;
@end
