//
//  XYHttpRequest.m
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import "XYHttpRequest.h"
#import <AFNetworking/AFNetworking.h>
#import "XYRequestModel.h"
#import "XYResponseModel.h"
#import "XYHttpCookieManage.h"
#import "XYHttpRequestProtocol.h"

@implementation XYHttpRequest

#pragma mark - 得到会话的唯一实例 防止内存泄漏
+ (AFHTTPSessionManager *)manager{
    static AFHTTPSessionManager *_manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _manager = [AFHTTPSessionManager manager];
        ///ssl 公开key
        _manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
        _manager.requestSerializer = [AFHTTPRequestSerializer serializer];
        [XYHttpCookieManage setCookieWithHost:[XYHttpRequest host]];
        
    });
    return _manager;
}

#pragma mark - 主页
+ (NSString *)host{
    return [[XYHttpRequestProtocol  regisclass] host];
}


#pragma mark - 公共参数
+ (NSDictionary *)publicInputParams{
    return [[XYHttpRequestProtocol  regisclass] publicInputParams];
}

#pragma mark - 公共输出
+ (void)publicOutParam:(id)dataModel{
    [[XYHttpRequestProtocol  regisclass] publicOutParam:dataModel];
}

#pragma mark - 请求地址
+ (NSString *)requestUrl:(NSString *)url{
    NSString *reUrl = [self host];
    reUrl = [reUrl stringByAppendingPathComponent:url];
    return reUrl;
}

#pragma mark - 请求参数
+ (NSDictionary *)requestParams:(id)params{
    NSDictionary *paramDic = [[XYHttpRequestProtocol regisclass] transformParams:params] ;
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]initWithDictionary:paramDic];
    //[dic setDictionary:[self publicInputParams]];
    [dic addEntriesFromDictionary:[self publicInputParams]];
    NSDictionary *inputParam = [[XYHttpRequestProtocol  regisclass] inputParamsHander:dic];
    return inputParam;
}

#pragma mark - POST
+ (XYRequestModel *)POST:(NSString  *)url params:(NSDictionary * )params  success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    return [self POST:url params:params progress:nil success:success failure:failure];
}

+ (XYRequestModel *)POST:(NSString  *)url params:(NSDictionary * )params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    return [self POST:url responseType:[[XYHttpRequestProtocol  regisclass] defaultResponseType] params:params progress:progress success:success failure:failure];
}

+ (XYRequestModel *)POST:(NSString  *)url responseType:(XYResponseType)responseType params:(NSDictionary * )params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    return [self POST:url requestType:[[XYHttpRequestProtocol  regisclass] defaultRequestType] responseType:responseType params:params progress:progress success:success failure:failure];
}

+(XYRequestModel *)POST:(NSString  *)url requestType:(XYRequestType)requestType  responseType:(XYResponseType)responseType params:(id)params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    NSString *tipsErr  = nil;
    if (![[XYHttpRequestProtocol regisclass] checkParams:params err:&tipsErr]) {
        XYResponseModel *responseModel = [XYResponseModel new];
        responseModel.tipMsg = tipsErr;
        failure(responseModel);
        return nil;
    }
    
    AFHTTPResponseSerializer *httpResponse = [self getResponseSerializer:responseType];
    AFHTTPSessionManager *manager = [self manager];
    manager.responseSerializer = httpResponse;
    manager.requestSerializer = [self getRequestSerializer:requestType];
    NSString *requestUrl = [self requestUrl:url];
    NSDictionary *requestParams = [self requestParams:params];
    NSURLSessionDataTask *task = [manager POST:requestUrl parameters:requestParams progress:progress success:^(NSURLSessionDataTask * task, id responseObject) {
        [XYHttpRequest handerResponseSucc:task responseObject:responseObject success:success failure:failure];
    } failure:^(NSURLSessionDataTask * task, NSError * error) {
        [XYHttpRequest handerResponseFail:task err:error fail:failure];
    }];
    XYRequestModel *request = [XYRequestModel newWithTask:task];
    return request;
}

#pragma mark - POST上传
+ (XYRequestModel *)POST:(NSString *)url params:(id)params uploadParam:(NSDictionary *)uploadParam success:(void (^)(XYResponseModel *))success failure:(void (^)(XYResponseModel *))failure{
    return [self POST:url params:params uploadParam:uploadParam progress:nil success:success failure:failure];
}

+ (XYRequestModel *)POST:(NSString *)url params:(id)params uploadParam:(NSDictionary *)uploadParam progress:(void (^)(NSProgress *))progress success:(void (^)(XYResponseModel *))success failure:(void (^)(XYResponseModel *))failure{
    return  [self POST:url responseType:[[XYHttpRequestProtocol  regisclass]defaultResponseType] params:params uploadParam:uploadParam progress:progress success:success failure:failure];
}


+(XYRequestModel *)POST:(NSString  *)url responseType:(XYResponseType)responseType params:(id)params uploadParam:(NSDictionary *)uploadParam progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    return [self POST:url requestType:[[XYHttpRequestProtocol  regisclass] defaultRequestType] responseType:responseType params:params uploadParam:uploadParam progress:progress success:success failure:failure];
}

+ (XYRequestModel *)POST:(NSString *)url requestType:(XYRequestType)requestType responseType:(XYResponseType)responseType params:(id)params uploadParam:(NSDictionary *)uploadParam progress:(void (^)(NSProgress *))progress success:(void (^)(XYResponseModel *))success failure:(void (^)(XYResponseModel *))failure{
    return [self POST:url requestType:requestType responseType:responseType params:params uploadParam:uploadParam fileType:@"image/jpg" fileSuffix:@"jpg" progress:progress success:success failure:failure];
}

+ (XYRequestModel *)POST:(NSString *)url requestType:(XYRequestType)requestType responseType:(XYResponseType)responseType params:(id)params uploadParam:(NSDictionary *)uploadParam fileType:(NSString *)fileType fileSuffix:(NSString *)fileSuffix progress:(void (^)(NSProgress *))progress success:(void (^)(XYResponseModel *))success failure:(void (^)(XYResponseModel *))failure{
    NSString *tipsErr  = nil;
    if (![[XYHttpRequestProtocol regisclass] checkParams:params err:&tipsErr]) {
        XYResponseModel *responseModel = [XYResponseModel new];
        responseModel.tipMsg = tipsErr;
        failure(responseModel);
        return nil;
    }
    
    AFHTTPResponseSerializer *httpResponse = [self getResponseSerializer:responseType];
    AFHTTPSessionManager *manager = [self manager];
    manager.responseSerializer = httpResponse;
    manager.requestSerializer = [self getRequestSerializer:requestType];
    NSString *requestUrl = [self requestUrl:url];
    NSDictionary *requestParams = [self requestParams:params];
    
    NSURLSessionDataTask *task = [manager POST:requestUrl parameters:requestParams constructingBodyWithBlock:^(id<AFMultipartFormData>  formData) {
        for (NSString *key in uploadParam.allKeys) {
            id object = uploadParam[key];
            if ([object isKindOfClass:[NSData class]]) {
                [formData appendPartWithFileData:uploadParam[key] name:key fileName:[NSString stringWithFormat:@"%@.%@",key,fileSuffix] mimeType:fileType];
                
            }else if ([object isKindOfClass:[NSArray class]]){
                for (id data in (NSArray *)object) {
                    [formData appendPartWithFileData:data name:key fileName:[NSString stringWithFormat:@"%li.%@",[data hash],fileSuffix] mimeType:fileType];
                }
            }
            
            
        }
    } progress:progress success:^(NSURLSessionDataTask * task, id responseObject) {
        [XYHttpRequest handerResponseSucc:task responseObject:responseObject success:success failure:failure];
    } failure:^(NSURLSessionDataTask * task, NSError * error) {
        [XYHttpRequest handerResponseFail:task err:error fail:failure];
    }];
    XYRequestModel *request = [XYRequestModel newWithTask:task];
    return request;
}

#pragma mark - GET
+ (XYRequestModel *)GET:(NSString  *)url params:(NSDictionary * )params success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    return [self GET:url params:params progress:nil success:success failure:failure];
}


+ (XYRequestModel *)GET:(NSString  *)url params:(NSDictionary * )params progress:(void (^)(NSProgress * uploadProgress))progress success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    return [self GET:url responseType:[[XYHttpRequestProtocol  regisclass]defaultResponseType] params:params progress:progress success:success failure:failure];
}


+ (XYRequestModel *)GET:(NSString  *)url responseType:(XYResponseType)responseType params:(NSDictionary * )params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    return [self GET:url requestType:[[XYHttpRequestProtocol  regisclass] defaultRequestType] responseType:responseType params:params progress:progress success:success failure:failure];
}

+ (XYRequestModel *)GET:(NSString  *)url requestType:(XYRequestType)requestType responseType:(XYResponseType)responseType params:(NSDictionary * )params progress:(void (^)(NSProgress * uploadProgress))progress   success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    NSString *tipsErr  = nil;
    if (![[XYHttpRequestProtocol regisclass] checkParams:params err:&tipsErr]) {
        XYResponseModel *responseModel = [XYResponseModel new];
        responseModel.tipMsg = tipsErr;
        failure(responseModel);
        return nil;
    }
    
    AFHTTPResponseSerializer *httpResponse = [self getResponseSerializer:responseType];
    AFHTTPSessionManager *manager = [self manager];
    manager.responseSerializer = httpResponse;
    manager.requestSerializer = [self getRequestSerializer:requestType];
    NSString *requestUrl = [self requestUrl:url];
    NSDictionary *requestParams = [self requestParams:params];
    NSURLSessionDataTask *task = [manager GET:requestUrl parameters:requestParams progress:progress success:^(NSURLSessionDataTask * task, id  responseObject) {
        [XYHttpRequest handerResponseSucc:task responseObject:responseObject success:success failure:failure];
    } failure:^(NSURLSessionDataTask * task, NSError * error) {
        [XYHttpRequest handerResponseFail:task err:error fail:failure];
    }];
    XYRequestModel *request = [XYRequestModel newWithTask:task];
    return request;
}

+ (AFHTTPResponseSerializer *)getResponseSerializer:(XYResponseType)responsetype{
    AFHTTPResponseSerializer *responseSerializer = [[AFHTTPResponseSerializer alloc]init];
    switch (responsetype) {
        case XYResponseType_XML:
            responseSerializer = [[AFXMLParserResponseSerializer alloc]init];
            break;
        case XYResponseType_Json:
            responseSerializer = [[AFJSONResponseSerializer alloc]init];
            break;
        case XYResponseType_Data:
            responseSerializer = [[AFHTTPResponseSerializer alloc]init];
            break;
        default:
            responseSerializer = [[AFHTTPResponseSerializer alloc]init];
            break;
    }
    responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript",@"text/html",@"text/plain", nil];
    return responseSerializer;
}

+ (AFHTTPRequestSerializer *)getRequestSerializer:(XYRequestType)requestType{
    AFHTTPRequestSerializer *request = [AFHTTPRequestSerializer serializer];
    switch (requestType) {
        case XYRequestType_Normal:
            request = [AFHTTPRequestSerializer serializer];
            break;
        case XYRequestType_Json:
            request = [AFJSONRequestSerializer serializer];
            break;
        case XYRequestType_PropertyList:
            request = [AFPropertyListRequestSerializer serializer];
            break;
            
        default:
            break;
    }
    request.timeoutInterval = 30;
    NSDictionary *httpHeader = [[XYHttpRequestProtocol  regisclass] httpHeaderConfig];
    for (NSString *key in httpHeader.allKeys) {
        [request setValue:httpHeader[key] forHTTPHeaderField:key];
    }
    return request;
}

#pragma mark - response处理
+ (void)handerResponseSucc:(NSURLSessionDataTask *) task responseObject: (id )responseObject success:(void(^)( XYResponseModel * responseModel))success failure:(void(^)( XYResponseModel *  responseModel))failure{
    
    [XYHttpCookieManage saveCookieWithHost:task.currentRequest.URL.host];
    [XYHttpCookieManage setCookieWithHost:task.currentRequest.URL.host];
    
    id baseModel = [[XYHttpRequestProtocol regisclass] handelResponseObject:responseObject];
    XYResponseModel *responseModel = [XYResponseModel newWithTask:task baseModel:baseModel];
    ///公共输出处理
    [XYHttpRequest publicOutParam:baseModel];
    if ([[XYHttpRequestProtocol regisclass]  checkRequestSucc:&responseModel]) {
        success(responseModel);
        return;
    }
    failure(responseModel);
}

+ (void)handerResponseFail:(NSURLSessionDataTask *) task err: (NSError * )err fail:(void(^)( XYResponseModel *  responseModel))failure{
    [XYHttpCookieManage saveCookieWithHost:task.currentRequest.URL.host];
    [XYHttpCookieManage setCookieWithHost:task.currentRequest.URL.host];
    XYResponseModel *responseModel = [XYResponseModel newWithTask:task err:err];
    if ([task.response isKindOfClass:[NSHTTPURLResponse class]]) {
        NSHTTPURLResponse *response =  (NSHTTPURLResponse *)task.response;
        responseModel.tipMsg = [NSString stringWithFormat:@"%li",response.statusCode];
    }else{
        responseModel.tipMsg = @"网络异常";
    }
    [[XYHttpRequestProtocol regisclass] handleFail:&responseModel];
    failure(responseModel);
}

@end
