//
//  XYCollectionView.m
//  XYUIKit
//
//  Created by henry on 2018/1/4.
//

#import "XYCollectionView.h"

@implementation XYCollectionView

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return [self required:otherGestureRecognizer];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRequireFailureOfGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return [self required:otherGestureRecognizer];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldBeRequiredToFailByGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return [self required:otherGestureRecognizer];
}

-(BOOL)required:(UIGestureRecognizer *)otherGestureRecognizer{
    if(self.contentOffset.x) {
        return NO;
    }
    
    if([otherGestureRecognizer isKindOfClass:[UIScreenEdgePanGestureRecognizer class]])
    {
        return YES;
    }
    return NO;
}

- (BOOL)delaysContentTouches{
    return NO;
}

@end
