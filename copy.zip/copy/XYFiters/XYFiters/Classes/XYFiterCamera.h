//
//  XYFiterCamera.h
//  XYFiters
//
//  Created by henry on 2018/11/21.
//

#import <AVFoundation/AVFoundation.h>
@class GPUImageView;
NS_ASSUME_NONNULL_BEGIN
typedef enum {
    XY_NONE_FILTER = -1,//初始状态
    XY_NORMAL_FILTER = 0,//正常
    XY_AMARO_FILTER = 1,
    XY_RISE_FILTER = 2,
    XY_HUDSON_FILTER = 3,
    XY_XPROII_FILTER = 4,
    XY_SIERRA_FILTER = 5,
    XY_LOMOFI_FILTER = 6,
    XY_EARLYBIRD_FILTER = 7,
    XY_SUTRO_FILTER = 8,
    XY_TOASTER_FILTER = 9,
    XY_BRANNAN_FILTER = 10,
    XY_INKWELL_FILTER = 11,
    XY_WALDEN_FILTER = 12,
    XY_HEFE_FILTER = 13,
    XY_VALENCIA_FILTER = 14,
    XY_NASHVILLE_FILTER = 15,
    XY_1977_FILTER = 16,
    XY_LORDKELVIN_FILTER = 17,
    
} XYFilterType;

@protocol XYFiterCameraDelegate <NSObject>
@optional

/**
 视频帧输出的缓冲区和时间戳

 @param bufferRef 缓冲区
 @param ts 时间戳
 */
- (void)willOutputPixBufferRef:(CVPixelBufferRef)bufferRef ts:(int64_t)ts;
@end

@interface XYFiterCamera : NSObject

/**
 协议
 */
@property (nonatomic,weak) id<XYFiterCameraDelegate> delegate;

/**
 分辨率
 */
@property (nonatomic,assign) AVCaptureSessionPreset preset;

/**
 摄像头位置
 */
@property (nonatomic,assign) AVCaptureDevicePosition position;

/**
 滤镜类型
 */
@property (nonatomic,assign) XYFilterType filterType;

/**
 显示层
 */
@property (nonatomic,strong) GPUImageView *imgView;

/**
 滤镜map
 */
@property (nonatomic,strong) NSDictionary *filterMap;
@end

NS_ASSUME_NONNULL_END
