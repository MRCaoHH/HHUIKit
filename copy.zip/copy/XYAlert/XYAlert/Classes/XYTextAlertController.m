//
//  XYTextAlertController.m
//  XYAlert
//
//  Created by henry on 2017/12/29.
//

#import "XYTextAlertController.h"
#import <XYCategory/XYCategory.h>

@interface XYTextAlertController ()

@end

@implementation XYTextAlertController
static CGFloat kMessageFontSize = 14;
static CGFloat kMessageWidth = 270;
static NSString *kMessageTextColorHexString = @"#666666";

- (instancetype)initWithTitle:(NSString *)title message:(NSString *)message cancelTitle:(NSString *)cancelTitle okTitle:(NSString *)okTitle{
    self = [super initWithTitle:title cancelTitle:cancelTitle okTitle:okTitle];
    if (self) {
        self.messageLabel.text = message;
        CGSize size = [self.messageLabel sizeThatFits:CGSizeMake(kMessageWidth, MAXFLOAT)];
        self.messageLabel.xy_size = size;
    }
    return self;
    
}

- (UIView *)contentView{
    return self.messageLabel;
}

-(UILabel *)messageLabel{
    if (_messageLabel == nil) {
        _messageLabel = [UILabel new];
        _messageLabel.textColor = [UIColor xy_colorWithHexString:kMessageTextColorHexString];
        _messageLabel.font = [UIFont systemFontOfSize:kMessageFontSize];
        _messageLabel.numberOfLines = 0;
    }
    return _messageLabel;
}

@end
