//
//  XYChatFooterProtocol.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import <Foundation/Foundation.h>
@protocol XYChatFooterDelegate;
@class XYChatVC;
@protocol XYChatFooterProtocol <NSObject>
@required

/**
 协议
 */
@property (nonatomic,weak) id<XYChatFooterDelegate> footerDelegate;

/**
 聊天控制器
 */
@property (nonatomic,weak) XYChatVC *chatVC;

/**
 是否展开
 */
@property (nonatomic,assign,readonly) BOOL isExpand;

/**
 消息列表拖拽 隐藏展开内容
 */
- (void)dragTableView;
@end
