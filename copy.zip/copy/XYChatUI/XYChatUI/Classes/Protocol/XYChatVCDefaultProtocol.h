//
//  XYChatVCDefaultProtocol.h
//  XYChatUI
//
//  Created by henry on 2017/11/15.
//

#import <Foundation/Foundation.h>
#import "XYChatVCProtocol.h"
@interface XYChatVCDefaultProtocol : NSObject<XYChatVCProtocol>

@end
