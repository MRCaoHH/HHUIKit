#!/usr/bin/python
# -*- coding:utf-8 -*-
import requests
import json
import re
import urllib
import sys
import getopt

reload(sys)
sys.setdefaultencoding('utf8')

__host = "http://pods.xy.com:3000/api/v4"

def createGit(token,projectName,desc):
	'''
	token:身份令牌
	projectName:项目名称，这里项目名称和path是相同的
	desc:项目描述
	'''
	body = {"namespace_id":4,"private_token":token,"description":desc,"name":projectName,"path":projectName,"visibility_level":"20"}
	bodyStr = json.dumps(body)
	url = __host+"/projects"
	headers = {"Content-Type":"application/json"}
	r = requests.post(url=url,data=bodyStr,headers=headers,allow_redirects=False)
	return r.status_code
	pass

if __name__=='__main__':
    opts, args = getopt.getopt(sys.argv[1:], "t:n:d:",["rp="])
    token=""
    projectName=""
    desc=""
    # print opts
    for op, value in opts:
        if op == "-t":
            token=value
            pass
        elif op == "-n":
            projectName = value
            pass
        elif op == "-d":
            desc=value
            pass
        pass

    if len(token) == 0:
    	print "请输入token\n"
    	sys.exit()
    	pass
    if len(projectName) == 0:
    	print "项目名称不能为空.\n"
    	sys.exit()
    	pass
    if len(desc) == 0:
    	desc = projectName
    	pass
    res =  createGit(token,projectName,desc)
    print res
