# XYHUD

[![CI Status](http://img.shields.io/travis/henry/XYHUD.svg?style=flat)](https://travis-ci.org/henry/XYHUD)
[![Version](https://img.shields.io/cocoapods/v/XYHUD.svg?style=flat)](http://cocoapods.org/pods/XYHUD)
[![License](https://img.shields.io/cocoapods/l/XYHUD.svg?style=flat)](http://cocoapods.org/pods/XYHUD)
[![Platform](https://img.shields.io/cocoapods/p/XYHUD.svg?style=flat)](http://cocoapods.org/pods/XYHUD)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XYHUD is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'XYHUD'
```

## Author

henry, henry@xy.com

## License

XYHUD is available under the MIT license. See the LICENSE file for more info.
