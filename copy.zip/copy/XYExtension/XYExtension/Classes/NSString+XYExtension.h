//
//  NSString+XYExtension.h
//  XYExtension
//
//  Created by henry on 2018/1/26.
//

#import <Foundation/Foundation.h>

@interface NSString (XYExtension)
/**
 *  驼峰转下划线（loveYou -> love_you）
 */
- (NSString *)xy_underlineFromCamel;
/**
 *  下划线转驼峰（love_you -> loveYou）
 */
- (NSString *)xy_camelFromUnderline;
/**
 * 首字母变大写
 */
- (NSString *)xy_firstCharUpper;
/**
 * 首字母变小写
 */
- (NSString *)xy_firstCharLower;

- (BOOL)xy_isPureInt;

- (NSURL *)xy_url;
@end
