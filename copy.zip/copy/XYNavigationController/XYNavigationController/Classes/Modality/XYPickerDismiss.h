//
//  XYPickerDismiss.h
//  XYNavigationController
//
//  Created by henry on 2017/12/23.
//

#import <Foundation/Foundation.h>

@interface XYPickerDismiss : NSObject<UIViewControllerAnimatedTransitioning>

/**
 动画执行时间
 */
@property (nonatomic,assign) NSTimeInterval duration;

@end
