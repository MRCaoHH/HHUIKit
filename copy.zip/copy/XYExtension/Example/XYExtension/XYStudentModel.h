//
//  XYStudentModel.h
//  XYExtension
//
//  Created by henry on 2017/10/26.
//  Copyright © 2017年 henry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYSexModel : NSObject

@property (nonatomic,assign) int value;
@property (nonatomic,copy) NSString *name;

@end

@interface XYStudentModel : NSObject

@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *intro;
@property (nonatomic,assign) int  age;
@property (nonatomic,strong) XYSexModel *sex;

@end
