//
//  XYRequestModel.m
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import "XYRequestModel.h"

@implementation XYRequestModel
+ (XYRequestModel *)newWithTask:(id)task{
    XYRequestModel * model = [[XYRequestModel alloc]init];
    model.task = task;
    return  model;
}
    
- (BOOL)isFinish{
    NSURLSessionDataTask *task = self.task;
    return task.state == NSURLSessionTaskStateCompleted;
}
    
- (void)cancel{
    NSURLSessionDataTask *task = self.task;
    [task cancel];
}
@end
