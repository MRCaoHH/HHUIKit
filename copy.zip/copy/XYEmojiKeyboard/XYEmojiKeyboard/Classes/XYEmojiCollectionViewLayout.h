//
//  XYEmojiCollectionViewLayout.h
//  Pods-XYEmojiKeyboard_Example
//
//  Created by henry on 2017/11/15.
//

#import <UIKit/UIKit.h>
static NSInteger kEmojiColumnCount = 7;
static NSInteger kEmojiRowCount = 3;
@interface XYEmojiCollectionViewLayout : UICollectionViewFlowLayout

@end
