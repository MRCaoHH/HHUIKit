//
//  XYBTTextCell.m
//  Pods-XYUIKit_Example
//
//  Created by henry on 2017/11/22.
//

#import "XYBTTextCell.h"
#import <XYCategory/XYCategory.h>

@implementation XYBTTextCell
- (void)layoutSubviews{
    [super layoutSubviews];
    self.titleLabel.font = [UIFont systemFontOfSize:self.fontSize];
    self.titleLabel.textColor = [UIColor xy_colorWithHexString:self.titleColor];
    
    self.noteLabel.font = [UIFont systemFontOfSize:self.fontSize];
    self.noteLabel.textColor = [UIColor xy_colorWithHexString:self.noteTitleColor];
    
    [self.titleLabel sizeToFit];
    self.titleLabel.xy_centerY = self.contentView.xy_centerY;
    self.titleLabel.xy_x = self.edgeDistance;
    
    if (self.noteLabel.text == nil) {
        self.noteLabel.text = self.noteDefaultText;
    }
    [self.noteLabel sizeToFit];
    CGFloat maxWidth = self.contentView.frame.size.width - self.titleLabel.xy_width - self.edgeDistance - self.edgeDistance - self.edgeDistance;
    if (self.noteLabel.xy_width > maxWidth) {
        self.noteLabel.xy_width = maxWidth;
    }
    self.noteLabel.xy_centerY = self.contentView.xy_centerY;
    self.noteLabel.xy_right = self.contentView.xy_right - self.edgeDistance;
}

#pragma mark - 属性方法 -
- (UILabel *)titleLabel{
    if(_titleLabel == nil){
        _titleLabel = [[UILabel alloc]init];
        _titleLabel.font = [UIFont systemFontOfSize:self.fontSize];
        _titleLabel.textColor = [UIColor xy_colorWithHexString:self.titleColor];
        [self.contentView addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (UILabel *)noteLabel{
    if(_noteLabel == nil){
        _noteLabel = [[UILabel alloc]init];
        _noteLabel.font = [UIFont systemFontOfSize:self.fontSize];
        _noteLabel.textColor = [UIColor xy_colorWithHexString:self.noteTitleColor];
        [self.contentView addSubview:_noteLabel];
    }
    return _noteLabel;
}

- (NSString *)noteDefaultText{
    if (_noteDefaultText == nil) {
        _noteDefaultText =  @"请输入";
    }
    return _noteDefaultText;
}

- (void)setTitle:(NSString *)title{
    _title = title;
    self.titleLabel.text = _title;
}

- (CGFloat)edgeDistance{
    if (_edgeDistance == 0) {
        _edgeDistance = 12;
    }
    return _edgeDistance;
}


- (CGFloat)fontSize{
    if (_fontSize == 0) {
        _fontSize = 13;
    }
    return _fontSize;
}

- (NSString *)titleColor{
    if (_titleColor == nil) {
        _titleColor = @"#000000";
    }
    return _titleColor;
}


- (NSString *)noteTitleColor{
    if (_noteTitleColor == nil) {
        _noteTitleColor = @"#000000";
    }
    return _noteTitleColor;
}
@end
