//
//  XYChatHeaderProtocol.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import <UIKit/UIKit.h>
@protocol XYChatHeaderDelegate;
@class XYChatVC;
@protocol XYChatHeaderProtocol <NSObject>
@required
@property (nonatomic,weak) id<XYChatHeaderDelegate> headerDelegate;
@property (nonatomic,weak) XYChatVC *chatVC;

@optional

@end
