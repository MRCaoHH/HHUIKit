//
//  XYChatVCProtocol.h
//  XYChatUI
//
//  Created by henry on 2017/11/15.
//

#import <UIKit/UIKit.h>
#import "XYChatFooterProtocol.h"
#import "XYChatHeaderProtocol.h"
#import "XYChatVC.h"

@class XYChatPlusItem;
@protocol XYChatVCProtocol <NSObject>
@required
/**
 消息列表
 */
@property (nonatomic,strong) NSMutableArray *msgArr;

/**
 聊天视图控制器
 */
@property (nonatomic,weak) XYChatVC *chatVC;

/**
 联系人模型
 */
@property (nonatomic,strong) XYChatContactModel *contactModel;

/**
 脚部视图

 @return 视图
 */
- (UIView <XYChatFooterProtocol>*)footerView;

/**
 头部视图

 @return 视图
 */
- (UIView <XYChatHeaderProtocol>*)headerView;

/**
 选中附加功能item

 @param item 附加功能item
 */
- (void)selectPlusItem:(XYChatPlusItem *)item;

/**
 发送消息

 @param msg 消息
 */
- (void)sendMsg:(id)msg;

/**
 得到cell总数

 @param tableView 列表
 @return 总数
 */
- (NSInteger)getCellCountWithTableView:(UITableView *)tableView;

/**
 获取cell

 @param tableView 列表
 @param indexPath 下标
 @return cell
 */
- (UITableViewCell *)getCellWithTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath;


/**
 得到cell的高度

 @param tableView 列表
 @param indexPath 下标
 @return 高度
 */
- (CGFloat)getCellHeightWithTableView:(UITableView *)tableView indexPath:(NSIndexPath *)indexPath;

/**
 加载更多

 @param complete 完成回调
 */
- (void)loadMore:(void(^)(void))complete;

/**
 进入房间
 */
- (void)enterRoom;

/**
 离开房间
 */
- (void)leaveRoom;
@end
