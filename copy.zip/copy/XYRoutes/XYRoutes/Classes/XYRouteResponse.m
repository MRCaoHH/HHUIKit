//
//  XYRouteResponse.m
//  Pods
//
//  Created by henry on 2017/10/27.
//

#import "XYRouteResponse.h"

@implementation XYRouteResponse

- (void)actionRoute{
    _routeHandelEvent(_url.absoluteString,_params);
}


@end
