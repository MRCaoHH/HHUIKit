//
//  XYAlertController.m
//  XYAlert
//
//  Created by henry on 2017/12/29.
//

#import "XYAlertController.h"
#import <XYNavigationController/XYAlertPresent.h>
#import <XYNavigationController/XYAlertDismiss.h>
#import <XYCategory/XYCategory.h>
#import <YYText/YYText.h>

@interface XYAlertController ()<UIViewControllerTransitioningDelegate>{
    NSString *_title;
    NSString *_cancelTitle;
    NSString *_okTitle;
    CGSize _titleSize;
    NSAttributedString *_attributedStringTitle;
}

@end

@implementation XYAlertController
static CGFloat kAlertWidth = 294;
static CGFloat kAlertCornerRadius = 10;

static CGFloat kEdge = 12;
static CGFloat kTitleToTop = 19;
static CGFloat kTitleWidth = 270;
static CGFloat kTitleFontSize = 16;

static CGFloat kBtnToContent = 22;
static CGFloat kBtnWidth = 115;
static CGFloat kBtnTitleFontSize = 14;
static CGFloat kBtnHeight = 37;

static CGFloat kContentToTitle = 17;

static CGFloat kSubviewCornerRadius = 3;

static NSString *kTitleTextColorHexString = @"#333333";
static NSString *kThemeColorHexString = @"#FFB901";
static NSString *kWhiteColorHexString = @"#FFFFFF";
static NSString *kCancelBtnBgColorHexString = @"#D8D8D8";

- (instancetype)initWithTitle:(NSString *)title cancelTitle:(NSString *)cancelTitle okTitle:(NSString *)okTitle{
    self = [super init];
    if (self) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
        _title = title;
        _cancelTitle = cancelTitle;
        _okTitle = okTitle;
    }
    return self;
}

- (instancetype)initWithTitle:(NSString *)title okTitle:(NSString *)okTitle{
    return [self initWithTitle:title cancelTitle:nil okTitle:okTitle];
}

- (instancetype)initWithAttributedString:(NSAttributedString *)title cancelTitle:(NSString *)cancelTitle okTitle:(NSString *)okTitle{
    self = [super init];
    if (self) {
        self.transitioningDelegate = self;
        self.modalPresentationStyle = UIModalPresentationCustom;
        _attributedStringTitle = title;
        _cancelTitle = cancelTitle;
        _okTitle = okTitle;
    }
    return self;
}


- (instancetype)initWithAttributedString:(NSAttributedString *)title okTitle:(NSString *)okTitle{
    return [self initWithAttributedString:title cancelTitle:nil okTitle:okTitle];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initSubview];
}

#pragma mark - 初始化 -
- (void)initSubview{
    self.view.backgroundColor = [UIColor xy_colorWithHexString:kWhiteColorHexString];
    self.view.layer.cornerRadius = kAlertCornerRadius;
    self.view.layer.masksToBounds = YES;
    
    _titleLabel = [[YYLabel alloc]initWithFrame:CGRectMake((kAlertWidth - _titleSize.width)/2, kTitleToTop, _titleSize.width, _titleSize.height)];
    _titleLabel.font = [UIFont systemFontOfSize:kTitleFontSize];
    if (_title) {
        _titleLabel.text = _title;
        
    }
    _titleLabel.textColor = [UIColor xy_colorWithHexString:kTitleTextColorHexString];
    _titleLabel.numberOfLines = 0;
    if (_attributedStringTitle) {
        _titleLabel.attributedText = _attributedStringTitle;
    }
    [self.view addSubview:_titleLabel];
    
    CGFloat btnToContent = CGRectGetMaxY(_titleLabel.frame) + kContentToTitle;
    if (self.contentView) {
        btnToContent = kBtnToContent;
        self.contentView.frame = CGRectMake((kAlertWidth - self.contentView.xy_width)/2,CGRectGetMaxY(_titleLabel.frame) + kContentToTitle , kAlertWidth -kEdge  - kEdge , self.contentView.frame.size.height);
        [self.view addSubview:self.contentView];
    }
    
    if (_cancelTitle) {
        _cancelButton = [[UIButton alloc]initWithFrame:CGRectMake(kEdge, CGRectGetMaxY(self.contentView.frame) + btnToContent, kBtnWidth, kBtnHeight)];
        [_cancelButton setBackgroundImage:[UIImage xy_createImageFromColor:[UIColor xy_colorWithHexString:kCancelBtnBgColorHexString]] forState:UIControlStateNormal];
        [_cancelButton setTitle:_cancelTitle forState:UIControlStateNormal];
        [_cancelButton addTarget:self action:@selector(clickCancelButtonEvent) forControlEvents:UIControlEventTouchUpInside];
        _cancelButton.layer.cornerRadius = kSubviewCornerRadius;
        _cancelButton.titleLabel.font = [UIFont systemFontOfSize:kBtnTitleFontSize];
        _cancelButton.layer.masksToBounds = YES;
        [self.view addSubview:_cancelButton];
    }
    
    CGFloat x = _cancelTitle ? kAlertWidth - kBtnWidth -kEdge: (kAlertWidth - kBtnWidth)/2;
    _okButton = [[UIButton alloc]initWithFrame:CGRectMake(x, CGRectGetMaxY(self.contentView.frame) + btnToContent, kBtnWidth, kBtnHeight)];
    [_okButton setBackgroundImage:[UIImage xy_createImageFromColor:[UIColor xy_colorWithHexString:kThemeColorHexString]] forState:UIControlStateNormal];
    [_okButton addTarget:self action:@selector(clickOkButtonEvent) forControlEvents:UIControlEventTouchUpInside];
    [_okButton setTitle:_okTitle forState:UIControlStateNormal];
    _okButton.layer.cornerRadius = kSubviewCornerRadius;
    _okButton.titleLabel.font = [UIFont systemFontOfSize:kBtnTitleFontSize];
    _okButton.layer.masksToBounds = YES;
    [self.view addSubview:_okButton];
}

#pragma mark - 交互 -
- (void)clickCancelButtonEvent{
    [self.view endEditing:YES];
    if (self.clickCancelButtonCallback) {
        self.clickCancelButtonCallback(self);
    }
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

- (void)clickOkButtonEvent{
    [self.view endEditing:YES];
    if (self.clickOkButtonCallback) {
        self.clickOkButtonCallback(self);
    }
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

#pragma mark - UIViewControllerTransitioningDelegate -
- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForPresentedController:(UIViewController *)presented presentingController:(UIViewController *)presenting sourceController:(UIViewController *)source{
    return ({
        XYAlertPresent *present =  [XYAlertPresent new];
        present.viewSize = CGSizeMake(kAlertWidth, self.contentHeight);
        present;
    });
}

- (nullable id <UIViewControllerAnimatedTransitioning>)animationControllerForDismissedController:(UIViewController *)dismissed{
    return ({
        XYAlertDismiss *dismiss =  [XYAlertDismiss new];
        dismiss.type = XYAlertDismissAnimateType_Fall;
        dismiss;
    });
}


#pragma mark - 属性方法 -
- (CGFloat)contentHeight{
    if (_contentHeight == 0) {
        _titleSize =  ({
            CGSize size = CGSizeZero;
            if (_title) {
                YYLabel *label = [[YYLabel alloc]init];
                label.font = [UIFont systemFontOfSize:kTitleFontSize];
                label.numberOfLines = 0;
                label.text = _title;
                size = [label sizeThatFits:CGSizeMake(kTitleWidth, MAXFLOAT)];;
            }
            if (_attributedStringTitle) {
                //                size = [_attributedStringTitle boundingRectWithSize:CGSizeMake(kTitleWidth, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin context:NULL].size;
                YYLabel *label = [[YYLabel alloc]init];
                label.font = [UIFont systemFontOfSize:kTitleFontSize];
                [label sizeThatFits:CGSizeMake(kTitleWidth, MAXFLOAT)];
                label.attributedText = _attributedStringTitle;
                label.numberOfLines = 0;
                size = [label sizeThatFits:CGSizeMake(kTitleWidth, MAXFLOAT)];;
            }
            size;
        });
        CGFloat contentToBtn = self.contentView ? kBtnToContent:0;
        _contentHeight = _titleSize.height + kTitleToTop + self.contentView.xy_height + kBtnHeight + contentToBtn + kTitleToTop + kContentToTitle;
    }
    return _contentHeight;
}
@end
