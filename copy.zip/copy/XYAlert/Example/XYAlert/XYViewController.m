//
//  XYViewController.m
//  XYAlert
//
//  Created by Henry on 12/14/2017.
//  Copyright (c) 2017 Henry. All rights reserved.
//

#import "XYViewController.h"
#import <XYAlert/XYAlert.h>
#import <YYText/YYText.h>

@interface XYViewController ()

@end

@implementation XYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    UIButton *textFieldBtn = [[UIButton alloc]initWithFrame:CGRectMake(20,CGRectGetMaxY([UIApplication sharedApplication].statusBarFrame), [UIScreen mainScreen].bounds.size.width - 40,44)];
    textFieldBtn.backgroundColor = [UIColor magentaColor];
    [textFieldBtn addTarget:self action:@selector(clickTextFieldBtn) forControlEvents:UIControlEventTouchUpInside];
    [textFieldBtn setTitle:@"TEXT FIELD ALERT" forState:UIControlStateNormal];
    [self.view addSubview:textFieldBtn];
    
    UIButton *alertBtn = [[UIButton alloc]initWithFrame:CGRectMake(20,CGRectGetMaxY(textFieldBtn.frame), [UIScreen mainScreen].bounds.size.width - 40,44)];
    alertBtn.backgroundColor = [UIColor blueColor];
    [alertBtn addTarget:self action:@selector(clickAlertBtn) forControlEvents:UIControlEventTouchUpInside];
    [alertBtn setTitle:@"ALERT" forState:UIControlStateNormal];
    [self.view addSubview:alertBtn];
    
    UIButton *textBtn = [[UIButton alloc]initWithFrame:CGRectMake(20,CGRectGetMaxY(alertBtn.frame), [UIScreen mainScreen].bounds.size.width - 40,44)];
    textBtn.backgroundColor = [UIColor darkGrayColor];
    [textBtn addTarget:self action:@selector(clickTextBtn) forControlEvents:UIControlEventTouchUpInside];
    [textBtn setTitle:@"TEXT ALERT" forState:UIControlStateNormal];
    [self.view addSubview:textBtn];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)clickTextFieldBtn{
    XYTextFieldAlertController *vc = [[XYTextFieldAlertController alloc]initWithTitle:@"标题" cancelTitle:@"取消" okTitle:@"确定"];
   
    [vc setClickOkButtonCallback:^(XYAlertController *alertVC) {
        XYTextFieldAlertController *textFieldVC = (XYTextFieldAlertController *)alertVC;
        NSLog(@"%@",textFieldVC.textField.text);
    }];
    
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)clickAlertBtn{
     XYAlertController *vc = [[XYAlertController alloc]initWithAttributedString:[self attString] cancelTitle:@"取消" okTitle:@"确定"];
//    XYAlertController *vc = [[XYAlertController alloc]initWithTitle:@"标题" cancelTitle:@"取消" okTitle:@"确定"];
    [vc setClickOkButtonCallback:^(XYAlertController *alertVC) {
        
    }];
    [self presentViewController:vc animated:YES completion:nil];
}

- (void)clickTextBtn{
    XYTextAlertController *vc = [[XYTextAlertController alloc]initWithTitle:@"和乐天春词" message:@"新妆宜面下朱楼\n深锁春光一院愁\n行到中庭数花朵\n蜻蜓飞上玉搔头" cancelTitle:@"取消" okTitle:@"确定"];
    [vc setClickOkButtonCallback:^(XYAlertController *alertVC) {
        
    }];
    [self presentViewController:vc animated:YES completion:nil];
}

- (NSAttributedString *)attString{
    UIImage *img = [UIImage imageNamed:@"weix"];
    NSMutableAttributedString *attchImg = [NSMutableAttributedString yy_attachmentStringWithContent:img contentMode:UIViewContentModeCenter attachmentSize:img.size alignToFont:[UIFont systemFontOfSize:13] alignment:YYTextVerticalAlignmentCenter];
    [attchImg appendAttributedString: ({
        NSAttributedString * att = [[NSAttributedString alloc]initWithString:@"和乐天春词\n新妆宜面下朱楼\n深锁春光一院愁\n行到中庭数花朵\n蜻蜓飞上玉搔头" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14],NSForegroundColorAttributeName:[UIColor blueColor]}];
        att;
    })];
    return attchImg;
}
@end
