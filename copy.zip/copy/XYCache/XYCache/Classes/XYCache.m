//
//  XYCache.m
//  XYLawyerPlatform
//
//  Created by caohuihui on 2017/10/27.
//  Copyright © 2016年 华海乐盈. All rights reserved.
//

#import "XYCache.h"
#import <TMCache/TMCache.h>

@implementation XYCache

+ (void)addCacheWithKey:(NSString *)key object:(id<NSCoding>)object{
    [[TMCache sharedCache]setObject:object forKey:[self handleKey:key]];
}

+ (void)removeCacaheWithKey:(NSString *)key{
    [[TMCache sharedCache] removeObjectForKey:[self handleKey:key]];
}

+ (id)cacheWithKey:(NSString *)key{
    id object = [[TMCache sharedCache] objectForKey:[self handleKey:key]];
    return object;
}

+ (NSString *)handleKey:(NSString *)key{
    return key;
}

+ (NSString *)saveCacheWithObject:(NSObject <NSCoding>*)object{
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wformat"
    NSString *keyString = [NSString stringWithFormat:@"%lu",[object hash]];
#pragma clang duagnostic pop
    [self addCacheWithKey:keyString object:object];
    return keyString;
}

@end
