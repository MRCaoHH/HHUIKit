//
//  XYChatPlusItem.m
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/16.
//

#import "XYChatPlusItem.h"
#import "XYChatSourceProtocol.h"
@implementation XYChatPlusItem

- (UIImage *)coverImg{
    if (_coverImg == nil) {
        _coverImg = [XYChatSourceProtocol imageWithName:_imgName];
    }
    return _coverImg;
}

@end
