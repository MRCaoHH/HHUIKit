//
//  XYChatBubbleCell.h
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import <UIKit/UIKit.h>
@class XYChatMsgBaseModel;
static CGFloat kChatBubbleLeftEdge = 5;
static CGFloat kChatBubbleTopEdge = 33;

static CGFloat kChatBubbleReceiveLeftEdge = 20;

static CGFloat kChatBubbleEdgeOffset = 8;
static CGFloat kChatLeaveBlankWidth = 100;

static CGFloat kChatContentArrowEdge = 20;
static CGFloat kChatContentOtheEdge = 7;

static NSString *kChatSendImageName = @"chat_bubble_send";
static NSString *kChatReceviveImageName = @"chat_bubble_receive";

@interface XYChatBubbleCell : UITableViewCell

/**
 气泡背景图片
 */
@property (nonatomic,strong) UIImageView *bubbleImgView;

/**
 重新发送按钮
 */
@property (nonatomic,strong) UIButton *resendButton;

/**
 发送的菊花
 */
@property (nonatomic,strong) UIActivityIndicatorView *loadingView;

/**
 是否发送方
 */
@property (nonatomic,assign) BOOL isSend;

/**
 图像模型
 */
@property (nonatomic,weak) XYChatMsgBaseModel *model;

/**
 重新发送
 */
@property (nonatomic,copy) void(^resendEvent) (XYChatMsgBaseModel *model);
/**
 初始化子视图，子类重写
 */
- (void)initSubview;

/**
 计算气泡的frame

 @param size 内容的size
 @param isSend 是否发送方
 @return 气泡的frame
 */
+ (CGRect)calBubbleFrameWithContentSize:(CGSize)size isSend:(BOOL)isSend;

/**
 得到cell高度

 @param bubbleFrame 气泡的frame
 @return cell高度
 */
+ (CGFloat)calCellHeightWithBubbleFrame:(CGRect)bubbleFrame;

@end
