//
//  XYArchiverTool.h
//  XYLawyerPlatform
//
//  Created by caohuihui on 2017/10/27.
//  Copyright © 2016年 华海乐盈. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYArchiverTool : NSObject


/**
 归档

 @param encoder 归档的NSCoder
 @param object 归档的对象
 */
+ (void)archiver:(NSCoder *)encoder object:(id)object;


/**
 归档

 @param encoder 归档的NSCoder
 @param object 归档的对象
 @param superArr 需要归档属性所在的父类数组
 */
+ (void)archiver:(NSCoder *)encoder object:(id)object superArr:(NSArray<NSString *>*)superArr;

/**
 归档
 
 @param encoder 归档的NSCoder
 @param object 归档的对象
 @param filter 不归档的属性
 */
+ (void)archiver:(NSCoder *)encoder object:(id)object filter:(NSArray *)filter;


/**
 归档

 @param encoder 归档的NSCoder
 @param object 归档的对象
 @param superArr 需要归档属性所在的父类数组
 @param filter 不归档的属性
 */
+ (void)archiver:(NSCoder *)encoder object:(id)object superArr:(NSArray<NSString *>*)superArr filter:(NSArray *)filter;


/**
 解档
 
 @param decoder 解档的NSCoder
 @param object 解档的对象
 */
+ (void)unarchiver:(NSCoder *)decoder object:(id)object;

/**
 解档
 
 @param decoder 解档的NSCoder
 @param object 解档的对象
 @param superArr 需要解档属性所在的父类数组
 */
+ (void)unarchiver:(NSCoder *)decoder object:(id)object superArr:(NSArray<NSString *>*)superArr;

/**
 解档
 
 @param decoder 解档的NSCoder
 @param object 解档的对象
 @param filter 不解档的属性
 */
+ (void)unarchiver:(NSCoder *)decoder object:(id)object filter:(NSArray *)filter;

/**
 解档

 @param decoder 解档的NSCoder
 @param object 解档的对象
 @param superArr 需要解档属性所在的父类数组
 @param filter 不解档的属性
 */
+ (void)unarchiver:(NSCoder *)decoder object:(id)object superArr:(NSArray<NSString *>*)superArr filter:(NSArray *)filter;
@end
