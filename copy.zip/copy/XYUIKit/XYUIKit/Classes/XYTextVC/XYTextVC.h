//
//  XYTextVC.h
//  MJExtension
//
//  Created by henry on 2017/11/22.
//

#import <UIKit/UIKit.h>

@interface XYTextVC : UIViewController

/**
 文本输入框
 */
@property (nonatomic,strong) UITextView *textView;

/**
 占位文字
 */
@property (nonatomic,copy) NSString *placeholder;

/**
 文本内容
 */
@property (nonatomic,copy) NSString *text;

/**
 文本输入框的高度
 */
@property (nonatomic,assign) CGFloat textViewHeight;

/**
 完成的回调
 */
@property (nonatomic,copy) void(^finishCallback) (XYTextVC *textVC,NSString *content);
@end
