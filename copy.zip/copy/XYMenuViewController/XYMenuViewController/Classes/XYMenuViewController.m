//
//  XYMenuViewController.m
//  TestOC
//
//  Created by henry on 2017/11/03.
//  Copyright © 2017年 caohuihui. All rights reserved.
//

#import "XYMenuViewController.h"

@interface XYMenuViewController ()

@end

@implementation XYMenuViewController

#pragma mark - 父类方法
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self initViewModel];
    [self initNavBar];
    [self initUI];
    [self initConstraint];
    [self addNotification];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)dealloc{
    [self removeNotification];
    [[NSNotificationCenter defaultCenter]removeObserver:self];
    NSLog(@"");
}

#pragma mark - 初始化导航栏
- (void)initViewModel{
    
}

- (void)initNavBar{
    
}

#pragma mark - 初始化UI
- (void)initUI{
    
}

#pragma mark - 初始化约束
- (void)initConstraint{
    
}

#pragma mark - 添加通知
- (void)addNotification{
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(didEndScroller:) name:YZDisplayViewClickOrScrollDidFinshNote object:nil];
}

- (void)removeNotification{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:YZDisplayViewClickOrScrollDidFinshNote object:nil];
}

- (void)didEndScroller:(NSNotification *)notification{
    UIViewController *vc = notification.object;
    if ([self.childViewControllers containsObject:vc]) {
        [self didSelectViewController:vc];
    }
}

- (void)didSelectViewController:(UIViewController *)viewController{
    
}

- (UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

- (BOOL)shouldAutorotate{
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

-(UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationPortrait;
}

@end
