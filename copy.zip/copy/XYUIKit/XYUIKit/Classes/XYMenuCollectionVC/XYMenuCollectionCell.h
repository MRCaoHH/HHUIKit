//
//  XYMenuCollectionCell.h
//  XYUIKit
//
//  Created by henry on 2018/1/2.
//

#import <UIKit/UIKit.h>

@interface XYMenuCollectionCell : UICollectionViewCell

/**
 图标
 */
@property (nonatomic,strong) UIImageView *iconImgView;


/**
 名字
 */
@property (nonatomic,strong) UILabel *nameLabel;

@end
