//
//  XYHttpRequestProtocol.m
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import "XYHttpRequestProtocol.h"
#import "XYHttpRequest.h"

static Class XYRegisclass = nil;

@implementation XYHttpRequestProtocol

#pragma mark - class manage
+ (Class)regisclass{
    if (XYRegisclass == nil) {
        return [XYHttpRequestProtocol class];
    }
    return XYRegisclass;
}

+ (BOOL)registerClass:(Class)aclass{
    if([aclass isSubclassOfClass:[XYHttpRequestProtocol class]]){
        XYRegisclass = aclass;
        return YES;
    }
    return NO;
}

+ (void)unregisterClass:(Class)aclass{
    if (XYRegisclass == aclass) {
        XYRegisclass = [XYHttpRequestProtocol class];
    }
}

#pragma mark - 默认的返回数据类型
+ (NSInteger)defaultResponseType{
    return XYResponseType_Json;
}

+ (NSInteger)defaultRequestType{
    return XYRequestType_Normal;
}

#pragma mark - host
+ (NSString *)host{
    return @"http://pods.xy.com:3000/api/v3/";
}

#pragma mark - 请求参数处理
+ (NSDictionary *)publicInputParams{
    return nil;
}

+ (NSDictionary *)inputParamsHander:(NSDictionary *)param{
    return param;
}

+ (BOOL)checkRequestSucc:(XYResponseModel **)responseModel;{
    return YES;
}

+ (void)handleFail:(XYResponseModel **)responseModel{
    
}

#pragma mark - 返回数据处理
+ (id)handelResponseObject:(id)responseObject{
    return responseObject;
}

+ (void)publicOutParam:(id)dataModel{
    
}

#pragma makr - http header
+ (NSDictionary <NSString *,NSString*>*)httpHeaderConfig{
    return nil;
}

+ (BOOL)checkParams:(id)params err:(NSString **)err;{
    return YES;
}

+ (NSDictionary *)transformParams:(id)params;{
    return params;
}
@end
