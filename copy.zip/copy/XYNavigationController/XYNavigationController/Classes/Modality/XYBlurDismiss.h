//
//  XYBlurDismiss.h
//  XYNavigationController
//
//  Created by caohuihui on 2017/12/07.
//  Copyright © 2017年 Xin YI. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,XYBlurDismissAnimateType) {
    XYBlurDismissAnimateType_EaseIn = 0,//淡出淡出
    XYBlurDismissAnimateType_BottomPop = 1,//从下面移除
};

@interface XYBlurDismiss : NSObject<UIViewControllerAnimatedTransitioning>
@property (nonatomic,assign) NSTimeInterval duration;
@property (nonatomic,assign) XYBlurDismissAnimateType type;

/**
 开始执行动画回调
 */
@property (nonatomic,copy) void(^dismissAnimate)(void);
@end
