//
//  XYViewController.h
//  XYRefresh
//
//  Created by henry on 11/06/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

@import UIKit;

@interface XYViewController : UITableViewController

@end
