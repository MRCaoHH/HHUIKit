//
//  XYWebSocketMsgModel.h
//  XYWebSocket_Example
//
//  Created by henry on 2017/11/28.
//  Copyright © 2017年 henry. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XYWebSocketMsgModel : NSObject

/**
 join 加入聊天 chat消息内容
 */
@property (nonatomic,copy) NSString *code;

/**
 消息内容
 */
@property (nonatomic,copy) NSString *message;

/**
 用户id
 */
@property (nonatomic,copy) NSString *mid;

/**
 直播id
 */
@property (nonatomic,copy) NSString *live_id;
@end
