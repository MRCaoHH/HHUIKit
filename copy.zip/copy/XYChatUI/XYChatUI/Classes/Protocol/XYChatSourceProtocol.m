//
//  XYChatSourceProtocol.m
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import "XYChatSourceProtocol.h"

@implementation XYChatSourceProtocol

static Class XYLSourceProtocolRegisClass = nil;

+ (Class)regisclass{
    if (XYLSourceProtocolRegisClass == nil) {
        return [self class];
    }
    return XYLSourceProtocolRegisClass ;
}

+ (BOOL)registerClass:(Class)aclass{
    if([aclass isSubclassOfClass:[self class]]){
        XYLSourceProtocolRegisClass = aclass;
        return YES;
    }
    return NO;
}

+ (void)unregisterClass:(Class)aclass{
    if (XYLSourceProtocolRegisClass == aclass) {
        XYLSourceProtocolRegisClass = [self class];
    }
}

+ (NSBundle *)sourceBundle{
    NSBundle *classBundle = [NSBundle bundleForClass:[self class]];
    NSString *bundlePath = [classBundle pathForResource:@"XYChatUI" ofType:@"bundle"];
    NSBundle *newBundle = [NSBundle bundleWithPath:bundlePath];
    return newBundle;
}

+ (UIImage *)imageWithName:(NSString *)imageName{
    NSString *path = [[[self regisclass] sourceBundle] pathForResource:[NSString stringWithFormat:@"%@@3x",imageName] ofType:@"png"];
    return [UIImage imageWithContentsOfFile:path];
}

+ (NSString *)pathWithName:(NSString *)fileName withType:(NSString *)type{
    return [[[self regisclass] sourceBundle] pathForResource:fileName ofType:type];
}
@end
