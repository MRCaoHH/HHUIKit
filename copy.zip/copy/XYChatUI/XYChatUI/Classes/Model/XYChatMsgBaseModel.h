//
//  XYChatMsgBaseModel.h
//  MJExtension
//
//  Created by henry on 2017/11/20.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,XYChatMsgSendState) {
    XYChatMsgSendState_Unkow = 0, //未知
    XYChatMsgSendState_None = 1, //正常,发送成功
    XYChatMsgSendState_Sending = 2, //发送中
    XYChatMsgSendState_Fail = 3, //发送失败
};

@interface XYChatMsgBaseModel : NSObject

/**
 消息id
 */
@property (nonatomic,copy) NSString *id;

/**
 消息id
 */
@property (nonatomic,copy) NSString *messageId;

/**
 发送方用户id
 */
@property (nonatomic,copy) NSString *sendUId;

/**
 接收方id
 */
@property (nonatomic,copy) NSString *toUid;

/**
 消息创建时间
 */
@property (nonatomic,assign) NSTimeInterval createTime;

/**
 是否发送方
 */
@property (nonatomic,assign) BOOL isSend;

/**
 属性字典
 */
@property (nonatomic,strong) NSDictionary *attributesDic;

/**
 消息状态
 */
@property (nonatomic,assign) XYChatMsgSendState state;

/**
 发送状态监听
 */
@property (nonatomic,copy)  void(^stateObserver)(NSInteger state);

/**
 cell 高度
 */
@property (nonatomic,assign) CGFloat cellHeight;

/**
 气泡的frame
 */
@property (nonatomic,assign) CGRect bubbleFrame;

/**
 重新发布按钮
 */
@property (nonatomic,assign) CGRect resendFreme;

/**
 菊花
 */
@property (nonatomic,assign) CGRect loadingFrame;
@end
