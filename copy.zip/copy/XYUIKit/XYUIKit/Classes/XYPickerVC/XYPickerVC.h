//
//  XYPickerVC.h
//  XYUIKit
//
//  Created by henry on 2017/12/23.
//

#import <UIKit/UIKit.h>

@protocol XYPickerItem <NSObject>
@optional
///显示的标题
- (NSString *)title;
///子标题
- (NSArray *)subTitle;
@end

@interface XYPickerItemModel:NSObject<XYPickerItem>
@property (nonatomic,copy) NSString *title;
@property (nonatomic,strong) NSArray <id<XYPickerItem>>*subTitle;
@end


@protocol XYPickerVCDelegate;

@interface XYPickerVC : UIViewController

/**
 根据标题数组初始化

 @param titlArr 标题
 @return 实例
 */
- (instancetype)initWithTitleArr:(NSArray <id<XYPickerItem>>*)titlArr;

/**
 标题
 */
@property (nonatomic,strong) NSArray <id<XYPickerItem>>*titleArr;


/**
 点击确认按钮时候返回标题
 */
@property (nonatomic,copy) void(^clickOkButtonCallback)(NSString *title);

/**
 协议
 */
@property (nonatomic,weak) id<XYPickerVCDelegate> delegate;

/**
 设置选中行

 @param row 行
 @param component 块
 */
- (void)setSelectRow:(NSInteger)row component:(NSInteger)component;
@end


@protocol XYPickerVCDelegate<NSObject>
@optional

/**
 标题准备改变

 @param pickerVC 选择控制器
 @param title 新标题
 */
- (void)pickerVC:(XYPickerVC *)pickerVC  titleDidChange:(NSString *)title;

/**
 点击确认按钮

 @param pickerVC 选择控制器
 @param selItemArr 选中的item数组 从小到大排序
 */
- (void)pickerVC:(XYPickerVC *)pickerVC didClickOkBtn:(NSArray *)selItemArr;

/**
 点击取消按钮

 @param pickerVC 选择视图
 */
- (void)pickerVCDidClickCancelBtn:(XYPickerVC *)pickerVC ;
@end
