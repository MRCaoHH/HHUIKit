//
//  XYExampleProtocol.h
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//  Copyright © 2017年 Henry. All rights reserved.
//

#import <XYNetworking/XYNetworking.h>

@interface XYExampleProtocol : XYHttpRequestProtocol

@end
