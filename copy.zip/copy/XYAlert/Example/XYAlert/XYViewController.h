//
//  XYViewController.h
//  XYAlert
//
//  Created by Henry on 12/14/2017.
//  Copyright (c) 2017 Henry. All rights reserved.
//

@import UIKit;

@interface XYViewController : UIViewController

@end
