//
//  XYWebSocket.h
//  XYWebSocket
//
//  Created by henry on 2017/11/28.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,XYWebSocketState) {
    XYWebSocketState_Normal = -1,//未知
    XYWebSocketState_Connecting = 0,//连接中
    XYWebSocketState_Connect = 1,//连接
    XYWebSocketState_Disconnecting = 2,//断开连接中
    XYWebSocketState_Disconnect = 3// 断开连接
};

@protocol XYWebSocketDelegate;

@interface XYWebSocket : NSObject

//+(instancetype)shareInstance;

/**
 sw地址
 */
@property (nonatomic,strong) NSString *url;

/**
 状态
 */
@property (nonatomic, readonly) XYWebSocketState state;

/**
 添加代理

 @param delegate 代理对象
 */
- (void)addDelegate:(id<XYWebSocketDelegate>)delegate;

/**
 移除代理

 @param delegate 代理对象
 */
- (void)removeDelegate:(id<XYWebSocketDelegate>)delegate;

/**
 连接
 */
- (void)connect;

/**
 连接

 @param complete 连接完成回调
 */
- (void)connect;

/**
 断开连接
 */
- (void)disconnect;

/**
 发送消息

 @param msg 消息内容
 */
- (void)sendMsg:(id)msg;

@end

@protocol XYWebSocketDelegate<NSObject>
@optional

/**
 准备接收消息

 @param webSocket webSocket
 @param message 消息
 */
- (void)webSocket:(XYWebSocket *)webSocket didReceiveMessage:(id)message;

/**
 准备连接

 @param webSocket socket
 */
- (void)webSocketDidConnect:(XYWebSocket *)webSocket;

/**
 连接失败

 @param webSocket socket
 @param err 错误
 */
- (void)webSocket:(XYWebSocket *)webSocket connectFail:(NSError *)err;

/**
 准备断开连接

 @param webSocket socket
 */
- (void)webSocketDidDisconnect:(XYWebSocket *)webSocket;
@end
