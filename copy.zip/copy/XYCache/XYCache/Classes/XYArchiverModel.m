//
//  XYArchiverModel.m
//  XYCacheDemo
//
//  Created by caohuihui on 2017/10/27.
//  Copyright © 2017年 caohuihui. All rights reserved.
//

#import "XYArchiverModel.h"
#import "XYArchiverTool.h"

@implementation XYArchiverModel

- (id)initWithCoder:(NSCoder *)decoder {
    self = [super init];
    if (!self) {
        return nil;
    }
    [XYArchiverTool unarchiver:decoder object:self];
    return self;
}

- (void)encodeWithCoder:(NSCoder *)encoder {
    [XYArchiverTool archiver:encoder object:self];
}

@end
