//
//  XYViewController2.m
//  GPUImage
//
//  Created by henry on 2018/11/22.
//

#import "XYViewController2.h"
#import <XYFiters/XYFiterCamera.h>
#import <GPUImage/GPUImage.h>

@interface XYViewController2 ()
@property (nonatomic,strong) XYFiterCamera *camera;
@end

@implementation XYViewController2

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.camera = [XYFiterCamera new];
    self.camera.imgView = (GPUImageView *)self.view;
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(100, 500, 60, 30)];
    [button setBackgroundColor:[UIColor redColor]];
    [button setTitle:@"滤镜" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(clickButtonEvent) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:button];
    
    
}

- (void)loadView{
    self.view = [GPUImageView new];
}

- (void)clickButtonEvent{
    XYFilterType type = self.camera.filterType + 1;
    if(type > XY_LORDKELVIN_FILTER){
        type = XY_NORMAL_FILTER;
    }
    self.camera.filterType = type;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
