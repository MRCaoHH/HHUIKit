//
//  XYTrendChartView.h
//  HHTestGestureRecognizer
//
//  Created by henry on 2018/5/29.
//  Copyright © 2018年 caohuihui. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,XYTrendChartViewType) {
    XYTrendChartViewType_Form = 1<<0,//绘制表格
    XYTrendChartViewType_Vesion = 1<<1,//绘制期数
    XYTrendChartViewType_Number = 1<<2,//绘制号码
    XYTrendChartViewType_Winning = 1<<3,//中奖号码
    XYTrendChartViewType_LinkLine = 1<<4,//连线
    XYTrendChartViewType_Complement = 1<<5,//补位，即遗漏分层
    XYTrendChartViewType_None = XYTrendChartViewType_Complement|XYTrendChartViewType_LinkLine|XYTrendChartViewType_Winning|XYTrendChartViewType_Number|XYTrendChartViewType_Vesion|XYTrendChartViewType_Form,//正常
};

@interface XYTrendChartView : UIView

/**
 记录数组
 */
@property (nonatomic,strong) NSArray *recordArr;

/**
 线条颜色
 */
@property (nonatomic,strong) UIColor *lineColor;

/**
 行高
 */
@property (nonatomic,assign) CGFloat lineHeight;

/**
 第一列宽度
 */
@property (nonatomic,assign) CGFloat firstColumnWidth;

/**
 奇数行背景颜色
 */
@property (nonatomic,strong) UIColor *oddNumberLineColor;

/**
 偶数行背景颜色
 */
@property (nonatomic,strong) UIColor *evenNumberLineColor;

/**
 连接线颜色
 */
@property (nonatomic,strong) UIColor *linkLineColor;

/**
 中奖原形背景颜色
 */
@property (nonatomic,strong) UIColor *winningBgColor;

/**
 补位方块背景颜色
 */
@property (nonatomic,strong) UIColor *complementBgColor;

/**
 文本字体
 */
@property (nonatomic,strong) UIFont *textFont;

/**
 文本字体颜色
 */
@property (nonatomic,strong) UIColor *textColor;

/**
 表格类型
 */
@property (nonatomic,assign) XYTrendChartViewType type;
@end

@interface XYTrendChartRecord : NSObject

/**
 中奖号码的下标
 */
@property (nonatomic,assign) NSInteger winning;

/**
 版本
 */
@property (nonatomic,copy) NSString *version;

/**
 本期所有号码数组
 */
@property (nonatomic,strong) NSMutableArray *numberArr;

@end
