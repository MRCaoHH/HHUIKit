//
//  XYChatVC.h
//  Pods-XYChatUI_Example
//
//  Created by henry on 2017/11/15.
//

#import <UIKit/UIKit.h>
@protocol XYChatFooterProtocol;
@protocol XYChatHeaderProtocol;
@protocol XYChatVCProtocol;
@class XYChatContactModel;

@interface XYChatVC : UIViewController
/**
 脚部
 */
@property (nonatomic,strong) UIView <XYChatFooterProtocol>* footerView;

/**
 头部
 */
@property (nonatomic,strong) UIView <XYChatHeaderProtocol>* headerView;

/**
 联系人模型
 */
@property (nonatomic,strong) XYChatContactModel *contactModel;

/**
 列表
 */
@property (nonatomic,strong) UITableView *tableView;

/**
 协议
 */
@property (nonatomic,strong) id<XYChatVCProtocol> protocol;

/**
 根据协议初始化

 @param protocol 协议
 @return 实例
 */
- (instancetype)initWithProtocol:(id<XYChatVCProtocol>)protocol;

/**
根据联系人模型初始化初始化

 @param model 模型
 @return 实例
 */
- (instancetype)initWithChatContactModel:(XYChatContactModel *)model;

/**
 根据mid和用户名初始化

 @param mid 成员id
 @param name 用户名
 @return 实例
 */
- (instancetype)initWithMid:(NSString *)mid name:(NSString *)name;

/**
 根据协议和联系人模型初始化初始化

 @param protocol 协议
 @param model 模型
 @return 实例
 */
- (instancetype)initWithProtocol:(id<XYChatVCProtocol>)protocol chatContactModel:(XYChatContactModel *)model;

/**
 滚动到底部

 @param animated 是否执行动画
 */
- (void)scrollToBottom:(BOOL)animated;
@end
