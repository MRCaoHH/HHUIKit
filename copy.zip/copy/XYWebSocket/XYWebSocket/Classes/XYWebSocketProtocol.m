//
//  XYWebSocketProtocol.m
//  XYWebSocket
//
//  Created by henry on 2017/11/28.
//

#import "XYWebSocketProtocol.h"

@implementation XYWebSocketProtocol
static Class XYProtocolRegisClass = nil;

+ (Class)regisclass{
    if (XYProtocolRegisClass == nil) {
        return [self class];
    }
    return XYProtocolRegisClass ;
}

+ (BOOL)registerClass:(Class)aclass{
    if([aclass isSubclassOfClass:[self class]]){
        XYProtocolRegisClass = aclass;
        return YES;
    }
    return NO;
}

+ (void)unregisterClass:(Class)aclass{
    if (XYProtocolRegisClass == aclass) {
        XYProtocolRegisClass = [self class];
    }
}

- (id)convertReceiveMessage:(id)message{
    return message;
}
@end
