//
//  XYViewController.m
//  XYMenuViewController
//
//  Created by henry on 11/03/2017.
//  Copyright (c) 2017 henry. All rights reserved.
//

#import "XYViewController.h"
#import "XYChildViewController.h"

@interface XYViewController ()

@end

@implementation XYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    self.isNavBarMenu = YES;
    self.offset = 20;
    self.isShowTitleScale = YES;
    self.titleScale = 1.2;
    [self setUpTitleEffect:^(UIColor *__autoreleasing *titleScrollViewColor, UIColor *__autoreleasing *norColor, UIColor *__autoreleasing *selColor, UIFont *__autoreleasing *titleFont, CGFloat *titleHeight) {
        // 设置标题字体
        *titleFont            = [UIFont systemFontOfSize:15];
        *norColor             = [UIColor grayColor];
        *selColor             = [UIColor redColor];
        *titleScrollViewColor = [UIColor clearColor];
    }];
    
    [self setUpUnderLineEffect:^(BOOL *isShowUnderLine, BOOL *isDelayScroll, CGFloat *underLineH, UIColor *__autoreleasing *underLineColor) {
        
        // 是否显示标签
        *isShowUnderLine = YES;
        
        // 标题填充模式
        *underLineColor  = [UIColor redColor];
    }];
    self.view.backgroundColor = [UIColor whiteColor];
    self.titleScrollViewColor = [UIColor clearColor];
    self.titleHeight          = 44;
    self.isfullScreen         = NO;
    self.underLineYOffset = - 5;
    self.underLineFixedW = NO;
    self.sepLineHeight = 22;
    self.sepLineColor = [UIColor blackColor];
    self.isHiddenSeparatorLineView = NO;
    self.showBottomLine = NO;
    
    XYChildViewController *vc1 = [XYChildViewController new];
    vc1.view.backgroundColor = [UIColor orangeColor];
    vc1.title = @"控制器1";
    [self addChildViewController:vc1];
    
    XYChildViewController *vc2 = [XYChildViewController new];
    vc2.view.backgroundColor = [UIColor purpleColor];
    vc2.title = @"控制器2";
    [self addChildViewController:vc2];
    
    XYChildViewController *vc3 = [XYChildViewController new];
    vc3.view.backgroundColor = [UIColor greenColor];
    vc3.title = @"控制器3";
    [self addChildViewController:vc3];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
