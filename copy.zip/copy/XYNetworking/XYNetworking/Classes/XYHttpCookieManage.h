//
//  XYHttpCookieManage.h
//  XYNetworking
//
//  Created by henry on 2017/10/26.
//

#import <Foundation/Foundation.h>

@interface XYHttpCookieManage : NSObject

/**
 保存cookie
 
 @param host 主页
 */
+ (void)saveCookieWithHost:(NSString *)host;


/**
 设置cookie
 
 @param host 主页
 */
+ (void)setCookieWithHost:(NSString *)host;


/**
 移除cookie
 
 @param host 主页
 */
+ (void)removeCookieWithHost:(NSString *)host;

@end
