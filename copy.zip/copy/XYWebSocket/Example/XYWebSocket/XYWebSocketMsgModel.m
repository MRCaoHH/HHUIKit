//
//  XYWebSocketMsgModel.m
//  XYWebSocket_Example
//
//  Created by henry on 2017/11/28.
//  Copyright © 2017年 henry. All rights reserved.
//

#import "XYWebSocketMsgModel.h"

@implementation XYWebSocketMsgModel

- (instancetype)init{
    self = [super init];
    if (self) {
        if (TARGET_IPHONE_SIMULATOR) {
            _mid = @"1";
        }else{
            _mid = @"2";
        }
        _live_id = @"1";
    }
    return self;
}
@end
